"""Target-only fixed-input measurement controller; source edits are prohibited during use."""
import os,subprocess,json,hashlib,math,time,sys,statistics
from pathlib import Path
sys.path.insert(0,'tools')
from vulkan_source_receipt import source_hashes
from vulkan_performance import summarize_samples
root=Path.cwd();proof=root/'target/cap-edge-proof';frozen=json.loads((proof/'full-build-inputs.json').read_text());binary=root/'target/release/examples/capping_texture_edges_performance';frozen_binary=json.loads((proof/'freeze-readiness.json').read_text())['optimized_binary_sha256'];reports=[]
def input_hashes():
 result=source_hashes()
 for p in Path('.cargo').glob('*'):
  if p.is_file():result[p.as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result

def observe():
 inputs=input_hashes();sha=hashlib.sha256(binary.read_bytes()).hexdigest();assert inputs==frozen;assert sha==frozen_binary
 processes=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   args=(p/'cmdline').read_bytes().split(b'\0');name=Path(args[0].decode()).name
   if name not in ('cargo','rustc','rustdoc','clippy-driver','cc','c++','g++','clang','clang++','cmake','ninja','glslangValidator') and not name.endswith('_performance'):continue
   processes.append(dict(pid=int(p.name),program=name,cwd=os.readlink(p/'cwd')))
  except (OSError,UnicodeError):pass
 return dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),loadavg=Path('/proc/loadavg').read_text().strip(),processes=processes,input_count=len(inputs),input_manifest_sha256=hashlib.sha256((proof/'full-build-inputs.json').read_bytes()).hexdigest(),binary_sha256=sha,source_unchanged=True,binary_unchanged=True)
base='/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-layer-ab/extracted/usr'
for profile,icd in [('software','lvp'),('host','radeon')]:
 if profile == 'host':
  print('MARTENSITE_PROFILE_BOUNDARY_WAIT='+str(proof/'allow-host-timing'),flush=True)
  while not (proof/'allow-host-timing').exists(): time.sleep(1)
 env=dict(os.environ,DISPLAY=':1',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/'+icd+'_icd.json',LP_NATIVE_VECTOR_WIDTH='128',GALLIUM_OVERRIDE_CPU_CAPS='sse2',MARTENSITE_VULKAN_DEVICE='0',VK_LAYER_PATH=base+'/share/vulkan/explicit_layer.d',LD_LIBRARY_PATH=base+'/lib/x86_64-linux-gnu');env.pop('LLVM_TARGET_FEATURES',None)
 before=observe();identity=subprocess.run(['vulkaninfo','--summary'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(proof/f'performance-device-{profile}.log').write_text(identity.stdout);assert identity.returncode==0
 command=[str(binary)];started=time.monotonic();run=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);elapsed=time.monotonic()-started;(proof/f'performance-{profile}.log').write_text(run.stdout);after=observe();assert run.returncode==0
 rows=[json.loads(line.removeprefix('MARTENSITE_PERFORMANCE=')) for line in run.stdout.splitlines() if line.startswith('MARTENSITE_PERFORMANCE=')];devices=list(dict.fromkeys(line.removeprefix('MARTENSITE_DEVICE=') for line in run.stdout.splitlines() if line.startswith('MARTENSITE_DEVICE=')));assert len(rows)==64;assert len({r['workload'] for r in rows})==64;assert len(devices)==1
 for row in rows:
  assert row['warmup']==20 and row['validation'] is False and len(row['samples_ms'])==100
  row.update(summarize_samples(row['samples_ms']))
 report=dict(profile=profile,command=command,exit=run.returncode,elapsed_seconds=elapsed,device=devices[0],env={key:env.get(key) for key in ['DISPLAY','VK_DRIVER_FILES','LP_NATIVE_VECTOR_WIDTH','GALLIUM_OVERRIDE_CPU_CAPS','LLVM_TARGET_FEATURES','MARTENSITE_VULKAN_DEVICE','VK_LAYER_PATH','LD_LIBRARY_PATH']},before=before,after=after,performance=rows,baseline_accepted=False)
 (proof/f'performance-{profile}.json').write_text(json.dumps(report,indent=2)+'\n');reports.append(report);print(json.dumps(dict(profile=profile,exit=0,workloads=len(rows),samples=6400,median_range_ms=[min(r['median_ms'] for r in rows),max(r['median_ms'] for r in rows)],source_and_binary_unchanged=True)),flush=True)
(proof/'performance-summary.json').write_text(json.dumps([dict(profile=r['profile'],device=r['device'],exit=r['exit'],workloads=64,samples=6400,before=r['before'],after=r['after'],baseline_accepted=False) for r in reports],indent=2)+'\n')
