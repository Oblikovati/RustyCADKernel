from pathlib import Path
import os,subprocess,json,tarfile,hashlib
root=Path('/tmp/rustycad-ubtree-filler-native-dispatch');target=Path('/tmp/rustycad-sparse-base-target')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(target))
paths=[root/'crates/tkernel/src/ncollection'/name for name in ['ubtree.rs','ubtree/insertion.rs','ebtree.rs']]
final={p:p.read_bytes() for p in paths}
def compatibility(label):
 result=subprocess.run(['cargo','build','-p','rustycad-tkernel','--lib','--message-format=json'],cwd=root,env=env,capture_output=True)
 Path('/tmp/filler-dispatch-'+label+'-build.log').write_bytes(result.stdout+result.stderr);result.check_returncode()
 artifacts=[json.loads(line) for line in result.stdout.splitlines()]
 libraries=[p for item in artifacts if item.get('reason')=='compiler-artifact' and item['target']['name']=='rustycad_tkernel' for p in item['filenames'] if p.endswith('.rlib')]
 for probe,expected in [('compatibility',0),('negative-dropck',1),('negative-send',1),('negative-sync',1)]:
  binary='/tmp/filler-dispatch-'+label+'-'+probe
  with open(binary+'.log','w') as output:
   result=subprocess.run(['rustc','--edition=2024','/tmp/filler-dispatch-'+probe+'.rs','--extern','rustycad_tkernel='+libraries[-1],'-L','dependency='+str(target/'debug/deps'),'-o',binary],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
   assert result.returncode==expected,(label,probe,result.returncode)
   if expected==0:subprocess.run([binary],stdout=output,stderr=subprocess.STDOUT,check=True)
  print(label,probe,result.returncode,flush=True)
 return hashlib.sha256(Path(libraries[-1]).read_bytes()).hexdigest()

print(compatibility("candidate"))
