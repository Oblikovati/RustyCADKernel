import gzip,hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/kernel-10-batch-integration-2026-10-14';out.mkdir(parents=True,exist_ok=True)
candidates=['482e6fbc2','d2909a9e0','59348feee','a41b53c61',sys.argv[1]]
base='c57add1af'
reviewed=['crates/tkbo/src/sketch_region_prism/frozen/mod.rs','crates/tkbo/src/sketch_region_prism/frozen/annular_orientation/mod.rs','crates/tkbo/src/sketch_region_prism/owned_request/mod.rs','crates/tkbo/src/sketch_region_prism/exact_tolerance/annular/mod.rs']
shared_facades=['crates/tkbo/src/sketch_region_prism/diagnostic_envelope/'+tail for tail in ['mod.rs','replay/mod.rs','replay/native.rs','replay/phases.rs']]
def git(*args):return subprocess.check_output(['git',*args])
def digest(payload):return hashlib.sha256(payload).hexdigest()
rows=[]
for candidate in candidates:
 ancestor=git('merge-base',base,candidate).decode().strip();names=git('diff','--name-only',ancestor,candidate,'--','crates').decode().splitlines()
 for name in names:
  expected=git('show',candidate+':'+name);actual=(root/name).read_bytes();exact=actual==expected
  if not exact:
   assert name in reviewed or (candidate=='d2909a9e0' and name in shared_facades),(candidate,name)
   approved='900b414e0' if name in reviewed else 'cf196e9fe'
   assert actual==git('show',approved+':'+name),(candidate,name,'unreviewed change')
   patch=git('diff',candidate,'HEAD','--',name)
   (out/(candidate+'-'+name.replace('/','_')+'.diff.gz')).write_bytes(gzip.compress(patch,mtime=0))
  rows.append({'candidate':candidate,'path':name,'sha256':digest(actual),'candidate_exact':exact,'reviewed_registration_union':not exact and name in reviewed,'reviewed_shared_codec_facade':not exact and name in shared_facades})
receipt={'base':base,'revision':git('rev-parse','HEAD').decode().strip(),'candidates':candidates,'reviewed_union_reference':'900b414e0','files':rows}
(out/'source-origin-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'source-audit-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'candidate_file_checks':len(rows),'reviewed_unions':sum(x['reviewed_registration_union'] for x in rows),'reviewed_shared_facades':sum(x['reviewed_shared_codec_facade'] for x in rows)}))
