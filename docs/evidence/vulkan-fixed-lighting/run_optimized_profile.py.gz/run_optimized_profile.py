from pathlib import Path
import os,sys,json,gzip,hashlib,subprocess,time,math,statistics
sys.path.insert(0,'tools')
from vulkan_source_receipt import source_hashes
root=Path.cwd();proof=root/'target/fixed-lighting-proof';profile=sys.argv[1]
if profile not in ['software','host']:raise ValueError('expected software or host')
freeze=json.loads(gzip.decompress((proof/'optimized-freeze.json.gz').read_bytes()));binary=root/freeze['binary']['path']
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def observations():
 processes=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   comm=(p/'comm').read_text().strip();stat=(p/'stat').read_text().split()
   if any(x in comm.lower() for x in ['cargo','rustc','rustdoc','clippy','cc1','ninja','cmake','python','fixed_lighting']):processes.append({'pid':int(p.name),'comm':comm,'state':stat[2]})
  except (OSError,IndexError):pass
 return {'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'load_average':os.getloadavg(),'affinity':sorted(os.sched_getaffinity(0)),'processes':processes}
def bookend(label):
 hashes=source_hashes();external={p:digest(p) for p in freeze['external_libraries']};head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 receipt={'profile':profile,'label':label,'source_head':head,'source_equal':hashes==freeze['source_hashes'],'binary_equal':digest(binary)==freeze['binary']['sha256'],'external_equal':external==freeze['external_libraries'],'observations':observations()}
 (proof/f'optimized-{profile}-{label}.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if not all(receipt[k] for k in ['source_equal','binary_equal','external_equal']) or head!=freeze['source_head']:raise ValueError('frozen inputs changed')
 return receipt
before=bookend('before');env=os.environ.copy();icd='lvp' if profile=='software' else 'radeon';env.update(DISPLAY=':1',GALLIUM_OVERRIDE_CPU_CAPS='sse2',LP_NATIVE_VECTOR_WIDTH='128',MARTENSITE_VULKAN_DEVICE='0',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/'+icd+'_icd.json',VK_LAYER_PATH=str((root/'../RustyCADKernel/target/vulkan-layer-ab/extracted/usr/share/vulkan/explicit_layer.d').resolve()),LD_LIBRARY_PATH=str((root/'../RustyCADKernel/target/vulkan-layer-ab/extracted/usr/lib/x86_64-linux-gnu').resolve()));env.pop('LLVM_TARGET_FEATURES',None)
log=proof/f'optimized-{profile}.log';cmd=[str(binary)]
with log.open('w') as stream:completed=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
rows=[];device=''
for line in log.read_text().splitlines():
 if line.startswith('MARTENSITE_DEVICE='):device=line.split('=',1)[1]
 if line.startswith('MARTENSITE_PERFORMANCE='):
  row=json.loads(line.split('=',1)[1]);samples=row['samples_ms'];assert len(samples)==100 and row['warmup']==20 and row['validation'] is False and all(math.isfinite(v) and v>0 for v in samples)
  row['median_ms']=statistics.median(samples);row['p95_ms']=sorted(samples)[94];rows.append(row)
assert completed.returncode==0 and len(rows)==124,(completed.returncode,len(rows))
after=bookend('after');report={'profile':profile,'exit':completed.returncode,'device':device,'command':cmd,'environment':{k:env[k] for k in ['DISPLAY','GALLIUM_OVERRIDE_CPU_CAPS','LP_NATIVE_VECTOR_WIDTH','MARTENSITE_VULKAN_DEVICE','VK_DRIVER_FILES','VK_LAYER_PATH','LD_LIBRARY_PATH']},'LLVM_TARGET_FEATURES':env.get('LLVM_TARGET_FEATURES'),'binary':freeze['binary'],'source_head':freeze['source_head'],'baseline_accepted':False,'before':before,'after':after,'workloads':rows}
(proof/f'optimized-{profile}-report.json.gz').write_bytes(gzip.compress((json.dumps(report,indent=2)+'\n').encode(),mtime=0));print(json.dumps({'profile':profile,'exit':completed.returncode,'workloads':len(rows),'samples':sum(len(r['samples_ms']) for r in rows),'device':device,'report':str(proof/f'optimized-{profile}-report.json.gz')}),flush=True)
