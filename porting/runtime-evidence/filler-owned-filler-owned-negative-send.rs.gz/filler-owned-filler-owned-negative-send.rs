use rustycad_tkernel::ncollection::{BoundingNode, BoundingVolume, ObjBnd, UBTree, EBTree, HashKey};
use std::panic::{UnwindSafe, RefUnwindSafe};
#[derive(Clone,Default)] struct Bounds;
impl BoundingVolume for Bounds {
    fn add(&mut self, _: &Self) {}
    fn is_out(&self, _: &Self)->bool { false }
    fn square_extent(&self)->f64 { 0.0 }
}
fn assert_send<T: Send>() {}
fn main() { assert_send::<UBTree<std::rc::Rc<()>,Bounds>>(); }

fn native_wrapper_rejection() { assert_send::<rustycad_tkernel::ncollection::NativeBoundingTree<'static,UBTree<std::rc::Rc<()>,Bounds>>>(); }
