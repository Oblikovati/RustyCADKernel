from pathlib import Path
import os,subprocess,json,tarfile,hashlib
root=Path('/tmp/rustycad-ebtree-remove-order');target=Path('/tmp/rustycad-sparse-base-target')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(target))
paths=[root/'crates/tkernel/src/ncollection'/name for name in ['ebtree.rs','ubtree/removal.rs']];final={p:p.read_bytes() for p in paths}
def compatibility(label):
 result=subprocess.run(['cargo','build','-p','rustycad-tkernel','--lib','--message-format=json'],cwd=root,env=env,capture_output=True)
 Path('/tmp/ebtree-remove-'+label+'-build.log').write_bytes(result.stdout+result.stderr);result.check_returncode()
 artifacts=[json.loads(line) for line in result.stdout.splitlines()]
 libraries=[p for item in artifacts if item.get('reason')=='compiler-artifact' and item['target']['name']=='rustycad_tkernel' for p in item['filenames'] if p.endswith('.rlib')]
 binary='/tmp/ebtree-remove-dropck-'+label
 with open('/tmp/ebtree-remove-'+label+'-dropck.log','w') as output:
  subprocess.run(['rustc','--edition=2024','/tmp/ebtree-remove-dropck.rs','--extern','rustycad_tkernel='+libraries[-1],'-L','dependency='+str(target/'debug/deps'),'-o',binary],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
  subprocess.run([binary],stdout=output,stderr=subprocess.STDOUT,check=True)
 print(label,'dropck 0',flush=True)
 return hashlib.sha256(Path(libraries[-1]).read_bytes()).hexdigest()
def focused(label,expected):
 with open('/tmp/ebtree-remove-'+label+'-focused.log','w') as output:
  result=subprocess.run(['cargo','test','-p','rustycad-tkernel','--test','ebtree_remove_contracts'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 assert result.returncode==expected,(label,result.returncode)
 print(label,'focused',result.returncode,flush=True)
try:
 for p in paths:p.write_bytes(subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(root))],cwd=root))
 selected=paths+[root/'crates/tkernel/tests/ebtree_remove_contracts.rs',*sorted((root/'crates/tkernel/tests/ebtree_remove_contracts').glob('*.rs'))]
 with tarfile.open('/tmp/ebtree-remove-final-baseline-source.tar.gz','w:gz') as archive:
  for p in selected:archive.add(p,arcname=str(p.relative_to(root)))
 baseline=compatibility('baseline');focused('baseline',101)
finally:
 for p,content in final.items():p.write_bytes(content)
candidate=compatibility('candidate');focused('candidate',0)
Path('/tmp/ebtree-remove-baseline-proof.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'baseline_rlib_sha256':baseline,'candidate_rlib_sha256':candidate,'baseline_kind':'Actual HEAD production EBTree and UBTree removal modules with final test sources; no reconstructed ordering.','candidate_source_restored':True},indent=2)+'\n')
