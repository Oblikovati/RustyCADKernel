use rustycad_tkernel::ncollection::DynamicArray;
use std::{cell::RefCell, rc::Rc, panic::{catch_unwind, AssertUnwindSafe}};
struct Probe(i32, Rc<RefCell<Vec<i32>>>);
impl Drop for Probe {
    fn drop(&mut self) {
        self.1.borrow_mut().push(self.0);
        assert_ne!(self.0, 1, "destructor1: expected a different probe value");
    }
}
#[test]
fn clear_stops_immediately_after_native_throwing_destructor() {
    let events = Rc::new(RefCell::new(Vec::new()));
    let mut array = DynamicArray::with_increment(2);
    for value in 1..=5 { array.append(Probe(value, events.clone())); }
    assert!(catch_unwind(AssertUnwindSafe(|| array.clear(true))).is_err());
    assert_eq!(*events.borrow(), vec![1]);
}
