#!/bin/bash
cd /tmp/rustycad-mmgropt-free-list-table || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-target
cargo test -p rustycad-tkernel --lib standard::mmgr_opt > /tmp/mmgropt-table-unit.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-unit.exit
cargo test -p rustycad-tkernel --test mmgr_opt_initialize --test mmgr_opt_callback_unwind --test standard_memory_storage --test standard_services_api_behavior --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_cell_filter --test ncollection_ordered_map --test ncollection_ordered_data_map > /tmp/mmgropt-table-rust.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-rust.exit
cargo test -p rustycad-tkernel --doc > /tmp/mmgropt-table-doc.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-doc.exit
cargo clippy -p rustycad-tkernel --all-targets -- -D warnings > /tmp/mmgropt-table-clippy.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-clippy.exit
cargo fmt --all -- --check > /tmp/mmgropt-table-fmt.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-fmt.exit

#!/bin/bash
cd /tmp/rustycad-mmgropt-free-list-table || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-miri MIRIFLAGS=-Zmiri-strict-provenance
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib standard::mmgr_opt > /tmp/mmgropt-table-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test mmgr_opt_initialize --test mmgr_opt_callback_unwind --test standard_memory_storage > /tmp/mmgropt-table-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_services_api_behavior memory -- --skip memory::allocate_optimal_returns_null_instead_of_raising > /tmp/mmgropt-table-services-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-table-services-miri.exit

#!/bin/bash
cd /tmp/rustycad-mmgropt-free-list-table || exit 2
c++ -std=c++17 tools/oracle/tkernel_mmgr_opt_free_list_table.cxx -I/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/include/opencascade -L/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -Wl,-rpath,/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -Wl,--export-dynamic -lTKernel -o /tmp/mmgropt-table-native
/tmp/mmgropt-table-native
for stem in initialize callback_unwind; do
 c++ -std=c++17 tools/oracle/tkernel_mmgr_opt_${stem}.cxx -I/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/include/opencascade -L/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -Wl,-rpath,/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -lTKernel -o /tmp/mmgropt-table-${stem}-native
 /tmp/mmgropt-table-${stem}-native
 done
/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/bini/OpenCascadeGTest --gtest_filter='NCollection_BaseAllocatorTest.*:NCollection_OccAllocatorTest.*:NCollection_CellFilterTest.*:NCollection_OrderedMapTest.*:NCollection_OrderedDataMapTest.*'
