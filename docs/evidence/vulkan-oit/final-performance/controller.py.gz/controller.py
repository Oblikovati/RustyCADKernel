import hashlib,json,math,os,pathlib,subprocess,sys,time
root=pathlib.Path.cwd();freeze=root/'target/oit-proof/performance-freeze';spec=json.loads((freeze/'freeze.json').read_text());profile=sys.argv[1]
if profile not in ('software','host'):raise ValueError(f'profile={profile}; expected software or host')
folder=root/'target/oit-proof/final-performance'/profile;folder.mkdir(parents=True,exist_ok=True)
inputs=json.loads((freeze/'inputs.json').read_text());external=json.loads((freeze/'external-inputs.json').read_text());binary=pathlib.Path(spec['binary_path'])
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def process_facts():
 records=[]
 for folder in pathlib.Path('/proc').iterdir():
  if not folder.name.isdigit():continue
  try:comm=(folder/'comm').read_text().strip()
  except (FileNotFoundError,ProcessLookupError):continue
  if any(part in comm for part in ('cargo','rustc','rustdoc','clippy','llvm-cov','cc1','glslang','oit_perform','native-oit')):records.append({'pid':int(folder.name),'comm':comm})
 return records
def observe(label):
 actual={name:digest(root/name) for name in inputs};libraries={name:digest(pathlib.Path(name)) for name in external};head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 receipt={'head':head,'source_hashes':actual,'external_hashes':libraries,'binary_sha256':digest(binary),'processes':process_facts(),'loadavg':pathlib.Path('/proc/loadavg').read_text().strip(),'time':time.time(),'source_equal':actual==inputs,'external_equal':libraries==external,'binary_equal':digest(binary)==spec['binary_sha256']}
 (folder/f'{label}.json').write_text(json.dumps(receipt,indent=2));assert receipt['source_equal'] and receipt['external_equal'] and receipt['binary_equal'] and head==spec['head'],label
 return receipt
before=observe('before')
if before['processes']:
 (folder/'launch-rejected.json').write_text(json.dumps({'reason':'competing heavy processes before launch','processes':before['processes'],'benchmark_launched':False,'baseline_accepted':False},indent=2));raise SystemExit('heavy processes present; benchmark not launched')
env=dict(os.environ,VK_DRIVER_FILES=f"/usr/share/vulkan/icd.d/{'lvp' if profile=='software' else 'radeon'}_icd.json",MARTENSITE_VULKAN_DEVICE='0',GALLIUM_OVERRIDE_CPU_CAPS='sse2',LP_NATIVE_VECTOR_WIDTH='128');env.pop('LLVM_TARGET_FEATURES',None);env.pop('VK_ICD_FILENAMES',None)
keys=('VK_ICD_FILENAMES','VK_DRIVER_FILES','MARTENSITE_VULKAN_DEVICE','GALLIUM_OVERRIDE_CPU_CAPS','LP_NATIVE_VECTOR_WIDTH','LLVM_TARGET_FEATURES','VK_LAYER_PATH','LD_LIBRARY_PATH','VK_INSTANCE_LAYERS','LP_NUM_THREADS','MESA_SHADER_CACHE_DIR','MESA_SHADER_CACHE_DISABLE')
selected={key:env.get(key) for key in keys};(folder/'environment.json').write_text(json.dumps(selected,indent=2))
command=['/usr/bin/time','-v','-o',str(folder/'peak-rss.log'),str(binary)]
with (folder/'raw.log').open('w') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
after=observe('after');rows=[json.loads(line.partition('=')[2]) for line in (folder/'raw.log').read_text().splitlines() if line.startswith('MARTENSITE_PERFORMANCE=')]
report={'profile':profile,'exit':result.returncode,'command':command,'environment':selected,'device_identity_lines':[line for line in (folder/'raw.log').read_text().splitlines() if line.startswith('MARTENSITE_DEVICE_IDENTITY=')],'workloads':rows,'baseline_accepted':False,'gpu_memory_measured':False,'idle_host_bookends':not before['processes'] and not after['processes']}
(folder/'report.json').write_text(json.dumps(report,indent=2));assert result.returncode==0,result.returncode;assert report['idle_host_bookends'],after['processes'];assert len(rows)==35 and len({row['workload'] for row in rows})==35
for row in rows:assert row['warmup']==20 and row['validation'] is False and len(row['samples_ms'])==100 and all(math.isfinite(value) and value>0 for value in row['samples_ms']),row['workload']
print(json.dumps({'profile':profile,'exit':result.returncode,'workloads':len(rows),'samples':sum(len(row['samples_ms']) for row in rows),'report':str(folder/'report.json')}),flush=True)
