import gzip,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path.cwd();candidate=root/'docs/evidence/prism-domain-topology-v2-2026-10-14';out=root/'docs/evidence/prism-domain-topology-integration-2026-10-14';base=candidate/'baseline'
def sha(blob):return hashlib.sha256(blob).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],text=True).split('\0') if p}
manifest=json.loads((candidate/'artifacts.json').read_text());
for name,expected in manifest['artifacts'].items():assert sha((candidate/name).read_bytes())==expected
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target'}
cases=[('topology','exact_topology_report_replays_across_threads_and_processes','frozen-topology-v1:',base/'topology-replay.bin.gz'),('publication','publication_process_replay','named-prism-publication-v1=',base/'publication.bin.gz'),('volume','joined_volume_process_replay','joined-volume-v1=',root/'docs/evidence/prism-joined-volume-v1/final/replay-1.bin.gz')]
rows=[]
for label,needle,marker,fixture in cases:
 for number in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',needle,'--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{label}-{number}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  matched=re.findall(re.escape(marker)+r'([0-9a-f]+)',p.stdout.decode());assert len(matched)==1;actual=bytes.fromhex(matched[0]);assert actual==gzip.decompress(fixture.read_bytes());(out/f'{label}-{number}.bin.gz').write_bytes(gzip.compress(actual,mtime=0));rows.append({'label':label,'process':number,'bytes':len(actual),'sha256':sha(actual)})
for label,cmd in [('docs',['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked']),('independent-ranks',['python3','docs/evidence/prism-domain-topology-v2-2026-10-14/verify_boundary_words.py'])]:
 p=subprocess.run(cmd,env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{label}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M))
prior=names(gzip.decompress((candidate/'final/integrated-tests.log.gz').read_bytes()));actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert prior<=actual
assert before==snapshot();(out/'supplement.json').write_text(json.dumps({'candidate_artifacts_verified':len(manifest['artifacts']),'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_unchanged':True,'prior_test_names_retained':len(prior),'new_test_names':sorted(actual-prior),'replays':rows,'scope':'Internal domain seam and test-only annular assumptions; no production V2 issuance or release acceptance.'},indent=2)+'\n');(out/'supplement-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('domain topology supplement passed',flush=True)
