from pathlib import Path
root=Path('crates/tkmath/src/predicates/roots/metric_bounds')
(root/'enclosure_sum').mkdir(exist_ok=True)
(root/'enclosure_sum.rs').write_text('''// SPDX-License-Identifier: GPL-2.0-only
//! ADR0031: exact endpoint addition, conditional on the supplied component enclosures.
mod arithmetic;
mod error;
mod types;
use super::super::certificate_arithmetic::{ExactRatio, rounding::outward_binary64};
pub use error::*;
pub use types::*;

/// Sum nonnegative enclosures without certifying their originating computations.
/// Empty input completes with zero; each finite endpoint denotes its exact binary64 value.
/// Example: `sum_nonnegative_enclosures(&[[1., 2.]], Default::default(), || false)?`.
pub fn sum_nonnegative_enclosures(
    components: &[[f64; 2]],
    options: EnclosureSumOptions,
    mut cancelled: impl FnMut() -> bool,
) -> Result<CertifiedEnclosureSum, EnclosureSumError> {
    let result = arithmetic::sum(components, options, &mut cancelled);
    result.map_err(|cause| EnclosureSumError {
        operation: EnclosureSumOperation::NonnegativeBounds,
        requested_options: options,
        cause,
    })
}
fn checkpoint(cancelled: &mut impl FnMut() -> bool) -> Result<(), EnclosureSumCause> {
    if cancelled() {
        return Err(EnclosureSumCause::Cancelled);
    }
    Ok(())
}
#[cfg(test)]
mod tests;
''')
(root/'enclosure_sum/types.rs').write_text('''// SPDX-License-Identifier: GPL-2.0-only
/// Finite endpoint-sum policy; no component budget is allocated or changed.
/// Example: `EnclosureSumOptions { absolute_error_limit: 1e-4, ..Default::default() }`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct EnclosureSumOptions {
    /// Supported additive behavior version, currently one.
    pub behavior_version: u32,
    /// Maximum input component count, at most 64; zero admits only an empty sum.
    pub max_components: u16,
    /// Finite nonnegative full-width error cap, in the components' common units.
    pub absolute_error_limit: f64,
}
impl Default for EnclosureSumOptions {
    fn default() -> Self {
        Self { behavior_version: 1, max_components: 64, absolute_error_limit: 1e-4 }
    }
}
/// Typed identity of the conditional arithmetic operation.
/// Example: `let operation = EnclosureSumOperation::NonnegativeBounds;`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EnclosureSumOperation {
    /// Exact lower/upper addition and final outward rounding; input claims are external.
    NonnegativeBounds,
}
/// Immutable owned sum; component intervals retain their supplied bits and order.
/// This certifies endpoint arithmetic only, not that components enclose physical quantities.
/// Example: `assert!(report.absolute_error_bound() <= report.requested_options().absolute_error_limit);`.
#[derive(Clone, Debug, PartialEq)]
pub struct CertifiedEnclosureSum {
    pub(super) components: Vec<[f64; 2]>,
    pub(super) enclosure: [f64; 2],
    pub(super) error: f64,
    pub(super) options: EnclosureSumOptions,
}
impl CertifiedEnclosureSum {
    /// Read unchanged component endpoints; `let supplied = report.components();`.
    pub fn components(&self) -> &[[f64; 2]] {
        // Borrowing this owned slice cannot mutate the report or original input.
        &self.components
    }
    /// Read the certified sum enclosure; `let [lower, upper] = report.enclosure();`.
    pub fn enclosure(&self) -> [f64; 2] {
        // Both endpoint roundings are included in the published width.
        self.enclosure
    }
    /// Read the deterministic lower representative; `let value = report.representative();`.
    pub fn representative(&self) -> f64 {
        // A fixed endpoint avoids an additional unreported midpoint rounding.
        self.enclosure[0]
    }
    /// Read the upward-rounded full width; `let error = report.absolute_error_bound();`.
    pub fn absolute_error_bound(&self) -> f64 {
        // The width includes child uncertainty and final sum rounding.
        self.error
    }
    /// Read original limits; `let requested = report.requested_options();`.
    pub fn requested_options(&self) -> EnclosureSumOptions {
        // Policy admission never substitutes a child or total budget.
        self.options
    }
    /// Read unchanged applied limits; `let effective = report.effective_options();`.
    pub fn effective_options(&self) -> EnclosureSumOptions {
        // There are no implicit clamps or adaptive retries in this operation.
        self.options
    }
    /// Identify conditional endpoint arithmetic; `let kind = report.operation();`.
    pub fn operation(&self) -> EnclosureSumOperation {
        // Component provenance remains the caller's separate proof obligation.
        EnclosureSumOperation::NonnegativeBounds
    }
}
''')
(root/'enclosure_sum/error.rs').write_text('''// SPDX-License-Identifier: GPL-2.0-only
use super::{EnclosureSumOperation, EnclosureSumOptions};
/// Typed refusal retaining requested policy; no partial successful sum is returned.
/// Example: `let operation = error.operation;`.
#[derive(Clone, Debug, PartialEq)]
pub struct EnclosureSumError {
    /// Arithmetic operation that could not complete.
    pub operation: EnclosureSumOperation,
    /// Original policy, including invalid values.
    pub requested_options: EnclosureSumOptions,
    /// Exact stage and offending supplied value or bound.
    pub cause: EnclosureSumCause,
}
/// Reasons a finite conditional enclosure sum is incomplete.
/// Example: `matches!(error.cause, EnclosureSumCause::Cancelled)`.
#[derive(Clone, Debug, PartialEq)]
pub enum EnclosureSumCause {
    /// Version must be one, count cap at most 64, and error cap finite/nonnegative.
    Policy(EnclosureSumOptions),
    /// Input count exceeds the unchanged requested maximum.
    ComponentCount { actual: usize, maximum: u16 },
    /// Component must have finite ordered endpoints with lower at least zero.
    Component { index: usize, supplied: [f64; 2] },
    /// Exact nonnegative endpoint or width cannot be enclosed by finite binary64.
    Unrepresentable { quantity: &'static str, exact_value: String },
    /// Complete outward width exceeds the original finite cap.
    ErrorLimit { requested: f64, achieved: f64 },
    /// Caller requested cancellation; subsequent reuse starts from empty local state.
    Cancelled,
}
''')
(root/'enclosure_sum/arithmetic.rs').write_text('''// SPDX-License-Identifier: GPL-2.0-only
use super::*;
type SumResult<T> = Result<T, EnclosureSumCause>;

pub(super) fn sum(
    components: &[[f64; 2]],
    options: EnclosureSumOptions,
    cancelled: &mut impl FnMut() -> bool,
) -> SumResult<CertifiedEnclosureSum> {
    checkpoint(cancelled)?;
    admit(components.len(), options)?;
    let bounds = accumulate(components, cancelled)?;
    let enclosure = [rounded(&bounds[0], "sum lower")?[0], rounded(&bounds[1], "sum upper")?[1]];
    let width = ExactRatio::from_finite(enclosure[1]).subtract(&ExactRatio::from_finite(enclosure[0]));
    let error = rounded(&width, "sum width")?[1];
    require_error(error, options.absolute_error_limit)?;
    checkpoint(cancelled)?;
    Ok(CertifiedEnclosureSum { components: components.to_vec(), enclosure, error, options })
}
fn admit(count: usize, options: EnclosureSumOptions) -> SumResult<()> {
    if options.behavior_version != 1 || options.max_components > 64
        || !options.absolute_error_limit.is_finite() || options.absolute_error_limit < 0.
    {
        return Err(EnclosureSumCause::Policy(options));
    }
    if count > usize::from(options.max_components) {
        return Err(EnclosureSumCause::ComponentCount { actual: count, maximum: options.max_components });
    }
    Ok(())
}
fn accumulate(components: &[[f64; 2]], cancelled: &mut impl FnMut() -> bool) -> SumResult<[ExactRatio; 2]> {
    let mut sum = [ExactRatio::from_finite(0.), ExactRatio::from_finite(0.)];
    for (index, supplied) in components.iter().copied().enumerate() {
        checkpoint(cancelled)?;
        require_component(index, supplied)?;
        sum[0] = sum[0].add(&ExactRatio::from_finite(supplied[0]));
        sum[1] = sum[1].add(&ExactRatio::from_finite(supplied[1]));
    }
    Ok(sum)
}
fn require_component(index: usize, supplied: [f64; 2]) -> SumResult<()> {
    if supplied.iter().any(|value| !value.is_finite()) || supplied[0] < 0. || supplied[0] > supplied[1] {
        return Err(EnclosureSumCause::Component { index, supplied });
    }
    Ok(())
}
fn rounded(exact: &ExactRatio, quantity: &'static str) -> SumResult<[f64; 2]> {
    outward_binary64(exact).ok_or_else(|| EnclosureSumCause::Unrepresentable {
        quantity, exact_value: format!("{exact:?}"),
    })
}
fn require_error(achieved: f64, requested: f64) -> SumResult<()> {
    if achieved > requested {
        return Err(EnclosureSumCause::ErrorLimit { requested, achieved });
    }
    Ok(())
}
''')
p=root.parent/'metric_bounds.rs';p.write_text(p.read_text()+'''\nmod enclosure_sum;\npub use enclosure_sum::{CertifiedEnclosureSum, EnclosureSumCause, EnclosureSumError,\n    EnclosureSumOperation, EnclosureSumOptions, sum_nonnegative_enclosures};\n''')
