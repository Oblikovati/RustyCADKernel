import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-release-ref-maintenance')
out=Path('/tmp/martensite-release-ref-checks')
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','tools','.githooks'],cwd=root).decode().split('\0')
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if n}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True)+'\n')
commands=[['python3','-m','unittest','discover','-s','tools/tests','-p','test_release_*.py','-v'],['python3','tools/run_tool_tests.py','--jobs','2','--pattern','test_pre_release*.py'],['python3','-m','unittest','discover','-s','tools/tests','-p','test_verify_release_gate.py','-v'],[str(out/'format-env/bin/python'),'-m','black','--check','tools/release_tag_guard.py','tools/tests/test_release_tag_guard.py','tools/tests/test_release_ref_maintenance.py']]
rows=[]
for i,command in enumerate(commands):
 start=time.monotonic();log=out/f'frozen-{i}.log'
 with log.open('w') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 rows.append({'command':command,'exit_code':r.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'seconds':time.monotonic()-start})
 print(json.dumps(rows[-1]),flush=True)
 if r.returncode:break
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True)+'\n')
receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'commands':rows,'source_count':len(before),'source_unchanged':before==after}
(out/'frozen.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert before==after
assert len(rows)==len(commands) and all(r['exit_code']==0 for r in rows)
