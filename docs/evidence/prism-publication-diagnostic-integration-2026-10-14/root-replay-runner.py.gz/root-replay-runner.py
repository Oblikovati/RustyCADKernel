import ast,gzip,hashlib,json,os,subprocess,tarfile
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/prism-publication-diagnostic-integration-2026-10-14';raw=root/'target/prism-publication-diagnostic-integration-replay';raw.mkdir(exist_ok=True)
exe=root/'target/two-loop-integrated-cold/debug/deps/rustycad_tkbo-3743221922cb8a91'
assert exe.exists()
base=root/'docs/evidence/prism-body-view-v1/actual-checkpoint'
probes=[('body','publication::body_view::actual_replay_tests::actual_body_process_receipt',None),('symbolic','publication::body_view::row_replay_tests::symbolic_body_row_process_replay','SYMBOLIC_BODY_ROWS='),('publication','publication::replay_tests::publication_process_replay','named-prism-publication-v1='),('map','owned_request::names::body_map::tests::semantic_map_replay_probe','SEMANTIC_MAP_REPLAY='),('frozen','frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('ordered','frozen::ordered_validation::replay_tests::ordered_validation_process_receipt','ordered-validation-v1:'),('joined-measures','frozen::joined_measures::tests::replay_tests::joined_measure_process_replay','joined-measures-v1='),('complete-measures','region_certificate::measurements::tests::complete_tests::replay_tests::complete_prism_measure_process_receipt','{"operation":'),('resolver','owned_request::resolver::replay_tests::actual_resolver_process_replay','actual-semantic-resolver-v2=')]
def digest(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0')
 return {p:digest((root/p).read_bytes()) for p in names if p}
before=snapshot();rows=[]
with tarfile.open(root/'docs/evidence/prism-actual-semantic-resolver-v2/final/checks.tar.gz') as archive:
 resolver=archive.extractfile('frozen/actual-replay-1.bin').read()
for name,test,marker in probes:
 expected=resolver if name=='resolver' else gzip.decompress((base/(name+'-1.bin.gz')).read_bytes())
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
  env={**os.environ,'MARTENSITE_ACTUAL_BODY_RECEIPT':str(path)}
  cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();assert result.returncode==0 and '1 passed;' in text,label
  if marker:
   line=next(line[line.index(marker):] for line in text.splitlines() if marker in line)
   payload=bytes(ast.literal_eval(line[len(marker):])) if name=='map' else line.encode() if name=='complete-measures' else bytes.fromhex(line[len(marker):])
  else:payload=path.read_bytes()
  assert payload==expected,(label,'candidate full-byte mismatch')
  payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
  (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
with tarfile.open(root/'docs/evidence/prism-diagnostic-envelope-v1-2026-10-14/publication-adapter-frozen.tar.gz') as archive:
 source=archive.extractfile('publication-diagnostic-frozen/replay.py').read().decode()
 start=source.index('specs = ['); end=source.index('expected = {')
 namespace={};exec(source[start:end],namespace)
 for name,test,form,marker in namespace['specs']:
  expected=archive.extractfile('publication-diagnostic-frozen/'+name+'-0.bin').read()
  payloads=[]
  for ordinal in (1,2):
   label=f'root-diagnostic-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
   env={**os.environ}
   if form=='env':env[marker]=str(path)
   cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
   with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
   content=log.read_text();assert result.returncode==0 and '1 passed;' in content,label
   if form=='env':payload=path.read_bytes()
   else:
    line=next(line[line.index(marker)+len(marker):] for line in content.splitlines() if marker in line)
    payload=bytes(ast.literal_eval(line)) if form=='list' else bytes.fromhex(line)
   assert payload==expected,(label,'candidate full-byte mismatch')
   payloads.append(payload)
   (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
   (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
  assert payloads[0]==payloads[1]
  row={'name':'diagnostic-'+name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
after=snapshot();assert before==after
(out/'root-replay-source.json.gz').write_bytes(gzip.compress(json.dumps({'before':before,'after':after},sort_keys=True).encode(),mtime=0))
(out/'root-replays.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'executable_sha256':digest(exe.read_bytes()),'source_unchanged':True,'replays':rows},indent=2)+'\n')
(out/'root-replay-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
