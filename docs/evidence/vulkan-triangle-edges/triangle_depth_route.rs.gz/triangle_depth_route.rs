//! Bounded diagnostic isolates actual retained source and polygon-edge depth producers.
#[path = "support/device_options.rs"]
mod device_options;
#[allow(dead_code)]
#[path = "../tests/support/capping_texture_scene.rs"]
mod capping_scene;
#[allow(dead_code)]
#[path = "../tests/support/viewer_scene.rs"]
mod scene;
#[allow(dead_code)]
#[path = "../tests/support/surface_texture_scene.rs"]
mod texture_scene;
#[allow(dead_code)]
#[path = "../tests/support/view_setup.rs"]
mod view_setup;
#[path = "../tests/support/recording_device.rs"]
mod recording_device;
use martensite_vulkan::*;
use rustycad_tkservice::{graphic3d::*, image::ImagePixMap};
use rustycad_tkv3d::v3d::V3dImageDumpOptions;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let with = source_frame("cap-oblique-source-edges-dashed-fill-offset");
    let without = source_frame("cap-oblique-source-edges-disabled-fill-offset");
    println!("{{\"first_source_equal\":{},\"with_draw_count\":{},\"without_draw_count\":{}}}", with.draws()[0] == without.draws()[0], with.draws().len(), without.draws().len());
    eprintln!("{:#?}", with.draws()[3]);
    let mut renderer = VulkanRenderer::new(device_options::validation_options())?;
    for count in [1, 2, 4] {
        let frame = RenderFrame::new(64, 64, [0., 0., 1., 1.], with.draws()[..count].to_vec())?;
        renderer.render(&frame)?;
        let capture = renderer.render(&frame)?;
        println!("{{\"draw_count\":{count},\"zero_depth\":{}}}", capture.depth.iter().filter(|value| **value == 0.).count());
    }
    assert!(renderer.validation_errors().is_empty(), "{:?}", renderer.validation_errors());
    Ok(())
}
fn source_frame(mode: &str) -> RenderFrame {
    let recorder = TracingDevice::new();
    let limit = 128;
    let driver = Graphic3dRenderDriver::with_backend(recorder.clone(), limit).unwrap();
    let fixture = capping_scene::CappingTextureScene::new(&driver, mode);
    fixture.scene.render_view().try_redraw().unwrap();
    let options = V3dImageDumpOptions { width:64, height:64, to_adjust_aspect:false,
        target_z_layer_id:GRAPHIC3D_ZLAYER_ID_DEFAULT, is_single_layer:true, ..Default::default() };
    fixture.scene.view.to_pix_map(&ImagePixMap::default(), &options).unwrap();
    fixture.scene.view.remove();
    recorder.frames.lock().unwrap().last().unwrap().clone()
}

#[derive(Clone)]
struct TracingDevice {
    renderer: std::sync::Arc<std::sync::Mutex<VulkanRenderer>>,
    frames: std::sync::Arc<std::sync::Mutex<Vec<RenderFrame>>>,
}
impl TracingDevice {
    fn new() -> Self {
        Self { renderer:std::sync::Arc::new(std::sync::Mutex::new(VulkanRenderer::new(device_options::validation_options()).unwrap())),
            frames:Default::default() }
    }
}
impl RenderBackend for TracingDevice {
    fn render(&mut self, frame: &RenderFrame) -> Result<FrameCapture, RenderError> {
        self.frames.lock().unwrap().push(frame.clone());
        let capture = self.renderer.lock().unwrap().render(frame)?;
        println!("{{\"actual_view_zero_depth\":{}}}", capture.depth.iter().filter(|value| **value == 0.).count());
        Ok(capture)
    }
}
