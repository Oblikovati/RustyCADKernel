# Unvalidated continuation draft

This directory is preparation for the next porting batch, not compiled production
code and not included in the API inventory. The validated continuation remains
`/tmp/rustycad-resume` on `porting/resume-claude`.

- `frustum.rs` is Claude's untouched algorithmic content, formatted, recovered from
  `.claude/worktrees/agent-aa64fda07fced1190/crates/tkv3d/src/select_mgr/frustum.rs`.
  The original remains unchanged. It covers box/point/segment/polygon/triangle SAT.
- `frustum_quadric_geometry.rs`, `frustum_sphere.rs`, `frustum_cylinder.rs` and
  `frustum_circle.rs` draft the missing native routines against
  OCCT `3d097a0328e71b826377d4814ab05ec3c3d23871`,
  `src/Visualization/TKV3d/SelectMgr/SelectMgr_Frustum.lxx` lines 460–872.
- No tests or API claims exist for these drafts. They need compilation, review,
  behavior tests and exact native differential probes before inventory claims.

Before importing: export the core and wire modules; make `inc_factor` visible to
sibling implementations; split/refactor long functions; enforce the core's shape
invariants and make projection errors include the offending bounds. Native template
arrays have fixed dimensions; do not permit malformed Vec state to panic silently.
The native sphere helper evaluates only side planes and refines a projected polygon
when no inside output is requested. Keep native edge order, output-flag updates,
virtual boundary/ray calls, and arithmetic, including the untransformed circle center.

The old triangle helper returns a RealLast sentinel when native leaves the caller's
normal untouched. Expose an output-argument or optional-normal form that preserves
that behavior; do not claim it until the oracle verifies both early and late returns.
`DumpJson` is still missing. It needs a matching readable native stream, and explicit
canonicalization of unavoidable camera/builder addresses while checking their
identity relationships separately. Do not normalize any numeric fields.

Use named native subclasses of rectangular and triangular frustums to expose
protected SAT methods and initialize equivalent planes, vertices, projections and
edge directions. Test both N=3 and N=4, orthographic/perspective paths, inside outputs
initialized both ways and null, degeneracy/exception paths, transformed quadrics,
filled/hollow modes, and normal output preservation. The concrete selecting-volume
build/transform/overlap algorithms remain a later requirement.
