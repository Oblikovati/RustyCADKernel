import gzip,hashlib,json,os,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd(); raw=root/'target/gui-surface-outcomes-integrated-main'
out=root/'docs/evidence/gui-surface-outcomes-v2-2026-10-14'
receipt=json.loads((raw/'receipt.json').read_text())
assert receipt['source_bookends_equal'] and receipt['two_process_host_bytes_equal']
assert all(row.get('exit')==0 for row in receipt['runs'])
files=json.loads((raw/'candidate-file-comparison.json').read_text()); assert all(files.values())
for name in files:
 assert (root/name).read_bytes()==subprocess.check_output(['git','show','89d2c0a1e:'+name]),name
for name,expected in json.loads((raw/'source-after.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
counts={}
for driver in ['amd','lavapipe']:
 rows=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (raw/(driver+'-full.log')).read_text())
 counts[driver]={key:sum(int(row[i]) for row in rows) for i,key in enumerate(['passed','failed','ignored'])}
 assert counts[driver]=={'passed':836,'failed':0,'ignored':6}
 assert (raw/(driver+'-phases.log')).read_text().count('"status":"passed"')==12
capture_checks={}
with tarfile.open(out/'raw.tar.gz','r:gz') as archive:
 for member in archive.getmembers():
  prefix='gui-surface-outcomes/final/'
  if not member.isfile() or not member.name.startswith(prefix): continue
  name=member.name[len(prefix):]
  if pathlib.Path(name).suffix not in ['.depth','.ppm','.rgba']: continue
  actual=(raw/name).read_bytes(); expected=archive.extractfile(member).read()
  assert actual==expected,name
  capture_checks[name]=hashlib.sha256(actual).hexdigest()
assert len(capture_checks)==174,len(capture_checks)
links={str(p.relative_to(raw)):os.readlink(p) for p in (raw/'checker-input').iterdir()};assert len(links)==9
(raw/'integrated-capture-comparison.json').write_text(json.dumps({'matches_candidate':True,'captures':capture_checks,'checker_links':links},indent=2)+'\n')
manifest={}
archive_path=out/'integrated-raw.tar.gz'
with archive_path.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as archive:
 for path in sorted(raw.rglob('*')):
  if path.is_symlink() or not path.is_file(): continue
  name=str(path.relative_to(raw));payload=path.read_bytes();manifest[name]=hashlib.sha256(payload).hexdigest()
  info=archive.gettarinfo(str(path),arcname='integrated/'+name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with path.open('rb') as item: archive.addfile(info,item)
summary={'integration_revision':receipt['source_revision'],'candidate_source':'89d2c0a1e8b82bbad69de4c2ea62c5031bc24b32','candidate_evidence_tip':'216845a08','checks_passed':True,'full_suites':counts,'native_phase_cases_per_driver':12,'candidate_crate_tool_files_match':files,'candidate_capture_bytes_match':capture_checks,'source_bookends_equal':True,'two_process_host_bytes_equal':True,'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'archive_files':manifest,'limitations':['Five existing ignored tests remain excluded; new ignored native phase gate separately executed.','ThreadSanitizer startup failed before main; GUI sanitizer suite unexecuted.','Timing is paired debug/shared-host observation, not controlled previous-release performance.','No application acceptance, release, default-policy migration, or full API parity claim.']}
(out/'integrated-main.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':True,'capture_files':len(capture_checks),'archived_files':len(manifest),'full_suites':counts}))
