from pathlib import Path
root=Path('crates/tkbo/src/sketch_region_prism/region_certificate/measurements/tests/complete')
p=root/'policy.rs';s=p.read_text();a=s.index('    let CompletePrismMeasureFailure::Side {');b=s.index('\n#[test]',a);old=s[a:b];x=old.index('    let snapshot =');s=s[:a]+'''    let keys = side_error_keys(failure, policy.side_area);
    assert_current_side_keys(&bridge, &shapes, &receipt, keys);
}
'''+s[b:];s+='''
fn side_error_keys(failure: CompletePrismMeasureFailure, expected: PolynomialSideOptions)
    -> (crate::sketch_region::PartitionOccurrenceIdentity, crate::sketch_region::PartitionOccurrenceIdentity) {
'''+old[:x].replace('policy.side_area','expected')+'''    (source, output)
}
fn assert_current_side_keys(bridge: &PairedContactTransaction, shapes: &[Shape], receipt: &PrismReceipt,
    keys: (crate::sketch_region::PartitionOccurrenceIdentity, crate::sketch_region::PartitionOccurrenceIdentity)) {
'''+old[x:].replace('&bridge, &binding_sources(&shapes), &receipt','bridge, &binding_sources(shapes), receipt').replace('assert_eq!(source, chart.source);','assert_eq!(keys.0, chart.source);').replace('assert_eq!(output, chart.output);','assert_eq!(keys.1, chart.output);')
s=s.replace('    policy = fast_options();\n    policy.subset.cap_area', '''}
#[test]
fn cap_failure_quantity_remains_original_subset_error() {
    let (bridge, shapes) = fixture();
    let receipt = run(&bridge, &shapes);
    let mut policy = fast_options();
    policy.subset.cap_area''');p.write_text(s)
p=root/'mutation.rs';s=p.read_text();a=s.index('    use rustycad_tkbrep::brep::BRepTool;',s.index('fn actual_side_direction'));b=s.index('    let failure =',a);s=s[:a]+'''    let (bridge, shapes) = fixture();
    let receipt = run(&bridge, &shapes);
    redirect_side_direction(&receipt);
'''+s[b:];s+='''
fn redirect_side_direction(receipt: &PrismReceipt) {
    use rustycad_tkbrep::brep::BRepTool;
    use rustycad_tkg3d::geom::GeomSurfaceOfLinearExtrusion;
    let side = live_face(receipt, PrismImageRole::Generated);
    let raw = BRepTool::surface(&side).unwrap().cast::<GeomSurfaceOfLinearExtrusion>();
    raw.set_direction(rustycad_tkmath::gp::Direction3::new(1., 0., 0.).unwrap());
}
''';p.write_text(s)
p=root/'domain.rs';s=p.read_text();a=s.index('        let expected_side =');b=s.index('\n    }',a);chunk=s[a:b];s=s[:a]+'        assert_scaled_measure(&report, scale, height);'+s[b:];s+='''
fn assert_scaled_measure(report: &CompletePrismMeasureInspection, scale: f64, height: f64) {
'''+chunk+'\n}\n';p.write_text(s)
p=root/'replay.rs';s=p.read_text();a=s.index('    let mut polls = 0;',s.index('fn complete_cancellation'));b=s.index('    for cutoff in',a);s=s[:a]+'    let (report, polls) = report_with_poll_count(&bridge, &shapes, &receipt);\n'+s[b:];a=s.index('        let mut current = 0;',s.index('fn complete_cancellation'));b=s.index('\n    }',a);chunk=s[a:b];s=s[:a]+'        assert_cancel_cutoff(&bridge, &shapes, &receipt, cutoff, polls);'+s[b:];s+='''
fn report_with_poll_count(bridge: &PairedContactTransaction, shapes: &[Shape], receipt: &PrismReceipt)
    -> (CompletePrismMeasureInspection, usize) {
    let mut polls = 0;
    let report = full_attempt(bridge, shapes, receipt, fast_options(), || { polls += 1; false }).ok().unwrap();
    (report, polls)
}
fn assert_cancel_cutoff(bridge: &PairedContactTransaction, shapes: &[Shape], receipt: &PrismReceipt,
    cutoff: usize, polls: usize) {
'''+chunk.replace('&bridge, &shapes, &receipt','bridge, shapes, receipt')+'\n}\n'
a=s.index('fn assert_cancel_stage');b=s.index('\nfn report_with_poll_count',a);s=s[:a]+'''fn assert_cancel_stage(cutoff: usize, final_poll: usize, error: CompletePrismMeasureFailure) {
    // v1 total polls once before, three components, once after; outer binding polls once.
    match final_poll - cutoff {
        6 => assert!(matches!(error, CompletePrismMeasureFailure::Side { cause, .. }
            if matches!(*cause.cause, PolynomialSideFailure::Cancelled))),
        5 => assert!(matches!(error, CompletePrismMeasureFailure::Total(EnclosureSumError {
            cause: EnclosureSumCause::Cancelled, .. }))),
        _ => assert!(matches!(error, CompletePrismMeasureFailure::Binding(PrismBindingFailure::Cancelled))),
    }
}
'''+s[b:];p.write_text(s)
