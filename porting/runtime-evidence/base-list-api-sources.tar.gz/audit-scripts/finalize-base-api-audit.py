import collections,gzip,hashlib,json,pathlib,re,subprocess,tarfile
root=pathlib.Path('/tmp/rustycad-base-api-reconciliation')
main=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
summary_path=root/'porting/audits/base-list-api-reconciliation.json'
summary=json.loads(summary_path.read_text())
rows=[json.loads(l) for l in (root/summary['artifacts']['matrix']['path']).read_text().splitlines()]
catalog=[json.loads(l) for l in (root/summary['artifacts']['rust_body_catalog']['path']).read_text().splitlines()]
results=json.load(open('/tmp/base-api-check-results.json'))
assert all(s['exit_code']==0 for s in results)
for step in results:
    source=pathlib.Path(step['log']);dest=root/'porting/runtime-evidence'/('base-list-api-'+step['stage']+'.gz')
    dest.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
    step['log']={'path':str(dest.relative_to(root)),'sha256':sha(dest),'uncompressed_sha256':sha(source)}
summary['checks']={'commands':results,'rust_passed':sum(int(m) for m in re.findall(r'test result: ok\. (\d+) passed',pathlib.Path('/tmp/base-api-rust.log').read_text())),'native_rows':{scope:len(pathlib.Path('/tmp/base-api-'+scope+'-run.log').read_text().splitlines()) for scope in ['storage','basic_iterator']},'native_expected_bytes_equal':True,'full_workspace_tests_rerun':False,'runtime_scope_note':'Existing 23 focused tests and 28 native oracle rows were re-run unchanged. Related fixture success does not establish per-declaration complete behavior, ABI, all instantiations, or new original legacy test credit.'}
assert summary['checks']['rust_passed']==23
sources=set(c['source_file'] for c in catalog)
for scope in ['storage','basic_iterator']:
    sources.update(['crates/tkernel/tests/base_list_'+scope+'_contracts.rs','crates/tkernel/tests/base_list_'+scope+'_contracts/fixture.rs','tools/oracle/tkernel_base_list_'+scope+'_contracts.cxx','tools/oracle/tkernel_base_list_'+scope+'_contracts.expected'])
sources.update(str(p.relative_to(root)) for p in (root/'crates/tkernel/src/ncollection/base_list').rglob('*.rs'))
sources.update(['crates/tkernel/src/ncollection/list.rs','crates/tkernel/src/ncollection/list/iteration.rs','crates/tkernel/src/ncollection/list/topology.rs','crates/tkernel/src/ncollection/list/cursor_state.rs'])
summary['audited_source_sha256']={p:sha(root/p) for p in sorted(sources)}
summary['evidence_groups']={
 'storage':{'receipts':['porting/audits/base-list-storage-method-contracts.json'],'native_fixture':'tools/oracle/tkernel_base_list_storage_contracts.cxx','rust_fixture':'crates/tkernel/tests/base_list_storage_contracts.rs','domain':'Raw externally owned valid nodes, native pointer/callback ordering, transfer, allocator identity, count and empty-position errors. Aliasing self append/prepend is spelled splice_self in Rust. Native allocation macro/ABI/noexcept and arbitrary forged raw state closure remain open.'},
 'basic':{'receipts':['porting/audits/base-list-basic-iterator-method-contracts.json'],'native_fixture':'tools/oracle/tkernel_base_list_basic_iterator_contracts.cxx','rust_fixture':'crates/tkernel/tests/base_list_basic_iterator_contracts.rs','domain':'Custom writable/read-only nodes, nonzero embedded link offset, explicit caller lifetime/alias obligations; C++ IsConstant is the inverse of Rust MUTABLE. Native const member mutable access becomes &mut self; no safe STL trait adapter or all-template/alias closure claimed.'},
 'field':{'domain':'Compiler-visible public fields replace native public/protected slots through Rust composition. No binary-layout or inheritance ABI equivalence claim.'},
 'nominal':{'domain':'Compiler-visible base storage/raw iterator/generic cursor types. Generic bounds, inherited name visibility, allocator handle semantics and layout still require full-domain proof.'}}
summary['historical_receipt_findings']=[
 {'path':'porting/audits/base-list-storage-method-contracts.json','finding':'partial_uncommitted_draft is historical metadata although code/artifact is now integrated. The generic candidate lists sometimes include both constructor forms or both pointer mutabilities; this matrix selects exact native records independently.'},
 {'paths':['porting/audits/base-list-storage-method-contracts.json','porting/audits/base-list-basic-iterator-method-contracts.json'],'finding':'Their statement that typed List retains an independent node engine is stale: current list.rs delegates allocator/count/empty queries through BaseListStorage and ListTopology stores BaseListStorage. Historical runtime artifacts remain scoped to their source hashes.'},
 {'path':'porting/audits/base-list-cursor-selectors.json','finding':'Its statement that ListCursor has a sole address field is stale after predecessor state was introduced. Current equality is explicit address-only; exact base-surface replacements are recorded separately.'}]
summary['historical_receipt_source_freshness']={}
for filename in ['base-list-storage-method-contracts.json','base-list-basic-iterator-method-contracts.json']:
 receipt_path=root/'porting/audits'/filename;receipt=json.loads(receipt_path.read_text())
 hashes=receipt.get('source_sha256',{})
 summary['historical_receipt_source_freshness'][filename]={'receipt_sha256':sha(receipt_path),'matching_source_hashes':[p for p,h in hashes.items() if (root/p).is_file() and sha(root/p)==h],'changed_or_missing_source_hashes':[p for p,h in hashes.items() if not (root/p).is_file() or sha(root/p)!=h]}
summary['next_porting_actions']=[
 {'priority':1,'action':'Root serially validate and apply the 63 exact partial rows: replace 13 typed-facade implementation claims and add 50 missing links. Keep all statuses partial, with zero implemented-parity credit.'},
 {'priority':2,'action':'Add explicit compiler impl-context selection for six Init/Initialize/constructor overloads and three conditional accessors; do not arbitrarily pick a same-path specialization. Matrix already records exact bodies and the C++/Rust boolean inversion.'},
 {'priority':3,'action':'Audit a shared Rust object-allocation surface for all eight DEFINE_STANDARD_ALLOC/DEFINE_NCOLLECTION_ALLOC declarations, including allocator placement new/delete and failure cleanup. Existing node allocation is not a proof of BaseList object allocation.'},
 {'priority':4,'action':'Prove destructor member-drop ordering and the five native iterator aliases/trait obligations. Keep destructor exclusion and alias gaps explicit until language-equivalence evidence exists.'},
 {'priority':5,'action':'Reconcile BaseSequence and BaseMap separately with the same exact-ID/body/partial-domain discipline; this audit grants them no coverage.'}]
summary['limitations']=['This is a complete reconciliation of the captured BaseList records, not proof that compiler capture has a complete platform/configuration denominator.','The 19 api_visible=false records remain present and receive no separate candidate credit. Template wrapper and underlying method records are not collapsed.','A compiler body and source hash prove an implementation exists; fixture success proves only the exercised cases. All recommended ledger changes remain partial.','Two operator!= records use the standard PartialEq default, whose body is not a project-defined compiler path in this capture. No direct ne-body credit is granted.','No shared ledger or published inventory is edited by this branch.']
include=main/'target/occt-modeling-full/include/opencascade/NCollection_BaseList.hxx'
resolved_header=pathlib.Path(re.search(r'#include \"([^\"]+)\"',include.read_text()).group(1))
assert sha(resolved_header)==summary['native_header']['sha256']
summary['native_toolchain']={'g++':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'include_wrapper_sha256':sha(include),'compiled_header_path':str(resolved_header),'compiled_header_sha256':sha(resolved_header),'library_path':'target/occt-modeling-full/lin64/gcc/libi/libTKernel.so','library_sha256':sha(main/'target/occt-modeling-full/lin64/gcc/libi/libTKernel.so')}
archive=root/'porting/runtime-evidence/base-list-api-sources.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(sources):tar.add(root/path,arcname=path)
 tar.add('/tmp/reconcile-base-list.py',arcname='audit-scripts/reconcile-base-list.py')
 tar.add('/tmp/check-base-api-evidence.py',arcname='audit-scripts/check-base-api-evidence.py')
 tar.add('/tmp/finalize-base-api-audit.py',arcname='audit-scripts/finalize-base-api-audit.py')
summary['artifacts']['source_archive']={'path':str(archive.relative_to(root)),'sha256':sha(archive)}
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
assert len(summary_path.read_text().splitlines())<500
print(json.dumps({'checks':summary['checks'],'source_files':len(sources),'summary_lines':len(summary_path.read_text().splitlines())},indent=2))
