import re,subprocess,pathlib,hashlib,json,time
root=pathlib.Path('target/semantic-resolver-final')
log=(root/'tests.log').read_text()
match=re.search(r'Running unittests src/lib.rs \((target/debug/deps/rustycad_tkbo-[^)]+)\)',log)
assert match, 'compiled frozen TKBO unit-test executable must be observed first'
binary=pathlib.Path(match[1]); executable_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
reports=[];payloads=[]
for index in [1,2]:
 output=root/f'actual-replay-{index}.log'
 cmd=[str(binary),'actual_resolver_process_replay','--nocapture']
 with output.open('wb') as stream: run=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 assert run.returncode==0
 payload=bytes.fromhex(re.search(r'actual-semantic-resolver-v2=([0-9a-f]+)',output.read_text())[1])
 (root/f'actual-replay-{index}.bin').write_bytes(payload)
 reports.append({'command':cmd,'status':run.returncode,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()});payloads.append(payload)
assert payloads[0]==payloads[1]
assert executable_hash==hashlib.sha256(binary.read_bytes()).hexdigest()
(root/'replays.json').write_text(json.dumps({'executable':str(binary),'executable_sha256':executable_hash,'processes':reports,'equal':True},indent=2))
print('Exact independent processes',reports[0]['bytes'],reports[0]['sha256'])
