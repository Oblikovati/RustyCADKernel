use rustycad_tkernel::ncollection::{BoundingNode, BoundingVolume, ObjBnd, UBTree, EBTree, HashKey};
use std::panic::{UnwindSafe, RefUnwindSafe};
#[derive(Clone)] struct Bounds;
impl BoundingVolume for Bounds {
    fn add(&mut self, _: &Self) {}
    fn is_out(&self, _: &Self)->bool { false }
    fn square_extent(&self)->f64 { 0.0 }
}
fn traits<T: Send+Sync+Unpin+UnwindSafe+RefUnwindSafe>() {}
fn covariance<'a>(tree:UBTree<&'static str,Bounds>)->UBTree<&'a str,Bounds> { tree }
fn node_dropck() {
    let node;
    let value = String::from("borrowed");
    node = BoundingNode::new(&value, ());
    assert_eq!(node.object().as_str(), "borrowed");
}
fn pair_dropck() {
    let pair;
    let value = String::from("borrowed");
    pair = ObjBnd::new(&value, ());
    assert_eq!(pair.object.as_str(), "borrowed");
}
fn tree_borrowed_payload() {
    let value=String::from("borrowed");
    let mut tree=UBTree::default();
    tree.add(value.as_str(),Bounds);
    let mut destination=UBTree::default();
    destination.move_assign(&mut tree);
    assert_eq!(*destination.root().unwrap().object(), "borrowed");
    assert!(tree.is_empty());
    destination.clear();
}
#[derive(Clone, Default, Debug, PartialEq)] struct Borrowed<'a>(&'a str);
impl HashKey for Borrowed<'_> { fn occt_hash(&self)->usize { self.0.len() } }
fn editable_covariance<'a>(tree:EBTree<Borrowed<'static>,Bounds>)->EBTree<Borrowed<'a>,Bounds> { tree }
fn editable_borrowed_payload() {
    let value=String::from("borrowed");
    let mut source=EBTree::default();
    source.add(Borrowed(value.as_str()),Bounds);
    let mut destination=EBTree::default();
    destination.move_assign(&mut source);
    assert!(destination.contains(&Borrowed(value.as_str())));
    assert!(source.is_empty());
    assert!(destination.remove(&Borrowed(value.as_str())));
    assert!(destination.is_empty());
    destination.clear();
}
fn main() {
    traits::<UBTree<i32,Bounds>>();let _=covariance;
    traits::<EBTree<i32,Bounds>>();let _=editable_covariance;editable_borrowed_payload();
    node_dropck();pair_dropck();tree_borrowed_payload();
    let pair=ObjBnd { object:String::from("object"), bounds:String::from("bounds") };
    let object:String=pair.object;
    assert_eq!(object,"object");assert_eq!(pair.bounds,"bounds");
}
