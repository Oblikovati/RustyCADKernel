use rustycad_tkernel::ncollection::Sequence;
use std::time::Instant;
fn measure(size: usize, operation: &str) -> u128 {
    let mut sequence: Sequence<usize> = (0..size).collect();
    let start = Instant::now();
    match operation {
        "clear" => sequence.clear(None),
        "remove_first" => while !sequence.is_empty() { sequence.remove(1).unwrap(); },
        "cursor_scan" => { let mut cursor=sequence.cursor(); while cursor.more() { std::hint::black_box(cursor.value(&sequence)); cursor.next(&sequence); } },
        _ => unreachable!(),
    }
    start.elapsed().as_nanos()
}
fn main() {
    for size in [4_000,8_000,16_000] {
        for operation in ["clear", "remove_first", "cursor_scan"] {
            let mut samples: Vec<_> = (0..3).map(|_| measure(size,operation)).collect();
            samples.sort_unstable();
            println!("{{\"operation\":\"{operation}\",\"size\":{size},\"median_ns\":{},\"samples_ns\":{samples:?}}}",samples[1]);
        }
    }
}
