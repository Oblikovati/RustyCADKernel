import gzip,hashlib,json,os,re,subprocess
from pathlib import Path
p=Path('docs/evidence/prism-copy-provenance-v1-2026-10-14')
expected=json.loads((p/'reconciled/replay-summary.json').read_text())
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
rows=[]
cases=[('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads','prism-copy-lineage-v1:',expected['process-first']['sha256']),('frozen','frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:',expected['legacy-replay']['sha256'])]
for kind,test,marker,expected_hash in cases:
 for label in ['first','second']:
  command=['cargo','+1.99.0','test','-p','rustycad-tkbo','--all-features','--lib',test,'--locked','--','--nocapture','--test-threads=1']
  result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (p/('integrated-'+kind+'-'+label+'.log.gz')).write_bytes(gzip.compress(result.stdout,mtime=0))
  assert result.returncode==0,result.stdout[-3000:]
  values=re.findall(re.escape(marker)+r'([0-9a-f]+)',result.stdout.decode())
  assert len(values)==1,len(values)
  payload=bytes.fromhex(values[0]); actual=hashlib.sha256(payload).hexdigest()
  assert actual==expected_hash,(actual,expected_hash)
  rows.append({'kind':kind,'command':command,'exit_code':0,'bytes':len(payload),'sha256':actual,'matches_candidate':True})
rootlog=gzip.decompress((p/'integrated-tests.log.gz').read_bytes()).decode()
candidatelog=gzip.decompress((p/'final-all-targets.log.gz').read_bytes()).decode()
candidatelog=candidatelog.split('Running unittests src/lib.rs (target/debug/deps/rustycad_tkbrep-',1)[0]
pattern=r'^test (\S+) \.\.\. ok$'
rootnames=set(re.findall(pattern,rootlog,re.M)); candidatenames=set(re.findall(pattern,candidatelog,re.M))
assert rootnames and candidatenames
assert not candidatenames-rootnames,sorted(candidatenames-rootnames)
(p/'integrated-replay.json').write_text(json.dumps({'processes':rows,'additional_integrated_tests':sorted(rootnames-candidatenames)},indent=2)+'\n')
(p/'integrated-replay-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('All four replays match; additional integrated tests:',len(rootnames-candidatenames),flush=True)
