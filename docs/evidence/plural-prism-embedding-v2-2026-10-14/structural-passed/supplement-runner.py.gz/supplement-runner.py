import gzip,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/plural-prism-embedding-v2-2026-10-14/structural-passed';base=root/'docs/evidence/prism-publication-v1-2026-10-14'
def snapshot():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],text=True).split('\0') if n}
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target'}
cases=[('join','joined_math_byte_receipt','same-body-prism-proof-v1:',base/'join-1.bin.gz'),('ordered','ordered_validation_process_receipt','ordered-validation-v1:',base/'ordered-1.bin.gz'),('publication','publication_process_replay','named-prism-publication-v1=',base/'publication-1.bin.gz')]
records=[]
for label,needle,marker,fixture in cases:
 for num in [1,2]:
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',needle,'--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{label}-{num}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  matches=re.findall(re.escape(marker)+r'([0-9a-f]+)',p.stdout.decode());assert len(matches)==1;blob=bytes.fromhex(matches[0]);assert blob==gzip.decompress(fixture.read_bytes());records.append({'label':label,'process':num,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
fixture=root/'crates/tkbo/src/sketch_region_prism/region_certificate/embedding/tests/embedding-v1.json'
for num in [1,2]:
 cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked','prism_embedding_process_receipt','--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'embedding-{num}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
 matches=re.findall(rb'(\{"operation":"martensite.prism-embedding"[^\n]+)',p.stdout);assert len(matches)==1 and matches[0]==fixture.read_bytes().strip();records.append({'label':'embedding','process':num,'bytes':len(matches[0]),'sha256':hashlib.sha256(matches[0]).hexdigest()})
assert before==snapshot();(out/'supplement.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_unchanged':True,'replays':records,'scope':'Structural trim primitive reuse; no plural embedding issuer'},indent=2)+'\n');(out/'supplement-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Embedding structural replay supplement passed',flush=True)
