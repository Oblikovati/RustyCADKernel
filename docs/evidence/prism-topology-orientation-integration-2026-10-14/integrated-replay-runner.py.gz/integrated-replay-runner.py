import gzip,hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
p=Path('docs/evidence/prism-topology-orientation-integration-2026-10-14')
def digest(value): return hashlib.sha256(value).hexdigest()
def git(*args): return subprocess.check_output(['git',*args])
book=json.loads(gzip.decompress((p/'integrated-source-bookends.json.gz').read_bytes()))
assert book['before']==book['after']
def check_current():
 for name,expected in book['after'].items(): assert digest(Path(name).read_bytes())==expected,name
check_current()
fields=git('diff','--no-renames','--name-status','-z','e6955e6db','c23deb36f','--','crates').decode().split('\0')[:-1]
files={name: digest(git('show','c23deb36f:'+name))==book['after'].get(name) for name in fields[1::2]}
assert all(files.values())
helper_fields=git('diff','--no-renames','--name-status','-z','7f9ace712','ccfaad005','--','crates').decode().split('\0')[:-1]
helper_files={name: digest(git('show','ccfaad005:'+name))==book['after'].get(name) for name in helper_fields[1::2]}
assert all(helper_files.values())
with tarfile.open('docs/evidence/prism-orientation/reconciled/runs.tar.gz') as archive:
 focused=archive.extractfile('focused.log').read().decode()
 embedding=archive.extractfile('embedding-baseline.log').read().decode()
def json_record(output,prefix):
 start=output.index(prefix); _,length=json.JSONDecoder().raw_decode(output[start:]);return output[start:start+length].encode()
orientation_prefix='{"operation":"martensite.prism-orientation"'
orientation=json_record(focused,orientation_prefix)
# The math receipt is a distinct, scalar record rather than complete body serialization.
embedding_rows=[line.encode() for line in embedding.splitlines() if line.startswith('{')]
assert len(embedding_rows)==1,len(embedding_rows)
embedding_expected=embedding_rows[0]
legacy_hash='88e28942e1fc6ad301a90f5f07624962d842f0262bde1377103cd3470a871fb4'
lineage_hash='491a1a0a7d1a68505a31dcbc3ea52737d19542d44b3a9e5fb93a072614e397ec'
summary=json.loads(Path('docs/evidence/frozen-prism-topology-v1-2026-10-14/summary.json').read_text())
cases=[
 ('topology','exact_topology_report_replays_across_threads_and_processes','frozen-topology-v1:',summary['replay']['topology_sha256'],'hex'),
 ('orientation','prism_orientation_process_receipt',orientation_prefix,digest(orientation),'json'),
 ('embedding','prism_embedding_process_receipt',embedding_expected.decode()[:embedding_expected.decode().index(',')],digest(embedding_expected),'json'),
 ('frozen','frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:',legacy_hash,'hex'),
 ('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads','prism-copy-lineage-v1:',lineage_hash,'hex')]
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
rows=[]
for kind,test,prefix,expected,encoding in cases:
 for run in ['first','second']:
  command=['cargo','+1.99.0','test','-p','rustycad-tkbo','--all-features','--lib',test,'--locked','--','--nocapture','--test-threads=1']
  result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  log='integrated-'+kind+'-'+run+'.log.gz'; compressed=gzip.compress(result.stdout,mtime=0);(p/log).write_bytes(compressed)
  assert result.returncode==0,result.stdout[-3000:]
  output=result.stdout.decode()
  if encoding=='hex':
   found=re.findall(re.escape(prefix)+r'([0-9a-f]+)',output);assert len(found)==1,len(found);payload=bytes.fromhex(found[0])
  else: payload=json_record(output,prefix)
  assert digest(payload)==expected,(kind,digest(payload),expected)
  rows.append({'kind':kind,'command':command,'exit_code':0,'bytes':len(payload),'sha256':digest(payload),'matches_candidate':True,'log':{'path':log,'sha256':digest(compressed)}})
  print(kind,run,len(payload),'matches',flush=True)
check_current()
(p/'integrated-replay.json').write_text(json.dumps({'processes':rows,'orientation_candidate_files_match':files,'point_adapter_candidate_files_match':helper_files,'source_inputs_unchanged_after_replays':True},indent=2)+'\n')
(p/'integrated-replay-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
