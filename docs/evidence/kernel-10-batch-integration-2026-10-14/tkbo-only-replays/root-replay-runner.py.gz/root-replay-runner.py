import ast,gzip,hashlib,json,os,subprocess,tarfile
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/kernel-10-batch-integration-2026-10-14';raw=root/'target/kernel-10-final-batch-replay';raw.mkdir(exist_ok=True)
exe=root/'target/two-loop-integrated-cold/debug/deps/rustycad_tkbo-3743221922cb8a91'
assert exe.exists()
base=root/'docs/evidence/prism-body-view-v1/actual-checkpoint'
probes=[('body','publication::body_view::actual_replay_tests::actual_body_process_receipt',None),('symbolic','publication::body_view::row_replay_tests::symbolic_body_row_process_replay','SYMBOLIC_BODY_ROWS='),('publication','publication::replay_tests::publication_process_replay','named-prism-publication-v1='),('map','owned_request::names::body_map::tests::semantic_map_replay_probe','SEMANTIC_MAP_REPLAY='),('frozen','frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('ordered','frozen::ordered_validation::replay_tests::ordered_validation_process_receipt','ordered-validation-v1:'),('joined-measures','frozen::joined_measures::tests::replay_tests::joined_measure_process_replay','joined-measures-v1='),('complete-measures','region_certificate::measurements::tests::complete_tests::replay_tests::complete_prism_measure_process_receipt','{"operation":'),('resolver','owned_request::resolver::replay_tests::actual_resolver_process_replay','actual-semantic-resolver-v2=')]
def digest(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0')
 return {p:digest((root/p).read_bytes()) for p in names if p}
before=snapshot();rows=[]
with tarfile.open(root/'docs/evidence/prism-actual-semantic-resolver-v2/final/checks.tar.gz') as archive:
 resolver=archive.extractfile('frozen/actual-replay-1.bin').read()
for name,test,marker in probes:
 expected=resolver if name=='resolver' else gzip.decompress((base/(name+'-1.bin.gz')).read_bytes())
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
  env={**os.environ,'MARTENSITE_ACTUAL_BODY_RECEIPT':str(path)}
  cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();assert result.returncode==0 and '1 passed;' in text,label
  if marker:
   line=next(line[line.index(marker):] for line in text.splitlines() if marker in line)
   payload=bytes(ast.literal_eval(line[len(marker):])) if name=='map' else line.encode() if name=='complete-measures' else bytes.fromhex(line[len(marker):])
  else:payload=path.read_bytes()
  assert payload==expected,(label,'candidate full-byte mismatch')
  payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
  (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
with tarfile.open(root/'docs/evidence/prism-diagnostic-envelope-v1-2026-10-14/publication-adapter-frozen.tar.gz') as archive:
 source=archive.extractfile('publication-diagnostic-frozen/replay.py').read().decode()
 start=source.index('specs = ['); end=source.index('expected = {')
 namespace={};exec(source[start:end],namespace)
 for name,test,form,marker in namespace['specs']:
  expected=archive.extractfile('publication-diagnostic-frozen/'+name+'-0.bin').read()
  payloads=[]
  for ordinal in (1,2):
   label=f'root-diagnostic-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
   env={**os.environ}
   if form=='env':env[marker]=str(path)
   cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
   with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
   content=log.read_text();assert result.returncode==0 and '1 passed;' in content,label
   if form=='env':payload=path.read_bytes()
   else:
    line=next(line[line.index(marker)+len(marker):] for line in content.splitlines() if marker in line)
    payload=bytes(ast.literal_eval(line)) if form=='list' else bytes.fromhex(line)
   assert payload==expected,(label,'candidate full-byte mismatch')
   payloads.append(payload)
   (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
   (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
  assert payloads[0]==payloads[1]
  row={'name':'diagnostic-'+name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
extra=[
 ('annular-embedding','region_certificate::embedding::annular_operation::replay_tests::actual_annular_embedding_process_receipt','annular-prism-embedding-v2=', 'actual-entry/corrected-embedding-1.bin.gz'),
 ('legacy-embedding','region_certificate::embedding::tests::replay_tests::prism_embedding_process_receipt','{', 'structural-passed/embedding-1.bin.gz'),
 ('legacy-join','frozen::proof_join::tests::joined_math_byte_receipt','same-body-prism-proof-v1:', 'structural-passed/join-1.bin.gz')]
base_extra=root/'docs/evidence/plural-prism-embedding-v2-2026-10-14'
for name,test,marker,fixture in extra:
 if name=='legacy-embedding':expected=(root/'crates/tkbo/src/sketch_region_prism/region_certificate/embedding/tests/embedding-v1.json').read_bytes().strip()
 elif name=='legacy-join':expected=gzip.decompress((root/'docs/evidence/prism-publication-v1-2026-10-14/join-1.bin.gz').read_bytes())
 else:expected=gzip.decompress((base_extra/fixture).read_bytes())
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';log=raw/(label+'.log')
  cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();assert result.returncode==0 and '1 passed;' in text,label
  line=next(line[line.index(marker):] for line in text.splitlines() if marker in line)
  payload=line.encode() if name=='legacy-embedding' else bytes.fromhex(line[len(marker):])
  assert payload==expected,(label,'candidate full-byte mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
  (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)

import re
binding_base=root/'docs/evidence/annular-prism-binding-v2-2026-10-14'
completed_tests={'sketch_region_prism::'+item[1] for item in probes}|{item[1] for item in namespace['specs']}
def emitted(log,case):
 if case=='portable_region_certificate_process_receipt':
  return re.search(rb'(\{"operation":"martensite.region-certificate"[^\n]+)',log).group(1)
 found=re.findall(rb'([a-z0-9-]+)[:=]([0-9a-f]{100,})',log);assert len(found)==1,(case,len(found))
 return bytes.fromhex(found[0][1].decode())
for row in json.loads((binding_base/'final-exact-first.json').read_text())['commands']:
 case=row['filter'];test=row['command'][6]
 if test in completed_tests:continue
 expected=emitted(gzip.decompress((binding_base/row['log']).read_bytes()),case);payloads=[]
 for ordinal in (1,2):
  label=f'root-binding-{case}-{ordinal}';log=raw/(label+'.log');cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0 and b'1 passed;' in log.read_bytes(),label
  payload=emitted(log.read_bytes(),case);assert payload==expected,(label,'candidate bytes mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0));(out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':'binding-'+case,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)


join_base=root/'docs/evidence/annular-frozen-domain-v2-2026-10-14'
for name,test,marker,fixture in [
 ('annular-join','frozen::annular_join::replay_tests::annular_frozen_join_owned_process_receipt','named-annular-frozen-domain-v2=','final-annular-process2.log.gz'),
 ('two-loop','region_certificate::two_loop::replay_tests::two_loop_owned_process_receipt','two-loop-region-domain-v2:','final-replay-6.log.gz')]:
 expected_log=gzip.decompress((join_base/fixture).read_bytes()).decode()
 found=re.findall(re.escape(marker)+r'([0-9a-f]+)',expected_log);assert len(found)==1,(name,'expected')
 expected=bytes.fromhex(found[0]);payloads=[]
 for ordinal in (1,2):
  label=f'root-topology-{name}-{ordinal}';log=raw/(label+'.log');cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0 and b'1 passed;' in log.read_bytes(),label
  found=re.findall(re.escape(marker)+r'([0-9a-f]+)',log.read_text());assert len(found)==1
  payload=bytes.fromhex(found[0]);assert payload==expected,(label,'candidate bytes mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0));(out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':'topology-'+name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)


orientation_base=root/'docs/evidence/prism-annular-orientation-v2/replay-supplement'
for name,test,marker,kind in [
 ('orientation-v1','region_certificate::orientation::tests::replay_tests::prism_orientation_process_receipt','{"operation":"martensite.prism-orientation"','text'),
 ('joined-orientation-v1','frozen::joined_orientation::tests::replay_tests::joined_orientation_process_receipt','joined-orientation-v1:','hex'),
 ('annular-orientation-v2','frozen::annular_orientation::lifecycle_tests::annular_orientation_replay_probe','ANNULAR_ORIENTATION_REPLAY=','array')]:
 expected=gzip.decompress((orientation_base/(name+'-1.bin.gz')).read_bytes());payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';log=raw/(label+'.log');cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0 and b'1 passed;' in log.read_bytes(),label
  content=log.read_text();value=content.split(marker,1)[1].splitlines()[0]
  payload=bytes(ast.literal_eval(value)) if kind=='array' else bytes.fromhex(value) if kind=='hex' else (marker+value).encode()
  assert payload==expected,(label,'candidate bytes mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0));(out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)


with tarfile.open(root/'docs/evidence/scoped-owned-prism-v1/final/checks.tar.gz') as archive:
 expected=archive.extractfile('frozen/exact-complete-0.bin').read()
 expected_trace=archive.extractfile('frozen/exact-trace-0.txt').read()
 payloads=[]
 for ordinal in (1,2):
  label=f'root-complete-owned-{ordinal}';log=raw/(label+'.log');path=raw/(label+'.bin');trace_path=raw/(label+'.trace')
  cmd=[str(exe),'--exact','sketch_region_prism::owned_request::complete::runtime_tests::complete_operation_replay_across_processes','--nocapture','--test-threads=1']
  env={**os.environ,'MARTENSITE_COMPLETE_OWNED_RECEIPT':str(path),'MARTENSITE_COMPLETE_OWNED_TRACE':str(trace_path)}
  with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0 and b'1 passed;' in log.read_bytes(),label
  payload=path.read_bytes();trace=trace_path.read_bytes();assert payload==expected and trace==expected_trace,label;payloads.append(payload)
  for suffix,content in [('log',log.read_bytes()),('bin',payload),('trace',trace)]:
   (out/(label+'.'+suffix+'.gz')).write_bytes(gzip.compress(content,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':'complete-owned','bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True,'callback_trace_bytes':len(expected_trace),'callback_trace_sha256':digest(expected_trace)};rows.append(row);print(json.dumps(row),flush=True)

# New batch payloads are compared in full against the sealed candidate archives.
conformance_base=root/'docs/evidence/annular-exact-conformance-v2-2026-10-14'
conformance_records=json.loads((conformance_base/'final-replays.json').read_text())
extras=[]
for index in (8,10,11):
 record=conformance_records[index]
 marker='exact-conformance-callback-baseline:' if index==10 else None
 raw_expected=gzip.decompress((conformance_base/record['log']).read_bytes())
 if marker:
  expected=re.search(re.escape(marker.encode())+rb'([^\n]+)',raw_expected).group(1)
  form='trace'
 else:
  found=re.findall(rb'([a-z0-9-]+)[:=]([0-9a-f]{100,})',raw_expected);assert len(found)==1
  marker=found[0][0].decode();expected=bytes.fromhex(found[0][1].decode());form='tagged-hex'
 extras.append((record['payloads'][0]['tag'],record['command'][6],form,marker,expected))
extras.append(('annular-measures','sketch_region_prism::frozen::annular_measures::tests::baseline::annular_measure_process_receipt','tagged-hex','annular-measures-v2',gzip.decompress((root/'docs/evidence/prism-annular-measures-v2/initial/baseline.bin.gz').read_bytes())))
extras.append(('annular-ordered','sketch_region_prism::frozen::ordered_validation::annular::replay_tests::ordered_annular_replay_probe','array','ANNULAR_ORDERED_REPLAY=',gzip.decompress((root/'docs/evidence/prism-annular-ordered-validation-v2/structural/annular-ordered-1.bin.gz').read_bytes())))
with tarfile.open(root/'docs/evidence/owned-projection-refusal-v1/frozen.tar.gz') as archive:
 expected=archive.extractfile('frozen/processes/projection-0.bin').read()
extras.append(('owned-projection-refusal','sketch_region_prism::owned_request::complete::owned_projection_failure::tests::owned_projection_refusal_process_receipt','env','MARTENSITE_PROJECTION_REFUSAL_RECEIPT',expected))
for name,test,form,marker,expected in extras:
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';log=raw/(label+'.log');path=raw/(label+'.bin');env={**os.environ}
  if form=='env':env[marker]=str(path)
  cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  content=log.read_bytes();assert result.returncode==0 and b'1 passed;' in content,label
  if form=='env':payload=path.read_bytes()
  elif form=='tagged-hex':payload=bytes.fromhex(re.search(re.escape(marker.encode())+rb'[:=]([0-9a-f]+)',content).group(1).decode())
  else:
   value=content.decode().split(marker,1)[1].splitlines()[0]
   payload=bytes(ast.literal_eval(value)) if form=='array' else value.encode()
  assert payload==expected,(label,'candidate byte mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(content,mtime=0));(out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)

after=snapshot();assert before==after
(out/'root-replay-source.json.gz').write_bytes(gzip.compress(json.dumps({'before':before,'after':after},sort_keys=True).encode(),mtime=0))
(out/'root-replays.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'executable_sha256':digest(exe.read_bytes()),'source_unchanged':True,'replays':rows},indent=2)+'\n')
(out/'root-replay-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
