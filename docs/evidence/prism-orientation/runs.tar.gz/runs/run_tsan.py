import json
import os
import run_matrix

before = run_matrix.snapshot('tsan-source-before.json')
env = dict(os.environ, PATH='/home/vmiguel/.rustup/toolchains/nightly-2026-09-25-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin', CARGO_BUILD_JOBS='2', RUSTFLAGS='-Zsanitizer=thread', CARGO_TARGET_DIR='/tmp/martensite-prism-orientation-checks/tsan-target')
version = run_matrix.run('tsan-toolchain', ['rustc','-Vv'], env)
command = ['cargo','test','-p','rustycad-tkbo','--offline','--locked','-Zbuild-std','--target','x86_64-unknown-linux-gnu','--lib','region_certificate::orientation::tests::replay_tests::independent_orientation_threads_match_serial_owned_receipt','--','--nocapture']
result = run_matrix.run('ordinary-host-tsan', command, env)
after = run_matrix.snapshot('tsan-source-after.json')
receipt = dict(command=result, source_unchanged=before==after, host_instrumentation_changes=False,
               environment_changes={k: env[k] for k in ['PATH','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_TARGET_DIR']})
(run_matrix.OUT/'sanitizer.json').write_text(json.dumps(receipt,indent=2)+'\n')
