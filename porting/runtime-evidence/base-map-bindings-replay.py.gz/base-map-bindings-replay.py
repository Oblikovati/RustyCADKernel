import copy
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'tools'))
from api_crosswalk import cpp_indexes, header_owners, rust_crates
from api_binding_replay import BindingReplay, verify_binding_ledger
from normalize_rustdoc_inventory import make_reachable_inventory

ARCHIVE = 'porting/runtime-evidence/base-map-bindings-'


def read_json(relative: str) -> dict:
    path = ROOT / relative
    content = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(content)


def source_hash(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def native_index() -> dict:
    with gzip.open(ROOT / 'porting/api-inventory/occt-declarations.jsonl.gz', 'rt') as stream:
        rows = (json.loads(line) for line in stream)
        selected = [row for row in rows if row.get('qualified_name', '').startswith('NCollection_BaseMap')]
    index, duplicate, malformed = cpp_indexes(selected, header_owners(read_json('porting/api-header-manifest.json')))
    assert not duplicate and not malformed
    return index


def strict_transaction(candidate: dict, baseline: dict, records: list[dict]) -> None:
    expected = copy.deepcopy(baseline)
    for record in records:
        for prior in record['prior_rows']:
            assert expected['api'].count(prior) == 1
            expected['api'].remove(prior)
        expected['api'].append(record['proposed_row'])
    assert expected == candidate


def transaction_snapshots(transaction: dict) -> tuple[dict, dict]:
    baseline_ref = transaction['base_commit'] + ':porting/parity.json'
    baseline = json.loads(subprocess.check_output(['git', 'show', baseline_ref], cwd=ROOT))
    candidate = json.loads(subprocess.check_output(['git', 'cat-file', 'blob', transaction['candidate_ledger_blob']], cwd=ROOT))
    return candidate, baseline


def fresh_rust_index() -> dict:
    raw = gzip.decompress((ROOT / (ARCHIVE + 'rustdoc.json.gz')).read_bytes())
    captured = read_json(ARCHIVE + 'normalized.json.gz')
    assert hashlib.sha256(raw).hexdigest() == captured['raw_rustdoc_sha256']
    compiler = json.loads(raw)
    assert compiler['format_version'] == 61
    inventory = make_reachable_inventory(compiler, ROOT, 'rustycad_tkernel')
    return rust_crates({'crates': [inventory]})


def rejects(action: object) -> bool:
    try:
        action()
    except (AssertionError, ValueError):
        return True
    return False


def wrong_binding_checks(record: dict, replay: BindingReplay) -> dict:
    wrong_id = dict(record, cpp_id='0' * 64)
    wrong_body = copy.deepcopy(record)
    wrong_body['proposed_row']['rust_item'] = 'rustycad_tkernel::ncollection::BaseMapStorage::missing'
    stale_hash = copy.deepcopy(record)
    stale_hash['rust_body']['source_sha256'] = '0' * 64
    return {
        'wrong_native_id_rejected': rejects(lambda: replay.verify(wrong_id)),
        'missing_rust_body_rejected': rejects(lambda: replay.verify(wrong_body)),
        'stale_owned_body_hash_rejected': rejects(lambda: replay.verify(stale_hash)),
    }


def transaction_scope_checks(candidate: dict, baseline: dict, records: list[dict]) -> dict:
    unrelated = copy.deepcopy(candidate)
    unrelated['api'].append({'upstream_id': 'Unrelated::method', 'status': 'partial'})
    verify_binding_ledger(records, unrelated['api'])
    changed = copy.deepcopy(candidate)
    name = records[0]['proposed_row']['upstream_id']
    next(row for row in changed['api'] if row['upstream_id'] == name)['status'] = 'implemented'
    return {
        'unrelated_candidate_change_rejected': rejects(lambda: strict_transaction(unrelated, baseline, records)),
        'unrelated_integrated_class_change_allowed': True,
        'owned_integrated_mapping_change_rejected': rejects(lambda: verify_binding_ledger(records, changed['api'])),
    }


def replay_all() -> None:
    transaction = read_json(ARCHIVE + 'transaction.json.gz')
    records = transaction['records']
    assert len(records) == 38 and len({r['cpp_id'] for r in records}) == 38
    candidate, baseline = transaction_snapshots(transaction)
    strict_transaction(candidate, baseline, records)
    verify_binding_ledger(records, read_json('porting/parity.json')['api'])
    replay = BindingReplay(native_index(), fresh_rust_index(), source_hash)
    for record in records:
        replay.verify(record)
    checks = wrong_binding_checks(records[0], replay)
    checks.update(transaction_scope_checks(candidate, baseline, records))
    assert all(checks.values())
    result = {'native_ids': 38, 'current_public_bodies': 38, 'replaced_rows': 11, 'added_partial_rows': 27, 'checks': checks}
    pathlib.Path('/tmp/base-map-binding-proof.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


replay_all()
