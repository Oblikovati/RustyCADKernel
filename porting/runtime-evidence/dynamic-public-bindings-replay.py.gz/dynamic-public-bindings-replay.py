import collections
import copy
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'tools'))
from api_crosswalk import cpp_indexes, header_owners, cpp_candidates, rust_crates, row_rust_candidates
from normalize_rustdoc_inventory import make_reachable_inventory

BASE = '572d28fe4550e52b958a9bea57639e5e2f15995c'
ARCHIVE = 'porting/runtime-evidence/dynamic-public-bindings-'


def read_json(relative: str) -> dict:
    path = ROOT / relative
    content = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(content)


def sha256_path(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def declaration_index() -> dict:
    with gzip.open(ROOT / 'porting/api-inventory/occt-declarations.jsonl.gz', 'rt') as stream:
        rows = (json.loads(line) for line in stream)
        selected = [row for row in rows if row.get('qualified_name', '').startswith('NCollection_DynamicArray')]
    index, duplicates, malformed = cpp_indexes(selected, header_owners(read_json('porting/api-header-manifest.json')))
    assert not duplicates and not malformed
    return index


def exact_transaction(candidate: dict, baseline: dict, updates: list[dict]) -> None:
    expected = copy.deepcopy(baseline)
    for update in updates:
        positions = [i for i, row in enumerate(expected['api']) if row == update['previous_row']]
        assert len(positions) == 1
        expected['api'][positions[0]] = update['replacement_row']
    assert candidate == expected


def current_owned_rows(ledger: dict, updates: list[dict]) -> None:
    for update in updates:
        expected = update['replacement_row']
        matches = [r for r in ledger['api'] if r['upstream_id'] == expected['upstream_id']]
        assert matches == [expected]


def unchanged_ledger(updates: list[dict]) -> None:
    candidate = json.loads(subprocess.check_output(['git', 'show', 'f632bc56:porting/parity.json'], cwd=ROOT))
    baseline = json.loads(subprocess.check_output(['git', 'show', BASE + ':porting/parity.json'], cwd=ROOT))
    exact_transaction(candidate, baseline, updates)
    current_owned_rows(read_json('porting/parity.json'), updates)


def assert_native(row: dict, identity: str, index: dict) -> dict:
    status, records = cpp_candidates(row['upstream_id'], row['toolkit'], index)
    assert status == 'unique' and [r['id'] for r in records] == [identity]
    assert records[0]['api_visible'] is True
    return records[0]


def assert_rust(row: dict, index: dict) -> list[dict]:
    status, records = row_rust_candidates(row, index)
    assert status == 'unique', (row['upstream_id'], status)
    for record in records:
        assert record['signature']['has_body'] is True
        assert sha256_path(record['source_file']) == record['source_sha256'], record['path']
    return records


def proof_row(update: dict, native_index: dict, rust_index: dict) -> dict:
    row = update['replacement_row']
    native = assert_native(row, update['cpp_id'], native_index)
    rust = assert_rust(row, rust_index)
    proof = {key: native[key] for key in ['id', 'kind', 'qualified_name', 'signature', 'access', 'spelling_location']}
    proof['previous_cpp_status'] = cpp_candidates(update['previous_row']['upstream_id'], 'TKernel', native_index)[0]
    proof['rust_bodies'] = [{key: r[key] for key in ['path', 'signature', 'declaration_sha256', 'source_file', 'source_sha256']} for r in rust]
    proof['inherited_receipt_sha256'] = sha256_path(update['inherited_behavior_receipt'])
    return proof


def rejected(action: object) -> bool:
    try:
        action()
    except AssertionError:
        return True
    return False


def negative_checks(update: dict, native_index: dict, rust_index: dict) -> dict:
    row = update['replacement_row']
    missing = dict(row, rust_item='rustycad_tkernel::ncollection::DynamicArray::missing')
    missing.pop('rust_items', None)
    return {
        'wrong_native_id_rejected': rejected(lambda: assert_native(row, '0' * 64, native_index)),
        'missing_body_rejected': rejected(lambda: assert_rust(missing, rust_index)),
    }


def scoped_body_agreement(updates: list[dict], current: dict, captured: dict) -> None:
    for update in updates:
        row = update['replacement_row']
        current_status, current_rows = row_rust_candidates(row, current)
        saved_status, saved_rows = row_rust_candidates(row, captured)
        assert current_status == saved_status == 'unique'
        assert current_rows == saved_rows


def fresh_inventory(updates: list[dict]) -> dict:
    raw_path = ROOT / (ARCHIVE + 'rustdoc.json.gz')
    raw_bytes = gzip.decompress(raw_path.read_bytes())
    raw = json.loads(raw_bytes)
    assert raw['format_version'] == 61
    saved = read_json(ARCHIVE + 'normalized.json.gz')
    assert hashlib.sha256(raw_bytes).hexdigest() == saved['raw_rustdoc_sha256']
    inventory = make_reachable_inventory(raw, ROOT, 'rustycad_tkernel')
    current = rust_crates({'crates': [inventory]})
    scoped_body_agreement(updates, current, rust_crates(saved))
    return current


def integration_negative_checks(updates: list[dict], rust_index: dict) -> dict:
    baseline = json.loads(subprocess.check_output(['git', 'show', BASE + ':porting/parity.json'], cwd=ROOT))
    candidate = json.loads(subprocess.check_output(['git', 'show', 'f632bc56:porting/parity.json'], cwd=ROOT))
    unrelated = copy.deepcopy(candidate)
    unrelated['api'].append({'upstream_id': 'Unrelated::method', 'status': 'partial'})
    current_owned_rows(unrelated, updates)
    modified = copy.deepcopy(unrelated)
    owned = updates[0]['replacement_row']['upstream_id']
    next(r for r in modified['api'] if r['upstream_id'] == owned)['rust_item'] = 'incorrect'
    return {
        'unrelated_candidate_transaction_mutation_rejected': rejected(lambda: exact_transaction(unrelated, baseline, updates)),
        'unrelated_integrated_class_change_allowed': True,
        'owned_integrated_row_mutation_rejected': rejected(lambda: current_owned_rows(modified, updates)),
    }


def source_scope_checks(updates: list[dict], rust_index: dict) -> dict:
    unrelated = copy.deepcopy(rust_index)
    unrelated['rustycad_tkernel']['rustycad_tkernel::ncollection::BaseMapStorage::new'][0]['source_sha256'] = '0' * 64
    scoped_body_agreement(updates, unrelated, rust_index)
    relevant = copy.deepcopy(rust_index)
    row = updates[0]['replacement_row']
    _, targets = row_rust_candidates(row, relevant)
    targets[0]['source_sha256'] = '0' * 64
    return {
        'unrelated_integrated_body_change_allowed': True,
        'stale_owned_body_hash_rejected': rejected(lambda: scoped_body_agreement(updates, relevant, rust_index)),
    }


def run_verification() -> None:
    updates = read_json(ARCHIVE + 'updates.json.gz')
    assert len(updates) == 11 and all(row['replacement_row']['status'] == 'partial' for row in updates)
    unchanged_ledger(updates)
    native_index = declaration_index()
    rust_index = fresh_inventory(updates)
    proofs = [proof_row(row, native_index, rust_index) for row in updates]
    negatives = negative_checks(updates[0], native_index, rust_index)
    negatives.update(integration_negative_checks(updates, rust_index))
    negatives.update(source_scope_checks(updates, rust_index))
    assert all(negatives.values())
    result = {'proofs': proofs, 'negative_checks': negatives, 'base': BASE}
    pathlib.Path('/tmp/dynamic-public-bindings-proof.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'native_exact_ids': len(proofs), 'public_body_bindings': sum(len(r['rust_bodies']) for r in proofs), 'prior_cpp_status': dict(collections.Counter(r['previous_cpp_status'] for r in proofs)), 'negative_checks': negatives, 'original_transaction_only_expected11': True, 'integrated_owned_rows_current': True, 'new_test_credit': 0}))


run_verification()
