"""Replay the exact IndexedIterator partial transaction; pass the checkout root."""

from __future__ import annotations

import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from collections.abc import Callable

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / "tools"))
from api_crosswalk import cpp_indexes, header_owners, rust_crates
from api_binding_replay import BindingReplay, verify_binding_ledger, binding_object
from api_inventory.inputs import JSONObject, object_rows, text_field
from api_rust_kind import RustCrateIndex
from normalize_rustdoc_inventory import make_reachable_inventory

ARCHIVE = "porting/runtime-evidence/base-map-indexed-tail-"


def read_json(relative: str) -> JSONObject:
    """Read captured metadata; `read_json(ARCHIVE + 'transaction.json.gz')`."""
    path = ROOT / relative
    content = (
        gzip.decompress(path.read_bytes())
        if path.suffix == ".gz"
        else path.read_bytes()
    )
    parsed: JSONObject = json.loads(content)
    return parsed


def source_hash(relative: str) -> str:
    """Hash current body input; `source_hash('crates/tkernel/src/lib.rs')`."""
    payload = (ROOT / relative).read_bytes()
    return hashlib.sha256(payload).hexdigest()


def native_index() -> dict[str, list[JSONObject]]:
    """Index pinned native declarations; `native_index()`."""
    with gzip.open(
        ROOT / "porting/api-inventory/occt-declarations.jsonl.gz", "rt"
    ) as stream:
        rows = (json.loads(line) for line in stream)
        selected = [
            row
            for row in rows
            if row.get("qualified_name", "").startswith("NCollection_BaseMap")
            or row.get("qualified_name") == "operator+"
        ]
    owners = header_owners(read_json("porting/api-header-manifest.json"))
    index, duplicate, malformed = cpp_indexes(selected, owners)
    assert not duplicate and not malformed
    return index


def strict_transaction(
    candidate: JSONObject, baseline: JSONObject, records: list[JSONObject]
) -> None:
    """Reject mutations outside original owned rows; `strict_transaction(after, before, proof)`."""
    expected = copy.deepcopy(baseline)
    api = object_rows(expected["api"], "base api")
    for record in records:
        for prior in object_rows(record["prior_rows"], "prior rows"):
            assert api.count(prior) == 1
            api.remove(prior)
        api.append(binding_object(record, "proposed_row"))
    expected["api"] = api
    assert (
        expected == candidate
    ), "candidate ledger differs from exact twenty-five-row replacement"


def transaction_snapshots(transaction: JSONObject) -> tuple[JSONObject, JSONObject]:
    """Read immutable Git transaction snapshots; `transaction_snapshots(transaction)`."""
    baseline_ref = text_field(transaction, "base_commit") + ":porting/parity.json"
    baseline = json.loads(
        subprocess.check_output(["git", "show", baseline_ref], cwd=ROOT)
    )
    blob = text_field(transaction, "candidate_ledger_blob")
    candidate = json.loads(
        subprocess.check_output(["git", "cat-file", "blob", blob], cwd=ROOT)
    )
    return candidate, baseline


def fresh_rust_index() -> RustCrateIndex:
    """Normalize captured compiler identities against current bodies; `fresh_rust_index()`."""
    raw = gzip.decompress((ROOT / (ARCHIVE + "rustdoc.json.gz")).read_bytes())
    captured = read_json(ARCHIVE + "normalized.json.gz")
    assert hashlib.sha256(raw).hexdigest() == captured["raw_rustdoc_sha256"]
    compiler = json.loads(raw)
    assert compiler["format_version"] == 61
    inventory = make_reachable_inventory(compiler, ROOT, "rustycad_tkernel")
    return rust_crates({"crates": [inventory]})


def rejects(action: Callable[[], None]) -> bool:
    """Return whether a deliberately invalid proof fails; `rejects(check)`."""
    try:
        action()
    except (AssertionError, ValueError):
        return True
    return False


def wrong_binding_checks(record: JSONObject, replay: BindingReplay) -> dict[str, bool]:
    """Exercise ID, final body and selector failures; `wrong_binding_checks(record, replay)`."""
    wrong_id = dict(record, cpp_id="0" * 64)
    stale_hash = copy.deepcopy(record)
    object_rows(stale_hash["rust_bodies"], "bodies")[-1]["source_sha256"] = "0" * 64
    missing = copy.deepcopy(record)
    row = binding_object(missing, "proposed_row")
    object_rows(row["rust_declaration_selectors"], "selectors")[-1][
        "declaration_sha256"
    ] = ("0" * 64)
    return {
        "wrong_native_id_rejected": rejects(lambda: replay.verify(wrong_id)),
        "stale_last_body_hash_rejected": rejects(lambda: replay.verify(stale_hash)),
        "missing_last_selected_body_rejected": rejects(lambda: replay.verify(missing)),
    }


def changed_owned_ledger(
    candidate: JSONObject, records: list[JSONObject]
) -> list[JSONObject]:
    """Create a forbidden owned status change; `changed_owned_ledger(candidate, records)`."""
    changed_api = object_rows(copy.deepcopy(candidate)["api"], "changed api")
    name = binding_object(records[0], "proposed_row")["upstream_id"]
    changed = next(row for row in changed_api if row["upstream_id"] == name)
    changed["status"] = "implemented"
    return changed_api


def transaction_scope_checks(
    candidate: JSONObject, baseline: JSONObject, records: list[JSONObject]
) -> dict[str, bool]:
    """Separate transaction integrity from integration scope; `transaction_scope_checks(after, before, proof)`."""
    unrelated = copy.deepcopy(candidate)
    unrelated_api = object_rows(unrelated["api"], "unrelated api")
    unrelated_api.append({"upstream_id": "Unrelated::method", "status": "partial"})
    verify_binding_ledger(records, unrelated_api)
    changed_api = changed_owned_ledger(candidate, records)
    original_rejects = rejects(lambda: strict_transaction(unrelated, baseline, records))
    owned_rejects = rejects(lambda: verify_binding_ledger(records, changed_api))
    return {
        "unrelated_candidate_change_rejected": original_rejects,
        "unrelated_current_class_change_allowed": True,
        "owned_current_mapping_change_rejected": owned_rejects,
    }


def print_result(
    records: list[JSONObject], replay: BindingReplay, scope: dict[str, bool]
) -> None:
    """Report independent negative guards; `print_result(records, replay, scope)`."""
    multi = next(
        record for record in records if str(record["cpp_id"]).startswith("7fbed7ad")
    )
    checks = wrong_binding_checks(multi, replay)
    checks.update(scope)
    assert all(checks.values()), checks
    result = {
        "native_ids": 25,
        "public_bodies": 36,
        "exclusions_replaced_with_partial": 25,
        "checks": checks,
    }
    print(json.dumps(result))


def replay_all() -> None:
    """Verify every source-pinned policy and transaction guard; `replay_all()`."""
    transaction = read_json(ARCHIVE + "transaction.json.gz")
    records = object_rows(transaction["records"], "records")
    assert len(records) == 25 and len({record["cpp_id"] for record in records}) == 25
    candidate, baseline = transaction_snapshots(transaction)
    strict_transaction(candidate, baseline, records)
    verify_binding_ledger(
        records, object_rows(read_json("porting/parity.json")["api"], "current api")
    )
    replay = BindingReplay(native_index(), fresh_rust_index(), source_hash)
    for record in records:
        replay.verify(record)
    scope = transaction_scope_checks(candidate, baseline, records)
    print_result(records, replay, scope)


replay_all()
