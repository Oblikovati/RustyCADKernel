"""Replay scoped address-policy bodies without granting or changing parity ledger status."""

from __future__ import annotations
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys
from collections.abc import Callable

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / "tools"))
from api_binding_replay import BindingReplay, binding_object
from api_crosswalk import cpp_indexes, header_owners, rust_crates
from api_inventory.inputs import JSONObject, object_rows
from api_rust_kind import RustCrateIndex
from normalize_rustdoc_inventory import make_reachable_inventory

ARCHIVE = "porting/runtime-evidence/base-iterator-address-"


def read_json(relative: str) -> JSONObject:
    """Read archived metadata; `read_json(ARCHIVE + 'normalized.json.gz')`."""
    path = ROOT / relative
    payload = (
        gzip.decompress(path.read_bytes())
        if path.suffix == ".gz"
        else path.read_bytes()
    )
    result: JSONObject = json.loads(payload)
    return result


def source_hash(relative: str) -> str:
    """Pin relevant current sources; `source_hash('crates/tkernel/src/lib.rs')`."""
    payload = (ROOT / relative).read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    return digest


def native_index() -> dict[str, list[JSONObject]]:
    """Resolve actual List/Sequence declarations; `native_index()`."""
    with gzip.open(
        ROOT / "porting/api-inventory/occt-declarations.jsonl.gz", "rt"
    ) as stream:
        rows = (json.loads(line) for line in stream)
        chosen = [
            r
            for r in rows
            if r.get("qualified_name", "").startswith(
                ("NCollection_BaseList", "NCollection_BaseSequence")
            )
        ]
    index, duplicate, malformed = cpp_indexes(
        chosen, header_owners(read_json("porting/api-header-manifest.json"))
    )
    assert not duplicate and not malformed
    return index


def rust_index() -> RustCrateIndex:
    """Normalize pinned rustdoc and hash current bodies; `rust_index()`."""
    raw = gzip.decompress((ROOT / (ARCHIVE + "rustdoc.json.gz")).read_bytes())
    saved = read_json(ARCHIVE + "normalized.json.gz")
    assert hashlib.sha256(raw).hexdigest() == saved["raw_rustdoc_sha256"]
    compiler = json.loads(raw)
    assert compiler["format_version"] == 61
    inventory = make_reachable_inventory(compiler, ROOT, "rustycad_tkernel")
    return rust_crates({"crates": [inventory]})


def rejects(action: Callable[[], None]) -> bool:
    """Recognize an intentionally false binding; `rejects(check)`."""
    try:
        action()
    except (AssertionError, ValueError):
        return True
    return False


def body_guards(record: JSONObject, replay: BindingReplay) -> dict[str, bool]:
    """Reject stale final policy bodies and native IDs; `body_guards(record, replay)`."""
    wrong = dict(record, cpp_id="0" * 64)
    stale = copy.deepcopy(record)
    object_rows(stale["rust_bodies"], "bodies")[-1]["source_sha256"] = "0" * 64
    missing = copy.deepcopy(record)
    row = binding_object(missing, "proposed_row")
    object_rows(row["rust_declaration_selectors"], "selectors")[-1][
        "declaration_sha256"
    ] = ("0" * 64)
    return {
        "wrong_native_id_rejected": rejects(lambda: replay.verify(wrong)),
        "last_policy_hash_rejected": rejects(lambda: replay.verify(stale)),
        "missing_last_policy_rejected": rejects(lambda: replay.verify(missing)),
    }


def selector_guards(record: JSONObject, replay: BindingReplay) -> dict[str, bool]:
    """Prove explicit const/mutable specialization choices; `selector_guards(record, replay)`."""
    changed = copy.deepcopy(record)
    row = binding_object(changed, "proposed_row")
    selectors = object_rows(row["rust_declaration_selectors"], "selectors")
    selectors[0]["impl_context"] = copy.deepcopy(selectors[1]["impl_context"])
    duplicate = copy.deepcopy(record)
    duplicate_row = binding_object(duplicate, "proposed_row")
    repeated = object_rows(duplicate_row["rust_declaration_selectors"], "selectors")
    repeated.append(copy.deepcopy(repeated[0]))
    duplicate_row["rust_declaration_selectors"] = repeated
    return {
        "opposite_specialization_rejected": rejects(lambda: replay.verify(changed)),
        "duplicate_selector_rejected": rejects(lambda: replay.verify(duplicate)),
    }


def replay_all() -> None:
    """Verify all eight bodies without a partial-status shortcut; `replay_all()`."""
    captured = read_json(ARCHIVE + "bindings.json.gz")
    records = object_rows(captured["records"], "records")
    assert len(records) == 2 and len({r["cpp_id"] for r in records}) == 2
    replay = BindingReplay(native_index(), rust_index(), source_hash)
    for record in records:
        replay.verify(record)
    checks = body_guards(records[0], replay) | selector_guards(records[1], replay)
    assert all(checks.values()), checks
    print(
        json.dumps(
            {"native_ids": 2, "public_bodies": 8, "ledger_changes": 0, "checks": checks}
        )
    )


replay_all()
