import collections
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'tools'))
from api_crosswalk import cpp_indexes, header_owners, cpp_candidates, rust_crates, row_rust_candidates


def json_read(relative: str) -> dict:
    path = ROOT / relative
    payload = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(payload)


def file_hash(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def native_records() -> list[dict]:
    with gzip.open(ROOT / 'porting/api-inventory/occt-declarations.jsonl.gz', 'rt') as stream:
        rows = (json.loads(line) for line in stream)
        return [row for row in rows if row.get('qualified_name', '').startswith('NCollection_DynamicArray')]


def resolved_body(row: dict, rust_index: dict) -> list[dict]:
    status, targets = row_rust_candidates(row, rust_index)
    assert status == 'unique', (row['upstream_id'], status)
    for target in targets:
        assert target['signature']['has_body'] is True, target['path']
        assert file_hash(target['source_file']) == target['source_sha256'], target['path']
    return targets


def exact_native(row: dict, expected: str, native_index: dict) -> dict:
    status, records = cpp_candidates(row['upstream_id'], 'TKernel', native_index)
    assert status == 'unique' and [record['id'] for record in records] == [expected]
    assert records[0]['access'] == 'protected' and records[0]['api_visible'] is True
    return records[0]


def proposed_rows(ledger: dict, baseline: dict) -> list[dict]:
    old = {row['upstream_id']: row for row in baseline['api']}
    added = [row for row in ledger['api'] if row['upstream_id'] not in old]
    assert len(added) == 22 and all(row['status'] == 'partial' for row in added)
    assert [row for row in ledger['api'] if row['upstream_id'] in old] == baseline['api']
    assert ledger['tests'] == baseline['tests']
    return added


def binding_proof(row: dict, expected: dict, native_index: dict, rust_index: dict) -> dict:
    native = exact_native(row, expected['id'], native_index)
    targets = resolved_body(row, rust_index)
    proof = {key: native[key] for key in ['id', 'qualified_name', 'signature', 'access', 'api_visible', 'kind']}
    proof['ledger_row'] = row
    proof['rust_bodies'] = [{key: target[key] for key in ['path', 'declaration_sha256', 'source_file', 'source_sha256']} for target in targets]
    proof['inherited_behavior_receipt'] = expected['receipt']
    proof['inherited_behavior_receipt_sha256'] = file_hash(expected['receipt'])
    return proof


def rejects(action: object) -> bool:
    try:
        action()
    except AssertionError:
        return True
    return False


def negative_checks(row: dict, expected: dict, native_index: dict, rust_index: dict) -> dict:
    missing_native = dict(row, upstream_id='NCollection_DynamicArray::does_not_exist()')
    missing_rust = dict(row, rust_item='rustycad_tkernel::ncollection::DynamicArray::does_not_exist')
    missing_rust.pop('rust_items', None)
    return {
        'missing_native_rejected': rejects(lambda: exact_native(missing_native, expected['id'], native_index)),
        'wrong_exact_native_id_rejected': rejects(lambda: exact_native(row, '0' * 64, native_index)),
        'missing_rust_body_rejected': rejects(lambda: resolved_body(missing_rust, rust_index)),
    }


def main() -> None:
    ledger = json_read('porting/parity.json')
    baseline = json.loads(subprocess.check_output(['git', 'show', '1fa607a3f36c7f07c5e5224746a1bbf7e8e13f5c:porting/parity.json'], cwd=ROOT))
    native_index, duplicates, malformed = cpp_indexes(native_records(), header_owners(json_read('porting/api-header-manifest.json')))
    assert not duplicates and not malformed
    rust_document = json_read('porting/api-inventory/rust-api.json.gz')
    rust_index = rust_crates(rust_document)
    prepared = json_read('porting/runtime-evidence/dynamic-array-protected-binding-proof.json.gz')
    expected = {row['ledger_row']['upstream_id']: dict(row, receipt=row['inherited_behavior_receipt']) for row in prepared['bindings']}
    added = proposed_rows(ledger, baseline)
    bindings = [binding_proof(row, expected[row['upstream_id']], native_index, rust_index) for row in added]
    negative = negative_checks(added[0], expected[added[0]['upstream_id']], native_index, rust_index)
    assert all(negative.values())
    result = {'bindings': bindings, 'negative_checks': negative, 'rust_capture_revision': rust_document['capture_workspace_revision']}
    pathlib.Path('/tmp/dynamic-protected-binding-proof.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'exact_protected_native_ids': len(bindings), 'current_public_rust_bodies': sum(len(row['rust_bodies']) for row in bindings), 'negative_checks': negative, 'existing_rows_unchanged': True, 'implemented_credit_delta': 0, 'test_credit_delta': 0}))


main()
