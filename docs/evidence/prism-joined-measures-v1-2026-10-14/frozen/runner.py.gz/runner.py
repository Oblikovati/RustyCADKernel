import gzip,hashlib,json,os,pathlib,re,subprocess,time,platform
root=pathlib.Path.cwd();out=root/'docs/evidence/prism-joined-measures-v1-2026-10-14/frozen';out.mkdir(exist_ok=True)
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def hashes():
 paths=git('ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').decode().split('\0')
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if p}
assert not git('status','--porcelain').strip()
revision=git('rev-parse','HEAD').decode().strip();before=hashes();steps=[]
def save(name,payload):
 (out/(name+'.gz')).write_bytes(gzip.compress(payload,mtime=0))
def run(label,args,extra=None):
 print('start '+label,flush=True);start=time.monotonic();p=subprocess.run(args,env={**env,**(extra or {})},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);save(label+'.log',p.stdout)
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.stdout.decode(errors='replace'))
 step={'label':label,'command':args,'exit_code':p.returncode,'seconds':time.monotonic()-start,'counts':[list(map(int,row)) for row in counts]};steps.append(step);print(json.dumps(step),flush=True);assert p.returncode==0
 return p.stdout
cargo=['cargo','+1.99.0']
for name,args in [('tests',['test','--all-targets']),('doctests',['test','--doc']),('clippy',['clippy','--all-targets'])]:
 cmd=cargo+args+['-p','rustycad-tkbo','--all-features','--locked']
 if name=='clippy':cmd+=['--','-D','warnings']
 run(name,cmd)
run('format',cargo+['fmt','--all','--','--check'])
run('docs',cargo+['doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],{'RUSTDOCFLAGS':'-D warnings'})
selector='sketch_region_prism::frozen::joined_measures::tests::replay_tests::joined_measure_process_replay';values=[]
for process in [1,2]:
 output=run(f'joined-process-{process}',cargo+['test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture']).decode();assert '1 passed; 0 failed' in output
 rows=[line for line in output.splitlines() if line.startswith('joined-measures-v1=')];assert len(rows)==1
 value=bytes.fromhex(rows[0].split('=',1)[1]);values.append(value);save(f'joined-process-{process}.bin',value)
expected=gzip.decompress((out.parent/'joined-precleanup.bin.gz').read_bytes());assert values[0]==values[1]==expected
after=hashes();assert before==after
save('source-bookends.json',json.dumps({'before':before,'after':after},sort_keys=True).encode())
receipt={'source_revision':revision,'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','+1.99.0','-vV'],env=env).decode(),'steps':steps,'source_inputs_unchanged':before==after,'source_count':len(before),'replay_bytes':len(expected),'replay_sha256':hashlib.sha256(expected).hexdigest(),'two_processes_equal_to_pinned':True,'scope':'TKBO source only; unchanged dependencies retain preceding owner gates','limitations':['Private conditional scalar evidence; no body validity or release acceptance.','TSan not executed for this source; current host sanitizer startup failure remains incomplete.','No full API/test parity or application claim.']}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');save('runner.py',pathlib.Path(__file__).read_bytes());print('frozen candidate gate complete '+revision,flush=True)
