import ast,gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd();base=root/'docs/evidence/prism-publication-v1-2026-10-14';out=root/'docs/evidence/prism-publication-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
seals=json.loads((base/'sha256.json').read_text())
for path,digest in seals.items():assert sha((base/path).read_bytes())==digest,path
assert gzip.decompress((base/'inputs-before.json.gz').read_bytes())==gzip.decompress((base/'inputs-after.json.gz').read_bytes())
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M));candidate=names(gzip.decompress((base/'all-targets.log.gz').read_bytes()));actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual
module=ast.parse((base/'run_gate.py').read_text());cases=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CASES' for t in n.targets))
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for kind,needle,marker in cases:
 expected=gzip.decompress((base/f'{kind}-1.bin.gz').read_bytes());assert expected==gzip.decompress((base/f'{kind}-2.bin.gz').read_bytes())
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked','sketch_region_prism::'+needle,'--','--exact','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{kind}-process-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  found=re.findall(re.escape(marker)+r'([0-9a-f]+)',p.stdout.decode());assert len(found)==1;blob=bytes.fromhex(found[0]);assert blob==expected
  (out/f'{kind}-process-{i}.bin.gz').write_bytes(gzip.compress(blob,mtime=0));replays.append({'kind':kind,'process':i,'bytes':len(blob),'sha256':sha(blob)})
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0;assert before==snapshot()
r={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_test_names_retained':len(candidate),'missing_tests':sorted(candidate-actual),'source_unchanged':True,'verified_candidate_artifacts':seals,'replays':replays,'docs_exit':p.returncode,'limits':['Complete private single-Jordan polynomial operation only; owned public boundary, general profiles and release acceptance remain open.','ThreadSanitizer acceptance incomplete.']}
(out/'integrated-supplement.json').write_text(json.dumps(r,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('publication supplement passed',flush=True)
