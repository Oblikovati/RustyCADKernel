#include <NCollection_IndexedMap.hxx>
#include <NCollection_IndexedDataMap.hxx>
#include <NCollection_DataMap.hxx>
#include <iostream>
struct alignas(32) Wide { unsigned char value=7; };
template<class K> void map_row(const char* label) {
 using N=typename NCollection_IndexedMap<K>::IndexedMapNode;
 N node(K{},1,nullptr); const char* start=reinterpret_cast<const char*>(&node);
 std::cout<<label<<' '<<sizeof(N)<<' '<<alignof(N)<<' '<<reinterpret_cast<const char*>(&node.Key1())-start<<' '<<reinterpret_cast<const char*>(&node.Index())-start<<'\n';
}
template<class K,class V> void data_row(const char* label) {
 using N=typename NCollection_IndexedDataMap<K,V>::IndexedDataMapNode;
 N node(K{},1,V{},nullptr);const char* start=reinterpret_cast<const char*>(&node);
 std::cout<<label<<' '<<sizeof(N)<<' '<<alignof(N)<<' '<<reinterpret_cast<const char*>(&node.Key1())-start<<' '<<reinterpret_cast<const char*>(&node.Value())-start<<' '<<reinterpret_cast<const char*>(&node.Index())-start<<'\n';
}
int main() {
 map_row<unsigned char>("map_u8");map_row<int>("map_i32");map_row<Wide>("map_wide");
 data_row<unsigned char,unsigned char>("data_u8_u8");data_row<int,unsigned char>("data_i32_u8");data_row<unsigned char,int>("data_u8_i32");data_row<int,int>("data_i32_i32");
 data_row<Wide,unsigned char>("data_wide_u8");data_row<unsigned char,Wide>("data_u8_wide");data_row<Wide,Wide>("data_wide_wide");
}
