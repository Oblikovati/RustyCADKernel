import gzip,json,sys,hashlib,pathlib
root=pathlib.Path(sys.argv[1]).resolve();sys.path.insert(0,str(root/'tools'))
from normalize_rustdoc_inventory import make_reachable_inventory
from api_crosswalk import cpp_indexes,header_owners,cpp_candidates,rust_crates,row_rust_candidates
raw=pathlib.Path(sys.argv[2]);norm=make_reachable_inventory(json.loads(raw.read_bytes()),root,'rustycad_tkernel');rust=rust_crates({'crates':[norm]})
fixture=root/'tools/tests/fixtures/vector-scalar-body-selectors.json.gz';captured=json.loads(gzip.decompress(fixture.read_bytes()));paths={b['path'] for b in captured['crates'][0]['declarations']}
with gzip.open(root/'porting/api-inventory/occt-declarations.jsonl.gz','rt') as stream:native=[r for line in stream if (r:=json.loads(line)).get('qualified_name','').startswith(('NCollection_Vec2::','NCollection_Vec3::','NCollection_Vec4::'))]
owners=header_owners(json.loads((root/'porting/api-header-manifest.json').read_text()));index,duplicate,malformed=cpp_indexes(native,owners);assert not duplicate and not malformed
rows=[r for r in json.loads((root/'porting/parity.json').read_text())['api'] if r.get('rust_item') in paths];assert len(rows)==6
bindings=[]
for row in rows:
 status,bodies=row_rust_candidates(row,rust);assert status=='unique' and len(bodies)==2,(row,status)
 native_status,declarations=cpp_candidates(row['upstream_id'],row['toolkit'],index);assert native_status=='unique'
 for body in bodies:
  assert body['signature']['has_body'] and body['kind']=='function'
  assert hashlib.sha256((root/body['source_file']).read_bytes()).hexdigest()==body['source_sha256']
  assert body in captured['crates'][0]['declarations']
 bindings.append({'proposed_row':row,'cpp_id':declarations[0]['id'],'cpp_signature':declarations[0]['signature'],'rust_bodies':bodies})
pathlib.Path('/tmp/vector-scalar-selector-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
print('Verified six exact native declarations and twelve current compiler bodies; no status or original-test mapping promotions.')
