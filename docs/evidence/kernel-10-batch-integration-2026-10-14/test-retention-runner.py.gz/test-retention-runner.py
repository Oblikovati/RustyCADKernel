import gzip,json,re,tarfile
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/kernel-10-batch-integration-2026-10-14'
def compressed(path):return gzip.decompress((root/path).read_bytes())
def qualified(blob):
 package=None;target=None;names=set()
 for line in blob.decode().splitlines():
  running=re.search(r'Running (?:unittests )?([^ ]+) \(([^)]+)\)',line)
  if running:
   target=running.group(1);binary=Path(running.group(2)).name
   unit=re.fullmatch(r'(rustycad_tkbo|rustycad_tkmath)-[a-f0-9]+',binary)
   if unit:package=unit.group(1)
  passed=re.fullmatch(r'test (.+) \.\.\. ok',line)
  if passed:
   assert package and target,line
   key=(package,target,passed.group(1));assert key not in names,key;names.add(key)
 expected=sum(int(x) for x in re.findall(rb'test result: ok\. (\d+) passed;',blob))
 assert len(names)==expected,(len(names),expected)
 return names
blobs={
 'prior_main':compressed('docs/evidence/prism-owned-complete-integration-2026-10-14/integrated-tests.log.gz'),
 'conformance':compressed('docs/evidence/annular-exact-conformance-v2-2026-10-14/final-all-targets.log.gz'),
 'measures':compressed('docs/evidence/prism-annular-measures-v2/frozen/tests.log.gz'),
 'ordered_validation':compressed('docs/evidence/prism-annular-ordered-validation-v2/final/tests.log.gz'),
 'history_helpers':compressed('docs/evidence/annular-complete-history-v2-2026-10-14/final-all-targets.log.gz')}
with tarfile.open(root/'docs/evidence/owned-projection-refusal-v1/frozen.tar.gz') as archive:blobs['owned_projection_refusal']=archive.extractfile('frozen/all-targets.log').read()
rows=[]
actual=qualified(compressed('docs/evidence/kernel-10-batch-integration-2026-10-14/integrated-tests.log.gz'))
for label,blob in blobs.items():
 expected=qualified(blob);missing=sorted(expected-actual)
 rows.append({'candidate':label,'package_target_qualified_tests':len(expected),'missing':missing})
 assert not missing,(label,missing)
(out/'test-retention.json').write_text(json.dumps({'integrated_tests':len(actual),'qualification':'package + target source path + complete Rust test name','candidates':rows},indent=2)+'\n')
(out/'test-retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(rows))
