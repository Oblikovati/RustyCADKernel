import collections
import copy
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / 'tools'))
from api_crosswalk import cpp_indexes, header_owners, cpp_candidates, rust_crates, row_rust_candidates
from normalize_rustdoc_inventory import make_reachable_inventory

BASE = '321cd5ac477abfdfd0a5afb5962c20c3b2beef2c'
ARCHIVE = 'porting/runtime-evidence/dynamic-stale-bindings-'


def read_json(relative: str) -> dict:
    path = ROOT / relative
    content = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(content)


def sha256_path(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def declaration_index() -> dict:
    with gzip.open(ROOT / 'porting/api-inventory/occt-declarations.jsonl.gz', 'rt') as stream:
        rows = (json.loads(line) for line in stream)
        selected = [row for row in rows if row.get('qualified_name', '').startswith('NCollection_DynamicArray')]
    index, duplicates, malformed = cpp_indexes(selected, header_owners(read_json('porting/api-header-manifest.json')))
    assert not duplicates and not malformed
    return index


def unchanged_ledger(updates: list[dict]) -> None:
    ledger = read_json('porting/parity.json')
    original = json.loads(subprocess.check_output(['git', 'show', BASE + ':porting/parity.json'], cwd=ROOT))
    expected = copy.deepcopy(original)
    for update in updates:
        positions = [i for i, row in enumerate(expected['api']) if row == update['previous_row']]
        assert len(positions) == 1
        expected['api'][positions[0]] = update['replacement_row']
    assert ledger == expected


def assert_native(row: dict, identity: str, index: dict) -> dict:
    status, records = cpp_candidates(row['upstream_id'], row['toolkit'], index)
    assert status == 'unique' and [r['id'] for r in records] == [identity]
    assert records[0]['api_visible'] is True
    return records[0]


def assert_rust(row: dict, index: dict) -> list[dict]:
    status, records = row_rust_candidates(row, index)
    assert status == 'unique', (row['upstream_id'], status)
    for record in records:
        assert record['signature']['has_body'] is True
        assert sha256_path(record['source_file']) == record['source_sha256'], record['path']
    return records


def proof_row(update: dict, native_index: dict, rust_index: dict) -> dict:
    row = update['replacement_row']
    native = assert_native(row, update['cpp_id'], native_index)
    rust = assert_rust(row, rust_index)
    proof = {key: native[key] for key in ['id', 'kind', 'qualified_name', 'signature', 'access', 'spelling_location']}
    proof['previous_cpp_status'] = cpp_candidates(update['previous_row']['upstream_id'], 'TKernel', native_index)[0]
    proof['rust_bodies'] = [{key: r[key] for key in ['path', 'signature', 'declaration_sha256', 'source_file', 'source_sha256']} for r in rust]
    proof['inherited_receipt_sha256'] = sha256_path(update['inherited_behavior_receipt'])
    return proof


def rejected(action: object) -> bool:
    try:
        action()
    except AssertionError:
        return True
    return False


def negative_checks(update: dict, native_index: dict, rust_index: dict) -> dict:
    row = update['replacement_row']
    missing = dict(row, rust_item='rustycad_tkernel::ncollection::DynamicArray::missing')
    missing.pop('rust_items', None)
    return {
        'wrong_native_id_rejected': rejected(lambda: assert_native(row, '0' * 64, native_index)),
        'missing_body_rejected': rejected(lambda: assert_rust(missing, rust_index)),
    }


def fresh_inventory() -> dict:
    raw = read_json(ARCHIVE + 'rustdoc.json.gz')
    assert raw['format_version'] == 61
    inventory = make_reachable_inventory(raw, ROOT, 'rustycad_tkernel')
    saved = read_json(ARCHIVE + 'normalized.json.gz')['crates'][0]
    assert inventory == saved
    return rust_crates({'crates': [inventory]})


def run_verification() -> None:
    updates = read_json(ARCHIVE + 'updates.json.gz')
    assert len(updates) == 18 and all(row['replacement_row']['status'] == 'partial' for row in updates)
    unchanged_ledger(updates)
    native_index = declaration_index()
    rust_index = fresh_inventory()
    proofs = [proof_row(row, native_index, rust_index) for row in updates]
    negatives = negative_checks(updates[0], native_index, rust_index)
    assert all(negatives.values())
    result = {'proofs': proofs, 'negative_checks': negatives, 'base': BASE}
    pathlib.Path('/tmp/dynamic-stale-bindings-proof.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'native_exact_ids': len(proofs), 'public_body_bindings': sum(len(r['rust_bodies']) for r in proofs), 'prior_cpp_status': dict(collections.Counter(r['previous_cpp_status'] for r in proofs)), 'negative_checks': negatives, 'ledger_changes_only_expected18': True, 'new_test_credit': 0}))


run_verification()
