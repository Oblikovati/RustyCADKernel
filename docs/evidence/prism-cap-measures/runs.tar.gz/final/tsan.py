from pathlib import Path
import subprocess,os,json,time,hashlib
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-cap-measures');stage=Path('/tmp/martensite-prism-cap-final')
expected=json.loads((stage/'source-before.json').read_text())
def hashes():return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in expected}
env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/nightly-2026-09-25-x86_64-unknown-linux-gnu/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2';env['RUSTFLAGS']='-Zsanitizer=thread';env['CARGO_TARGET_DIR']=str(stage/'tsan-target')
command=['cargo','test','--manifest-path',str(stage/'extracted/Cargo.toml'),'--offline','--locked','-Zbuild-std','--target','x86_64-unknown-linux-gnu','--lib','plane_tests::failure_tests::independent_threads_return_identical_owned_reports','--','--nocapture']
before=hashes();started=time.time()
with (stage/'logs/ordinary-host-tsan.log').open('w') as output:
    code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
after=hashes();log=(stage/'logs/ordinary-host-tsan.log').read_text()
report={'command':command,'cwd':str(repo),'toolchain':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'environment_changes':{'PATH_prefix':'/home/vmiguel/.rustup/toolchains/nightly-2026-09-25-x86_64-unknown-linux-gnu/bin','CARGO_BUILD_JOBS':'2','RUSTFLAGS':'-Zsanitizer=thread','CARGO_TARGET_DIR':str(stage/'tsan-target')},'host_instrumentation_changes':False,'exit_code':code,'elapsed_seconds':time.time()-started,'source_unchanged':before==expected==after,'test_output_started':'running 1 test' in log,'passed':code==0 and '1 passed' in log}
(stage/'tsan.json').write_text(json.dumps(report,indent=2)+'\n');(stage/'tsan-source-bookends.json').write_text(json.dumps({'before':before,'after':after},indent=2)+'\n');print(json.dumps(report),flush=True)
assert report['source_unchanged']
