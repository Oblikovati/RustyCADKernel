import collections,gzip,hashlib,json,pathlib,re,subprocess,tarfile
root=pathlib.Path('/tmp/rustycad-base-sequence-reconciliation');main=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();p=root/'porting/audits/base-sequence-api-reconciliation.json';s=json.loads(p.read_text())
results=json.load(open('/tmp/base-sequence-check-results.json'));assert all(x['exit_code']==0 for x in results)
rustlog=pathlib.Path('/tmp/base-sequence-rust.log').read_text();nativelog=pathlib.Path('/tmp/base-sequence-originals.log').read_text()
passed=sum(int(n)for n in re.findall(r'test result: ok\. (\d+) passed',rustlog));assert passed==51
native_names=re.findall(r'\[       OK \] (NCollection_SequenceTest\.\S+) \(',nativelog)
rust_names=re.findall(r'test (NCollection_SequenceTest__\S+) \.\.\. ok',rustlog)
assert len(native_names)==len(rust_names)==20;assert {n.replace('.','__')for n in native_names}==set(rust_names)
s['original_runtime_name_joins']=[{'native':n,'rust':n.replace('.','__')}for n in sorted(native_names)]
s['runtime']={'rust_passed':passed,'native_original_passed':20,'original_name_joins':20,'new_original_test_credit':0,'native_fixture_rows':{scope:len(pathlib.Path('/tmp/base-sequence-'+scope+'-run.log').read_text().splitlines())for scope in ['storage','generic_iterator','self_splice','readonly_node','method']},'all_native_fixture_outputs_byte_equal':True,'miri_rerun':False,'full_workspace_rerun':False,'note':'Existing tests and native fixtures were re-run unchanged; this receipt does not imply method-by-method complete behavior or all specialization/configuration closure.'}
s['checks']={'validator_tests_passed':23,'standalone_replay_exit_code':0,'fresh_rustdoc_exit_code':0,'formatter_exit_code':0,'git_diff_check_exit_code':0}
s['validation_command']='PYTHONPATH=tools python3 tools/verify_base_sequence_bindings.py'
s['validator_test_command']='PYTHONPATH=tools:tools/tests python3 -m unittest test_api_binding_replay test_base_sequence_bindings -v'
s['capture_command']='CARGO_TARGET_DIR=/tmp/rustycad-base-api-check cargo +nightly-2026-09-25 rustdoc --locked -p rustycad-tkernel --lib -- -Z unstable-options --output-format json --document-private-items'
s['runtime_commands']=results
s['validation_artifacts']={}
logs={r['stage']:pathlib.Path(r['log'])for r in results}
logs.update({n:pathlib.Path('/tmp/base-sequence-'+n+'.log')for n in ['rustdoc','format','binding-tests','replay']})
for label,source in logs.items():
 dest=root/'porting/runtime-evidence'/('base-sequence-api-'+label+'.gz');dest.write_bytes(gzip.compress(source.read_bytes(),mtime=0));entry={'path':str(dest.relative_to(root)),'sha256':sha(dest),'uncompressed_sha256':sha(source)};s['validation_artifacts'][label]=entry
for cmd in s['runtime_commands']:cmd['log']=s['validation_artifacts'][cmd['stage']]['path']
s['historical_receipt_findings']=[
 {'path':'porting/audits/base-sequence-method-batch.json','finding':'The earlier raw-engine/custom-node absence and typed Vec-only engine descriptions are superseded by current public BaseSequence/BaseSequenceBasicIterator and SequenceTopology containing BaseSequence.'},
 {'path':'porting/audits/base-sequence-storage-batch.json','finding':'The earlier missing BasicIterator, unexposed protected fields and absent self-splice helpers are now present. Compiler binding is supplied here; historical snapshots remain scoped to their original source hashes.'},
 {'path':'porting/audits/base-sequence-generic-methods.json','finding':'The statement that typed Sequence retains a separate vector-of-owned-nodes engine is stale; current sequence.rs and sequence/topology.rs use canonical BaseSequence. This does not establish complete subclass/ABI/language equivalence.'}]
s['evidence_groups']={
 'storage':{'fixtures':['tkernel_base_sequence_storage_contracts','tkernel_base_sequence_self_splice_contracts'],'domain':'Valid raw-node topology, native cache/index rules, callback ordering and allocator retention, explicit native self-splice cycles. Checked Rust invalid-index extensions are not native unchecked-pointer behavior.'},
 'basic':{'fixtures':['tkernel_base_sequence_generic_iterator_contracts','tkernel_base_sequence_readonly_node_contracts'],'domain':'Both historical conversion directions, custom-node offset projection and const/mutable dispatch. C++ IsConstant is !Rust MUTABLE. Value always returns readonly reference, unlike mutable dereference/arrow. Rust methods require explicit unsafe lifetime/alias guarantees.'},
 'field':{'domain':'Rust public fields expose native protected metadata through composition; no C++ inheritance layout/ABI equivalence claim.'},
 'nominal':{'domain':'Compiler-visible BaseSequence, raw Iterator, generic BasicIterator. C++ virtual destruction/subclass dispatch, iterator aliases, allocation macros and full generic obligations remain open.'}}
s['remaining_actions']=['Resolve three conditional body mappings (Node/operator*/operator->) with explicit compiler impl-context selectors; retain both const and mutable bodies.','Audit eight object allocation overloads and six native iterator alias contracts separately.','Prove virtual destructor/subclass behavior and Rust member drop order rather than treating absence of a callable Drop body as coverage.','Keep operator!= default-trait dependency explicit; project eq body alone is not an observed ne body.','Native defaults, protected customization, checked Rust extensions, pointer lifetime/alias obligations, noexcept and configuration closure remain partial.']
s['limitations']=['126 captured records and101 visible candidates are this compiler capture scope, not a proven complete all-platform/configuration denominator.','No production Rust behavior changed; 71 partial mappings link existing implementation/evidence and correct eight broad implementation claims plus two obsolete exclusions.','Native template-owned non-candidates and private records are retained without separate API credit.','Fresh capture is TKernel only; published whole-workspace API inventory remains unchanged.','The source archive includes scoped base implementations and fixtures, not full workspace dependency closure.']
s['implemented_api_credit_delta']=-8;s['accounted_exclusion_delta']=-2;s['raw_and_partial_surface_credit_only']=True
matrix=[json.loads(l)for l in (root/s['matrix_path']).read_text().splitlines()];catalog=[json.loads(l)for l in (root/s['catalog_path']).read_text().splitlines()]
sources={r['source_file']for r in catalog}
sources.update(str(f.relative_to(root))for f in(root/'crates/tkernel/src/ncollection/sequence/base_storage').rglob('*.rs'))
sources.update(str(f.relative_to(root))for f in(root/'crates/tkernel/src/ncollection/sequence/basic_iterator').rglob('*.rs'))
sources.update(['crates/tkernel/src/ncollection/sequence.rs','crates/tkernel/src/ncollection/sequence/topology.rs','crates/tkernel/src/ncollection/sequence/basic_node.rs'])
sources.update(str(f.relative_to(root))for f in(root/'crates/tkernel/tests').glob('base_sequence*.rs'))
sources.update(str(f.relative_to(root))for f in(root/'crates/tkernel/tests/base_sequence_generic_contracts').glob('*.rs'))
sources.update(str(f.relative_to(root))for f in(root/'tools/oracle').glob('tkernel_base_sequence_*'))
s['audited_source_sha256']={name:sha(root/name)for name in sorted(sources)}
s['native_source_sha256']={name:sha(main.parent/'OCCT'/name)for name in ['src/FoundationClasses/TKernel/NCollection/NCollection_BaseSequence.hxx','src/FoundationClasses/TKernel/NCollection/NCollection_BaseSequence.cxx']}
wrapper=main/'target/occt-modeling-full/include/opencascade/NCollection_BaseSequence.hxx';resolved=pathlib.Path(re.search(r'#include "([^"]+)"',wrapper.read_text()).group(1));assert sha(resolved)==s['native_source_sha256']['src/FoundationClasses/TKernel/NCollection/NCollection_BaseSequence.hxx']
s['native_artifacts']={'include_wrapper_sha256':sha(wrapper),'resolved_header':str(resolved),'TKernel_library_sha256':sha(main/'target/occt-modeling-full/lin64/gcc/libi/libTKernel.so'),'original_gtest_binary_sha256':sha(main/'target/occt-modeling-full/lin64/gcc/bini/OpenCascadeGTest')}
s['proof_tools_sha256']={name:sha(root/name)for name in ['tools/api_binding_replay.py','tools/api_binding_transaction.py','tools/verify_base_list_bindings.py','tools/verify_base_sequence_bindings.py','tools/tests/test_base_sequence_bindings.py']}
archive=root/'porting/runtime-evidence/base-sequence-api-sources.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name in sorted(sources):tar.add(root/name,arcname=name)
 for name in ['reconcile-base-sequence.py','check-base-sequence-evidence.py','finalize-base-sequence-proof.py']:tar.add('/tmp/'+name,arcname='audit-scripts/'+name)
s['source_archive']={'path':str(archive.relative_to(root)),'sha256':sha(archive)}
command_archive=root/'porting/runtime-evidence/base-sequence-api-commands.json.gz'
command_archive.write_bytes(gzip.compress(json.dumps(s.pop('runtime_commands'),indent=2).encode(),mtime=0))
s['runtime_command_archive']={'path':str(command_archive.relative_to(root)),'sha256':sha(command_archive)}
p.write_text(json.dumps(s,indent=2)+'\n');assert len(p.read_text().splitlines())<500,len(p.read_text().splitlines())
print({'rust':passed,'original_joins':20,'native_probe_rows':sum(s['runtime']['native_fixture_rows'].values()),'summary_lines':len(p.read_text().splitlines())})
