import os,pathlib,subprocess,json
root=pathlib.Path('/tmp/rustycad-base-sequence-reconciliation');main=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
env=os.environ|{'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/tmp/rustycad-base-api-check'}
targets=['base_sequence_storage_contracts','base_sequence_generic_contracts','base_sequence_self_splice_contracts','base_sequence_method_contracts','ncollection_sequence']
command=['cargo','test','--locked','-p','rustycad-tkernel']
for target in targets:command+=['--test',target]
steps=[('rust',command)]
lib=main/'target/occt-modeling-full/lin64/gcc/libi';include=main/'target/occt-modeling-full/include/opencascade'
for scope in ['storage','generic_iterator','self_splice','readonly_node','method']:
 stem='tkernel_base_sequence_'+scope+'_contracts'
 steps.append((scope+'-compile',['g++','-std=c++17','-O2','-I'+str(include),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(lib),'-Wl,-rpath,'+str(lib),'-lTKernel','-o',f'/tmp/base-sequence-{scope}-oracle']))
 steps.append((scope+'-run',[f'/tmp/base-sequence-{scope}-oracle']))
steps.append(('originals',[str(main/'target/occt-modeling-full/lin64/gcc/bini/OpenCascadeGTest'),'--gtest_filter=NCollection_SequenceTest.*']))
results=[]
for name,command in steps:
 log=pathlib.Path(f'/tmp/base-sequence-{name}.log')
 with log.open('wb')as out:completed=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 results.append({'stage':name,'command':command,'exit_code':completed.returncode,'log':str(log)})
 if completed.returncode:break
 if name.endswith('-run'):assert log.read_bytes()==(root/'tools/oracle'/('tkernel_base_sequence_'+name[:-4]+'_contracts.expected')).read_bytes(),name
pathlib.Path('/tmp/base-sequence-check-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([(r['stage'],r['exit_code'])for r in results]))
