import hashlib
import json
from pathlib import Path
import platform
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-orientation')
CHECKS = Path('/tmp/martensite-prism-orientation-checks')
ALGEBRA = Path('/tmp/martensite-prism-orientation-algebra')
STAGE = Path('/tmp/martensite-prism-orientation-evidence')
DEST = ROOT / 'docs/evidence/prism-orientation'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_file(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def stage():
    assert not STAGE.exists()
    for source in CHECKS.iterdir():
        if source.is_file():
            copy_file(source, STAGE/'runs'/source.name)
    for source in (CHECKS/'frozen').iterdir():
        if source.is_file():
            copy_file(source, STAGE/'runs/frozen'/source.name)
    for source in ALGEBRA.iterdir():
        if source.is_file():
            copy_file(source, STAGE/'algebra'/source.name)
    names = subprocess.check_output(['git','diff','--name-only','f4cd79ae2','e60b9542f'],cwd=ROOT).decode().splitlines()
    for name in names:
        copy_file(ROOT/name, STAGE/'candidate-source'/name)
    return names


def test_count(name):
    text = (CHECKS/'frozen'/(name+'.log')).read_text()
    return sum(map(int,re.findall(r'test result: ok\. (\d+) passed',text)))


def receipt(names):
    matrix=json.loads((CHECKS/'frozen/matrix.json').read_text())
    sanitizer=json.loads((CHECKS/'frozen/sanitizer.json').read_text())
    assert matrix['source_unchanged'] and sanitizer['source_unchanged']
    assert all(row['exit_code']==0 for row in matrix['commands'])
    return dict(operation='Martensite private prism orientation', behavior_version=1,
        source_revision=matrix['revision'], baseline_revision='bf5745181', base_revision='f4cd79ae2',
        platform=platform.platform(), source_bookends=15789,
        candidate_files={name:digest(ROOT/name) for name in names},
        checks={name:test_count(name) for name in ['focused','tests','doctests','embedding-baseline']},
        matrix=matrix, sanitizer=sanitizer,
        algebra=json.loads((ALGEBRA/'verification.json').read_text()),
        concurrency=dict(independent_workers=8,repetitions_per_worker=4,process_replays=2),
        scope=dict(orientation='complete conditional face and trim orientation for admitted fresh embedding',
                   native_winding='DerivedFromFreshFacedWinding; no independently retained raw native contribution',
                   body='incomplete; unchanged diagnostics and coverage',frozen_topology_endpoint_composition='pending'),
        provenance=dict(initial_wrapper='system Cargo1.95 rejected +1.99.0, exit101; pinned direct toolchain succeeded',
                        compiler_correction='initial domain test used nonexistent Orientation::reverse method; corrected to existing top_abs::reverse',
                        prefreeze='diagnostic-only: overlapped final SendSync test macro edit; frozen matrix reran all checks',
                        algebra_transport='initial math.run input key rejected before computation; payload request succeeded'),
        exclusions=['no native OCCT execution or new native fixtures','no tessellation or GPU acceptance',
                    'no geometry evaluator, classifier, topology or endpoint capture duplication',
                    'no full body, tolerance, public contract, naming or Kernel#10 completion',
                    'no performance or allocation improvement claimed','no host protection or instrumentation changes'])


def main():
    names=stage()
    report=receipt(names)
    sanitizer=report['sanitizer']
    log=(CHECKS/'frozen/ordinary-host-tsan.log').read_text()
    sanitizer['test_output_started']='running 1 test' in log
    sanitizer['status']='passed' if sanitizer['command']['exit_code']==0 else 'incomplete'
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    files=sorted(p for p in STAGE.rglob('*') if p.is_file())
    (STAGE/'SHA256SUMS').write_text(''.join(digest(p)+'  '+str(p.relative_to(STAGE))+'\n' for p in files))
    with tarfile.open(DEST/'runs.tar.gz','w:gz') as archive:
        for p in sorted(STAGE.rglob('*')):
            if p.is_file(): archive.add(p,arcname=str(p.relative_to(STAGE)),recursive=False)
    print(json.dumps(dict(candidate_files=len(names),retained_files=len(files)+1,archive_bytes=(DEST/'runs.tar.gz').stat().st_size)))


if __name__=='__main__':
    main()
