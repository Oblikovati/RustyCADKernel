import json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();tree=Path(sys.argv[1]).resolve();branch=sys.argv[2];out=root/sys.argv[3]
def git(*args,cwd=root):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
tip=git('rev-parse','HEAD',cwd=tree)
assert git('branch','--show-current')=='main'
assert git('branch','--show-current',cwd=tree)==branch
assert not git('status','--porcelain',cwd=tree),'unaccounted local work'
assert subprocess.run(['git','merge-base','--is-ancestor',tip,'main']).returncode==0
consumers=[];unreadable=[];other_users=0
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if proc.stat().st_uid!=os.getuid():
   other_users+=1;continue
 except FileNotFoundError:continue
 refs=[]
 for item in [proc/'cwd',proc/'exe',*list((proc/'fd').glob('*'))]:
  try:
   target=os.readlink(item)
   if target==str(tree) or target.startswith(str(tree)+'/'):refs.append(str(item)+': '+target)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:unreadable.append(str(item))
 try:
  with (proc/'maps').open() as stream:
   for line in stream:
    if str(tree)+'/' in line:refs.append('mapped file: '+line.strip())
 except (FileNotFoundError,ProcessLookupError):pass
 except PermissionError:unreadable.append(str(proc/'maps'))
 if refs:consumers.append({'pid':int(proc.name),'references':refs})
assert not consumers,consumers
unreadable_services=[]
for pid in sorted({Path(name).parts[2] for name in unreadable}):
 comm=(Path('/proc')/pid/'comm').read_text().strip()
 assert (pid,comm) in {('1551','systemd'),('1568','(sd-pam)'),('2115','gpg-agent'),('2821','ai-memory')},(pid,comm)
 unreadable_services.append({'pid':int(pid),'comm':comm,'reason':'Inspected long-lived login/credential/memory service, started before this batch; not an agent build or checkout task. Protected process references were not bypassed.'})
receipt={'tree':str(tree),'branch':branch,'tip':tip,'clean':True,'ancestor_of_main':True,'process_consumers':consumers,'unreadable_process_references':unreadable,'process_audit_scope':'all current-user processes: cwd, executable, fd and mappings','other_user_processes':other_users,'protected_service_exclusions':unreadable_services}
subprocess.run(['git','worktree','remove',str(tree)],check=True)
subprocess.run(['git','branch','-d',branch],check=True)
receipt['tree_deleted']=not tree.exists();receipt['branch_deleted']=subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch]).returncode==1
assert receipt['tree_deleted'] and receipt['branch_deleted']
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
