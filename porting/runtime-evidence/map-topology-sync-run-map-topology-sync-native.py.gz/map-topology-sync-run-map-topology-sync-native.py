import os,subprocess
from pathlib import Path
root=Path('/tmp/rustycad-map-topology-sync');build=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full');libs=build/'lin64/gcc/libi';env=dict(os.environ,LD_LIBRARY_PATH=str(libs))
for stem,expected in [('tkernel_double_map_canonical_contracts',['tkernel_double_map_canonical_contracts.expected']),('tkernel_indexed_map_canonical',[f'tkernel_indexed_map_canonical_{group}.expected' for group in ['0','1','observer']])]:
 subprocess.run(['g++','-std=c++17','-fno-access-control','-I'+str(build/'include/opencascade'),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(libs),'-lTKernel','-o','/tmp/topology-'+stem],check=True)
 output=subprocess.check_output(['/tmp/topology-'+stem],env=env)
 assert output==b''.join((root/'tools/oracle'/name).read_bytes() for name in expected)
 Path('/tmp/map-topology-sync-native-'+stem+'.log').write_bytes(output)
 print(stem,len(output.splitlines()),'matched',flush=True)
with open('/tmp/map-topology-sync-legacy.log','w') as output:
 result=subprocess.run([str(build/'lin64/gcc/bini/OpenCascadeGTest'),'--gtest_filter=NCollection_DoubleMapTest.*:NCollection_IndexedMapTest.*:NCollection_IndexedDataMapTest.*:NCollection_DataMapTest.*:NCollection_MapTest.*'],env=env,stdout=output,stderr=subprocess.STDOUT)
print('legacy',result.returncode,flush=True)
assert result.returncode==0
