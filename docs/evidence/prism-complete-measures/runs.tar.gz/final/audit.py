from pathlib import Path
import re,json,ast
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-complete-measures');stage=Path('/tmp/martensite-complete-measures-final')
roots=['crates/tkbo/src/sketch_region_prism/region_certificate/measurements/complete','crates/tkbo/src/sketch_region_prism/region_certificate/measurements/tests/complete','crates/tkmath/src/predicates/roots/metric_bounds/enclosure_sum']
files=[p for root in roots for p in (repo/root).rglob('*.rs')]+[repo/(roots[1]+'.rs'),repo/(roots[2]+'.rs')];rows=[]
for path in files:
 source=path.read_text();assert len(source.splitlines())<500,path
 clean=re.sub(r'"(?:\\.|[^"\\])*"|//[^\n]*',lambda match:' '*len(match[0]),source)
 for match in re.finditer(r'\bfn\s+(\w+)',clean):
  start=clean.find('{',match.end());depth=1;end=start
  while depth:
   end+=1;depth+=(clean[end]=='{')-(clean[end]=='}')
  length=source[match.start():end+1].count('\n')+1
  rows.append({'path':str(path.relative_to(repo)),'function':match[1],'line':source[:match.start()].count('\n')+1,'length':length})
  assert 4<=length<=20,rows[-1]
script=repo/'crates/tkmath/tests/fixtures/prism_complete_measures/generate.py';tree=ast.parse(script.read_text())
for function in [node for node in tree.body if isinstance(node,ast.FunctionDef)]:
 length=function.end_lineno-function.lineno+1;assert 4<=length<=20,(function.name,length)
 rows.append({'path':str(script.relative_to(repo)),'function':function.name,'line':function.lineno,'length':length})
report={'new_rust_files':len(files),'generator_files':1,'function_count':len(rows),'functions':rows};(stage/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='functions'}))
