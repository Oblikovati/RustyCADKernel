use rustycad_tkernel::ncollection::HSequence;
struct Item(i32);
fn main() {
    let donor = Item(7);
    let destination = HSequence::default();
    #[cfg(not(explicit_constructor))]
    destination.append_ref(&donor);
    #[cfg(explicit_constructor)]
    destination.append_ref_with_constructor(&donor, |source| Item(source.0));
    assert_eq!(destination.sequence(|s| s.first().map(|x| x.0)), Some(7));
    assert_eq!(donor.0, 7);
}
