import gzip,hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/prism-diagnostic-envelope-integration-2026-10-14';candidate=root/'docs/evidence/prism-diagnostic-envelope-v1-2026-10-14';base=root/'docs/evidence/prism-publication-v1-2026-10-14';raw=root/'target/diagnostic-main-replay';raw.mkdir(exist_ok=False)
def sha(blob):return hashlib.sha256(blob).hexdigest()
def snapshot():return {n:sha((root/n).read_bytes()) for n in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],text=True).split('\0') if n}
report=json.loads((out/'integrated-main.json').read_text());assert report['checks_passed'];before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
records=[]
def run(needle,label,num,extra=None):
 cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',needle,'--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env={**env,**(extra or {})},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{label}-{num}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0;return p.stdout
with tarfile.open(candidate/'typed-codec-prefix.tar.gz') as archive:
 prior_before=json.load(archive.extractfile('source-before.json'));prior_after=json.load(archive.extractfile('source-after.json'));assert prior_before['files']==prior_after['files']
 for label,needle,var,member in [('typed','full_typed_refusal_process_receipt','MARTENSITE_TYPED_DIAGNOSTIC_RECEIPT','full-0.bin'),('legacy-context','preparation_diagnostic_process_receipt','MARTENSITE_PREPARATION_DIAGNOSTIC_RECEIPT','legacy-context-0.bin')]:
  expected=archive.extractfile(member).read()
  for num in [1,2]:
   path=raw/f'{label}-{num}.bin';run(needle,label,num,{var:str(path)});blob=path.read_bytes();assert blob==expected;(out/f'{label}-{num}.bin.gz').write_bytes(gzip.compress(blob,mtime=0));records.append({'label':label,'process':num,'bytes':len(blob),'sha256':sha(blob)})
cases=[('join','joined_math_byte_receipt','same-body-prism-proof-v1:',base/'join-1.bin.gz'),('measures','joined_measure_process_replay','joined-measures-v1=',base/'measures-1.bin.gz'),('tolerance','exact_tolerance_bytes_replay_across_threads_and_operations','prism-exact-tolerance-v2:',base/'tolerance-1.bin.gz'),('publication','publication_process_replay','named-prism-publication-v1=',base/'publication-1.bin.gz'),('request','owned_request_process_receipt','owned-prism-request-v1:',root/'crates/tkbo/src/sketch_region_prism/owned_request/request_replay/fixtures/request-v1.bin')]
for label,needle,marker,fixture in cases:
 expected=gzip.decompress(fixture.read_bytes()) if fixture.suffix=='.gz' else fixture.read_bytes()
 for num in [1,2]:
  output=run(needle,label,num);matched=re.findall(re.escape(marker)+r'([0-9a-f]+)',output.decode());assert len(matched)==1;blob=bytes.fromhex(matched[0]);assert blob==expected;records.append({'label':label,'process':num,'bytes':len(blob),'sha256':sha(blob)})
assert snapshot()==before
(out/'supplement.json').write_text(json.dumps({'source_revision':report['integration_revision'],'source_unchanged':True,'candidate_source_bookends_verified':True,'resolved_module_union':report['approved_union'],'replays':records,'scope':'Complete supported preparation envelopes only; unsupported owner payloads and publication attribution remain explicit incomplete obligations'},indent=2)+'\n');(out/'supplement-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Diagnostic integration supplement passed',flush=True)
