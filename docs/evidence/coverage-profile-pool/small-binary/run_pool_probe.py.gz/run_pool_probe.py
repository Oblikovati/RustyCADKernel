"""Measure one actual binary; filename policy is the only changing runtime input."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT: Path = Path(__file__).resolve().parent
BINARY: Path = ROOT / "pool-probe"
LLVM: Path = Path("/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin")
TESTS: tuple[str, ...] = ("positive_path", "negative_path", "zero_path", "mixed_path")
POLICIES: dict[str, str] = {"pid": "sample-%p-%32m.profraw", "pool1": "sample-%1m.profraw", "pool4": "sample-%4m.profraw"}


def launch_test(folder: Path, pattern: str, test: str) -> subprocess.Popen[str]:
    environment: dict[str, str] = os.environ.copy()
    environment["LLVM_PROFILE_FILE"] = str(folder / pattern)
    command: list[str] = [str(BINARY), "--exact", test, "--test-threads=1", "--nocapture"]
    process: subprocess.Popen[str] = subprocess.Popen(command, env=environment, text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert process.stdout is not None
    prefix: str = ""
    for _ in range(8):
        prefix += process.stdout.readline()
        if "MARTENSITE_READY" in prefix:
            return process
    raise RuntimeError(f"received {prefix!r}; expected test-ready marker")


def release_batch(processes: list[subprocess.Popen[str]], folder: Path, offset: int) -> list[int]:
    exits: list[int] = []
    for process in processes:
        assert process.stdin is not None
        process.stdin.write("release\n")
        process.stdin.flush()
    for ordinal, process in enumerate(processes, offset):
        stdout, stderr = process.communicate(timeout=20)
        (folder / f"process-{ordinal}.stdout").write_text(stdout)
        (folder / f"process-{ordinal}.stderr").write_text(stderr)
        exits.append(process.returncode)
    return exits


def measure_files(folder: Path) -> dict[str, int]:
    profiles: list[Path] = sorted(folder.glob("*.profraw"))
    return {"files": len(profiles), "logical_bytes": sum(p.stat().st_size for p in profiles), "allocated_bytes": sum(p.stat().st_blocks * 512 for p in profiles)}


def run_policy(policy: str, concurrency: int) -> dict[str, object]:
    folder: Path = ROOT / f"{policy}-c{concurrency}"
    folder.mkdir()
    exits: list[int] = []
    for offset in range(0, 32, concurrency):
        processes: list[subprocess.Popen[str]] = [launch_test(folder, POLICIES[policy], TESTS[i % 4]) for i in range(offset, offset + concurrency)]
        exits += release_batch(processes, folder, offset)
    results: dict[str, object] = measure_files(folder)
    results["exits"] = exits
    results["stderr_bytes"] = sum(p.stat().st_size for p in folder.glob("*.stderr"))
    return results


def merge_and_report(policy: str, concurrency: int) -> None:
    folder: Path = ROOT / f"{policy}-c{concurrency}"
    command: list[str] = [str(LLVM / "llvm-profdata"), "merge", "-sparse", *map(str, sorted(folder.glob("*.profraw"))), "-o", str(folder / "merged.profdata")]
    subprocess.run(command, check=True, capture_output=True)
    show: list[str] = [str(LLVM / "llvm-profdata"), "show", "--all-functions", "--counts", str(folder / "merged.profdata")]
    (folder / "counters.txt").write_bytes(subprocess.run(show, check=True, capture_output=True).stdout)
    for kind in ["json", "lcov"]:
        export: list[str] = [str(LLVM / "llvm-cov"), "export", str(BINARY), "-instr-profile=" + str(folder / "merged.profdata"), "-format=" + ("text" if kind == "json" else "lcov")]
        (folder / f"coverage.{kind}").write_bytes(subprocess.run(export, check=True, capture_output=True).stdout)


def experiment() -> None:
    measurements: dict[str, object] = {}
    for concurrency in [1, 4, 8, 32]:
        for policy in POLICIES:
            key: str = f"{policy}-c{concurrency}"
            measurements[key] = run_policy(policy, concurrency)
            merge_and_report(policy, concurrency)
            print(key, measurements[key], flush=True)
    measurements["binary_sha256"] = hashlib.sha256(BINARY.read_bytes()).hexdigest()
    (ROOT / "measurements.json").write_text(json.dumps(measurements, indent=2) + "\n")


if __name__ == "__main__":
    experiment()
