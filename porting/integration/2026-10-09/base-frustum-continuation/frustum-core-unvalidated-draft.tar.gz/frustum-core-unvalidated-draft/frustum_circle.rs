//! Native circle overlap, retaining the untransformed center used by OCCT 3d097a0.
use super::SelectMgrFrustumCore;
use super::frustum_quadric_geometry::{frustum_circle_intersection, frustum_point_inside};
use rustycad_tkernel::standard::Failure;
use rustycad_tkmath::gp::{Direction3, Plane3, Point3, Transform3};

impl SelectMgrFrustumCore {
    fn circle_center_projection(&self) -> Result<Point3, Failure> {
        let ray = Direction3::from_vector(self.view_edge())?;
        let [a, b, c, d] = Plane3::new(self.vertices[0], ray)?.coefficients()?;
        // Preserve the native origin dot product, including signed-zero arithmetic.
        let t = -(Point3::default().xyz().dot(ray.xyz()) + d);
        Ok(Point3::new(a * t, b * t, c * t))
    }
    /// Test an outlined or filled circle with the native projected-center convention.
    /// Example: `core.has_circle_overlap(1., transform, true, false, None)?`.
    pub fn has_circle_overlap(
        &self,
        radius: f64,
        transform: Transform3,
        filled: bool,
        is_ortho: bool,
        inside: Option<&mut bool>,
    ) -> Result<bool, Failure> {
        let vertices = self.outline_vertices(is_ortho);
        if frustum_circle_intersection(
            radius,
            Point3::default(),
            transform,
            &vertices,
            self.view_edge(),
        )? {
            if let Some(flag) = inside {
                *flag = false;
            }
            return Ok(true);
        }
        let center = self.circle_center_projection()?;
        let center_inside = frustum_point_inside(center, &vertices)?;
        let inside_circle = vertices
            .iter()
            .any(|vertex| vertex.distance(&center) > radius);
        if let Some(flag) = inside {
            *flag = inside_circle && center_inside;
        }
        Ok(if filled {
            !inside_circle || (center_inside && inside_circle)
        } else {
            inside_circle && center_inside
        })
    }
}
