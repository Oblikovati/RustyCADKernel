use rustycad_tkernel::ncollection::{Array2,HArray2};
#[derive(Copy)]
struct Trivial(i32);
impl Clone for Trivial { fn clone(&self)->Self { panic!("Clone hook called") } }
fn main() {
 let mut buffer=[Trivial(7),Trivial(9)];
 let source=Array2::from_buffer(&mut buffer,1,2).unwrap();
 let copy=HArray2::from_array(&source);
 assert_eq!(copy.array2().value(0,0).unwrap().0,7);
}
