import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd();base=root/'docs/evidence/prism-joined-measures-v1-2026-10-14';out=root/'docs/evidence/prism-joined-measures-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def hashes():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=hashes();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
seals=0
for line in (base/'SHA256SUMS').read_text().splitlines():
 h,p=line.split(maxsplit=1);assert sha((base/p).read_bytes())==h,p;seals+=1
for p,h in json.loads((base/'reconciliation/artifact-hashes.json').read_text()).items():assert sha((base/p).read_bytes())==h,p;seals+=1
for folder in ('frozen','reconciliation'):
 r=json.loads(gzip.decompress((base/folder/'source-bookends.json.gz').read_bytes()));assert r['before']==r['after']
for p,h in json.loads((base/'reconciliation/candidate-files.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
selectors=[('joined','sketch_region_prism::frozen::joined_measures::tests::replay_tests::joined_measure_process_replay','joined-measures-v1=',base/'frozen/joined-process-1.bin.gz'),('complete','sketch_region_prism::region_certificate::measurements::tests::complete_tests::replay_tests::complete_prism_measure_process_receipt','{"operation":',root/'docs/evidence/prism-proof-join-v1-2026-10-14/complete_corrected-process-1.bin.gz'),('subset','sketch_region_prism::region_certificate::measurements::tests::replay_tests::portable_prism_measure_process_receipt','{"operation":',root/'docs/evidence/prism-proof-join-v1-2026-10-14/cap_subset-process-1.bin.gz'),('exact','sketch_region_prism::exact_tolerance::joined_replay_tests::exact_tolerance_bytes_replay_across_threads_and_operations','prism-exact-tolerance-v2:',root/'docs/evidence/prism-exact-tolerance-integration-2026-10-14/integrated-exact-1.bin.gz')]
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for label,selector,prefix,baseline in selectors:
 expected=gzip.decompress(baseline.read_bytes())
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-{label}-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  if label in ('joined','exact'):
   lines=re.findall(re.escape(prefix)+r'([0-9a-f]+)',p.stdout.decode());assert len(lines)==1;actual=bytes.fromhex(lines[0])
  else:
   lines=[s for s in p.stdout.decode().splitlines() if s.startswith(prefix)];assert len(lines)==1;actual=(lines[0]+'\n').encode()
  assert actual==expected;(out/f'integrated-{label}-{i}.bin.gz').write_bytes(gzip.compress(actual,mtime=0))
 row={'kind':label,'bytes':len(expected),'sha256':sha(expected),'two_processes_match_owned_baseline':True};replays.append(row);print(json.dumps(row),flush=True)
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=lambda payload:set(re.findall(r'^test (.+?) \.\.\. ok$',payload.decode(),re.M))
candidate=names(gzip.decompress((base/'frozen/tests.log.gz').read_bytes()));actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual
assert before==hashes()
receipt={'integration_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_artifacts_verified':seals,'source_unchanged_since_matrix':True,'both_candidate_bookends_equal':True,'reconciled_candidate_files_exact':True,'candidate_test_names':len(candidate),'integrated_test_names':len(actual),'missing_test_names':sorted(candidate-actual),'replays':replays,'warning_denied_docs_exit':p.returncode,'sanitizer':'Not executed for this source; host startup failure remains incomplete'}
(out/'integrated-supplement.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('measurement supplement passed',flush=True)
