from __future__ import annotations
import hashlib, json, re, shutil, tarfile
from pathlib import Path
ROOT=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-seam-pcurve-import')
EVIDENCE=ROOT/'docs/evidence/pcurve-import-v2-2026-10-14'
RAW=Path('/tmp/martensite-pcurve-final-raw')

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def payload(path: Path) -> bytes:
    rows=[line[line.index(b'{"pcurve_import_behavior":'):] for line in path.read_bytes().splitlines() if b'{"pcurve_import_behavior":' in line]
    if len(rows)!=1:
        raise ValueError(f'{path.name}: got {len(rows)} JSON payloads; expected exactly one')
    assert json.loads(rows[0])=={'pcurve_import_behavior':2,'stored':True,'range':[0,1],'reversed':False}
    return rows[0]

shutil.copy2(EVIDENCE/'verification.json',EVIDENCE/'initial-finalizer-receipt.json')
shutil.move(EVIDENCE/'raw-verification.tar.gz',EVIDENCE/'initial-finalizer-raw.tar.gz')
receipt=json.loads((EVIDENCE/'verification.json').read_text())
original=json.loads((RAW/'source-before.json').read_text())
assert original==json.loads((RAW/'source-after.json').read_text())
current={name:sha(ROOT/name) for name in original}
assert current==original
first,second=RAW/'process-0.log',RAW/'process-1.log'
assert first.read_bytes()==second.read_bytes()
assert payload(first)==payload(second)
receipt['two_process_bytes_equal']=True
receipt['whole_process_output_bytes_equal']=True
receipt['process_snapshot']=payload(first).decode()
receipt['receipt_finalizer_recovery']={'original_exit_code':1,'original_all_checks_passed':False,'cause':'The initial parser expected JSON at line start, but libtest emits its test-name prefix on that line. All executed commands already passed.','original_receipt_sha256':sha(EVIDENCE/'initial-finalizer-receipt.json'),'original_archive_sha256':sha(EVIDENCE/'initial-finalizer-raw.tar.gz'),'method':'Strictly extract exactly one expected JSON payload from each retained output; compare both payload and whole output bytes; rehash all original source inputs unchanged.','recovery_source_inputs_unchanged':True}
artifacts={}
for name in ('tkbrep-all-targets','tkbo-all-targets'):
    for relative in re.findall(r'\((target/debug/(?:deps|examples)/[^)]+)\)',(RAW/(name+'.log')).read_text()):
        artifacts[relative]=sha(ROOT/relative)
receipt['executed_artifact_hashes_observed_after_run']=artifacts
receipt['all_checks_passed']=all(row['exit_code']==0 for row in receipt['commands']) and receipt['source_bookends_equal'] and receipt['two_process_bytes_equal'] and receipt['legacy_fixture_unchanged']
shutil.copy2(__file__,RAW/'receipt-recovery.py')
shutil.copy2(EVIDENCE/'initial-finalizer-receipt.json',RAW/'initial-finalizer-receipt.json')
shutil.copy2('/tmp/martensite-pcurve-final-checks.log',RAW/'orchestrator.log')
with tarfile.open(EVIDENCE/'raw-verification.tar.gz','w:gz') as archive:
    archive.add(RAW,arcname='pcurve-import-v2')
receipt['raw_archive_sha256']=sha(EVIDENCE/'raw-verification.tar.gz')
(EVIDENCE/'verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_checks_passed':receipt['all_checks_passed'],'source_commit':receipt['source_commit'],'source_files':receipt['source_file_count'],'test_counts':receipt['test_counts'],'post_run_executable_hashes':len(artifacts)}))
