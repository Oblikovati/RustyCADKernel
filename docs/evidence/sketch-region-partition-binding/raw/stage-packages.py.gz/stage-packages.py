from pathlib import Path
import sys,json,subprocess,hashlib,tarfile
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
from release_inventory import SystemCommands,release_inventory
from release_packages import prepare_release_packages
from release_archives import stage_workspace
commands=SystemCommands();crates=release_inventory(root,commands)
prepare_release_packages(root,commands)
stage=root/'target/partition-binding/extracted';stage_workspace(root/'target/package',stage,crates,root/'Cargo.lock')
archives={str(root/'target/package'/f'{crate.name}-{crate.version}.crate'):hashlib.sha256((root/'target/package'/f'{crate.name}-{crate.version}.crate').read_bytes()).hexdigest() for crate in crates}
(root/'target/partition-binding/archive-build-receipt.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'archives':archives,'stage':str(stage)},indent=2)+'\n')
print('STAGE',stage,flush=True)
