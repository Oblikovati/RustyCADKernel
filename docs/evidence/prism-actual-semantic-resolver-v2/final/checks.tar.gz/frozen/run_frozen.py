import subprocess,pathlib,hashlib,json,time,platform
root=pathlib.Path('target/semantic-resolver-final')
files=subprocess.check_output(['git','ls-files','crates','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],text=True).splitlines()
def snapshot(): return {p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in files}
before=snapshot();(root/'source-before.json').write_text(json.dumps(before,sort_keys=True))
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=['/home/vmiguel/.cargo/bin/rustup','run','1.99.0','cargo']
commands=[('tests',base+['test','-p','rustycad-tkbo','--all-targets','--all-features','-j2']),('docs',base+['test','-p','rustycad-tkbo','--doc','--all-features','-j2']),('clippy',base+['clippy','-p','rustycad-tkbo','--all-targets','--all-features','-j2','--','-D','warnings']),('fmt',base+['fmt','--all','--','--check'])]
results=[]
for name,cmd in commands:
 start=time.monotonic()
 with (root/(name+'.log')).open('wb') as log: result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'argv':cmd,'status':result.returncode,'seconds':time.monotonic()-start})
 print(name,result.returncode,flush=True)
 (root/'commands.json').write_text(json.dumps(results,indent=2))
after=snapshot();(root/'source-after.json').write_text(json.dumps(after,sort_keys=True))
receipt={'revision':revision,'platform':platform.platform(),'source_count':len(files),'equal':before==after,'commands':results}
(root/'gate.json').write_text(json.dumps(receipt,indent=2))
print('Source bookends',len(files),before==after,flush=True)
assert before==after and all(r['status']==0 for r in results)
