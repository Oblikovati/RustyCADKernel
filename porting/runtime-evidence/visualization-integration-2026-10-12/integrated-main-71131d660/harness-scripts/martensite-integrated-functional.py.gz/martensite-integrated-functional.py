import os,sys,json,gzip,hashlib,re,struct
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path.cwd()/'tools'))
from verify_vulkan import run,capture_cases
from vulkan_profiles import probe_profile,confirm_device
from vulkan_capture_artifacts import FileCaptureStore,export_comparison
from vulkan_source_receipt import source_hashes
folder=Path('/tmp/martensite-integrated-gpu-71131d660');start=json.loads((folder/'start.json').read_text());env=os.environ.copy();env['DISPLAY']=':1';assert start['source_sha256']==source_hashes();assert run(['git','rev-parse','HEAD'],env)==start['start_head'];binary=max((p for p in Path('target/debug/deps').glob('toolkit-*') if p.is_file() and os.access(p,os.X_OK)),key=lambda p:p.stat().st_mtime)
executables=[binary,*[Path('target/debug/examples')/name for name in ['offscreen_acceptance','text_capture','text_culling_capture','view_cube_capture','ais_light_source_capture']],*[folder/name for name in ['opengl-reference','native-text_culling','native-view_cube']]];binary_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in executables}
receipt={**start,'binary_sha256':binary_hashes,'profiles':[],'strict_gates_unchanged':True,'local_only':True,'baseline_accepted':False}
text=Path('crates/vulkan/tests/support/text_culling_scene.rs').read_text();modes=re.findall(r'"([^"]+)"',re.search(r'pub const CULLING_MODES:.*?=\s*\[(.*?)\];',text,re.S).group(1));assert len(modes)==19
for name in ['lavapipe','host']:
 p=probe_profile(name,env,list(Path('/usr/share/vulkan/icd.d').glob('*.json')),run,Path('/usr/share/vulkan/icd.d/radeon_icd.json'));entry={'name':name,'device':asdict(p.device),'probe':p.probe,'stages':[]};receipt['profiles'].append(entry)
 output=run(['target/debug/examples/offscreen_acceptance'],p.environment);confirm_device(output,p.device);entry['offscreen_acceptance']=output;print(name,'offscreen acceptance passed',flush=True)
 entry['rust_replay']={}
 for selector in ['shadow_text::','ais_light_source::','text_primitives::','text_culling_test::','point_alpha::','line_alpha::','view_culling::']:
  entry['rust_replay'][selector]=run([str(binary),selector,'--test-threads=1'],p.environment)
 print(name,'source-bound Rust replay passed',flush=True)
 entry['shadow_matrix']=capture_cases(folder/'opengl-reference',Path('target/debug/examples/text_capture'),folder/'shadow'/name,p,'shadow-text');print(name,'Shadow strict',sum(r['status']=='passed' for r in entry['shadow_matrix']),54,flush=True)
 entry['culling']=[]
 for mode in modes:
  output_dir=folder/'culling'/name;output_dir.mkdir(parents=True,exist_ok=True);native=output_dir/f'native-{mode}';ported=output_dir/f'ported-{mode}';gl=run([str(folder/'native-text_culling'),mode,str(native)],p.environment);vk=run(['target/debug/examples/text_culling_capture',mode,str(ported)],p.environment);confirm_device(vk,p.device);row=export_comparison(mode,128,128,native,ported,FileCaptureStore());row.update(native_runtime=gl,ported_runtime=vk,command_exit=0);entry['culling'].append(row)
 print(name,'culling strict',sum(r['status']=='passed' for r in entry['culling']),19,flush=True)
 entry['named_lights']=[]
 for kind in range(4):
  output_dir=folder/'named-lights'/name;output_dir.mkdir(parents=True,exist_ok=True);native=output_dir/f'native-{kind}';ported=output_dir/f'ported-{kind}';gl=run([str(folder/'opengl-reference'),'64','64','0','0',str(native),f'named-light-{kind}'],p.environment);vk=run(['target/debug/examples/ais_light_source_capture',str(kind),str(ported),'named'],p.environment);confirm_device(vk,p.device);row=export_comparison(f'named-light-{kind}',64,64,native,ported,FileCaptureStore());row.update(native_runtime=gl,ported_runtime=vk,command_exit=0);entry['named_lights'].append(row)
 print(name,'named lights strict',sum(r['status']=='passed' for r in entry['named_lights']),4,flush=True)
 output_dir=folder/'view-cube'/name;output_dir.mkdir(parents=True,exist_ok=True);native=output_dir/'native';ported=output_dir/'ported';gl=run([str(folder/'native-view_cube'),str(native)],p.environment);vk=run(['target/debug/examples/view_cube_capture',str(ported)],p.environment);confirm_device(vk,p.device);entry['view_cube']={'native_runtime':gl,'ported_runtime':vk,'command_exit':0,'comparisons':[],'label_toggle_pixels':{}}
 for suffix in ['', '-unlabeled','-lit','-lit-unlabeled']:
  a=native.with_name(native.name+suffix);b=ported.with_name(ported.name+suffix);entry['view_cube']['comparisons'].append(export_comparison('view-cube'+suffix,320,320,a,b,FileCaptureStore()))
  for capture in [a,b]:assert all(0<=v<=1 for v in struct.unpack('<102400f',capture.with_suffix('.depth').read_bytes()))
 for suffix in ['', '-lit']:
  left=ported.with_name(ported.name+suffix).with_suffix('.rgba').read_bytes();right=ported.with_name(ported.name+suffix+'-unlabeled').with_suffix('.rgba').read_bytes();count=sum(left[i:i+4]!=right[i:i+4] for i in range(0,len(left),4));assert count>0;entry['view_cube']['label_toggle_pixels'][suffix or 'default']=count
 print(name,'ViewCube strict',sum(r['status']=='passed' for r in entry['view_cube']['comparisons']),4,entry['view_cube']['label_toggle_pixels'],flush=True)
 (folder/'functional.json.gz').write_bytes(gzip.compress((json.dumps(receipt,indent=2)+'\n').encode(),mtime=0))
assert start['source_sha256']==source_hashes();assert run(['git','rev-parse','HEAD'],env)==start['start_head'];assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha for name,sha in binary_hashes.items());receipt['exit_code']=0;receipt['final_hashes_verified']=True;(folder/'functional.json.gz').write_bytes(gzip.compress((json.dumps(receipt,indent=2)+'\n').encode(),mtime=0));print('final source/binary/HEAD hashes unchanged',flush=True)
