fn main() { println!("TSAN_TOPOLOGY_CONTROL_MAIN_REACHED"); }
