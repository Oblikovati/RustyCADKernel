from pathlib import Path
import os,subprocess
root=Path('/tmp/rustycad-buffer-raw-adoption')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/tmp/rustycad-sparse-base-miri',MIRIFLAGS='-Zmiri-strict-provenance -Zmiri-seed=0 -Zmiri-preemption-rate=1.0')
command=['cargo','+nightly-2026-09-25','miri','test','-p','rustycad-tkernel','--test','buffer_raw_adoption_contracts','owned_allocation_and_lease_are_atomic_against_concurrent_reset']
with open('/tmp/buffer-raw-adoption-fixed-race.log','w') as output:result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
Path('/tmp/buffer-raw-adoption-fixed-race.exit').write_text(str(result.returncode));print('fixed',result.returncode,flush=True)
if result.returncode:raise SystemExit(result.returncode)
subprocess.run(['python3','/tmp/run-buffer-raw-adoption-checks.py','miri'],cwd=root,check=True)
