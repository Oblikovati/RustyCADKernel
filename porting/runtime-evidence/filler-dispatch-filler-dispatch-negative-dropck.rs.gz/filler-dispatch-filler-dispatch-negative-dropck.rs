use rustycad_tkernel::ncollection::{UBTree,BoundingVolume};
#[derive(Clone)]struct B;
impl BoundingVolume for B {fn add(&mut self,_:&Self){}fn is_out(&self,_:&Self)->bool{false}fn square_extent(&self)->f64{0.0}}
fn main(){let tree;let value=String::from("borrowed");tree={let mut t=UBTree::default();t.add(value.as_str(),B);t};assert!(!tree.is_empty());}
