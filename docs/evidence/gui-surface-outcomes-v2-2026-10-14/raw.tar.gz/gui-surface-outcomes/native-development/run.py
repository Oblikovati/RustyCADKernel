import os,sys,subprocess,json,hashlib,re,time,platform
from pathlib import Path
root=Path.cwd();out=root/'target/gui-surface-outcomes/native-development'
sys.path.insert(0,str(root/'tools'))
from vulkan_source_receipt import source_hashes
before=source_hashes();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/home/vmiguel/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
command=['cargo','+1.99.0','test','-p','martensite-vulkan','--lib','--no-run']
with (out/'build.log').open('w') as log: build=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
results={'build_command':command,'build_exit':build.returncode,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':platform.platform(),'runs':[]}
if build.returncode==0:
 binary=root/'target/debug/deps/martensite_vulkan-ddf64f3039f39019'
 layer=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr')
 env['VK_LAYER_PATH']=str(layer/'share/vulkan/explicit_layer.d');env['LD_LIBRARY_PATH']=str(layer/'lib/x86_64-linux-gnu');env.pop('MARTENSITE_VULKAN_DEVICE',None)
 results['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();results['validation_sha256']=hashlib.sha256((layer/'lib/x86_64-linux-gnu/libVkLayer_khronos_validation.so').read_bytes()).hexdigest()
 for name,icd in [('amd','radeon_icd.json'),('lavapipe','lvp_icd.json')]:
  env['VK_DRIVER_FILES']=env['VK_ICD_FILENAMES']='/usr/share/vulkan/icd.d/'+icd
  args=[str(binary),'--exact','backend::window_gui_native_tests::native_gui_surface_phase_gate','--ignored','--nocapture','--test-threads=1']
  record={'driver':name,'command':args,'load_before':os.getloadavg(),'environment':{key:env.get(key) for key in ['DISPLAY','VK_LAYER_PATH','LD_LIBRARY_PATH','VK_DRIVER_FILES','VK_ICD_FILENAMES']}}
  with (out/(name+'.log')).open('w') as log:
   try:record['exit']=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
   except subprocess.TimeoutExpired:record['timed_out']=True
  record['load_after']=os.getloadavg();results['runs'].append(record)
after=source_hashes();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');results['source_bookends_equal']=before==after
(out/'results.json').write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')
print(json.dumps(results))
