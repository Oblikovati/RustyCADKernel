use rustycad_tkernel::ncollection::{BoundingVolume,UBTree};
#[derive(Clone,Default)] struct Bounds;
impl BoundingVolume for Bounds {
 fn add(&mut self,_:&Self) {} fn is_out(&self,_:&Self)->bool {false}
 fn square_extent(&self)->f64 {0.0}
}
fn main() {
 let call: fn(&mut UBTree<i32,Bounds>,usize,&Bounds,&i32,&Bounds)->Option<usize> = UBTree::gemmate_ref;
 let mut tree=UBTree::default();tree.add(1,Bounds);
 assert_eq!(call(&mut tree,0,&Bounds,&2,&Bounds),Some(2));
}
