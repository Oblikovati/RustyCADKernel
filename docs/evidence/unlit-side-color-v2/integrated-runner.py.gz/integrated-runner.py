import gzip,hashlib,json,os,platform,re,subprocess,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
from renderer_archive_inputs import renderer_input_hashes
out=root/'docs/evidence/unlit-side-color-v2';raw=root/'target/integrated-unlit-side-color-v2';raw.mkdir(parents=True,exist_ok=False)
before=renderer_input_hashes(root); revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'tools','VK_LAYER_PATH':str(root/'target/vulkan-validation/extracted/usr/share/vulkan/explicit_layer.d'),'LD_LIBRARY_PATH':str(root/'target/vulkan-validation/extracted/usr/lib/x86_64-linux-gnu')}
for k in ['VK_INSTANCE_LAYERS','VK_LAYER_SETTINGS_PATH','VK_LAYER_ENABLES','VK_LAYER_DISABLES','MARTENSITE_VULKAN_DEVICE','MESA_VK_DEVICE_SELECT']:env.pop(k,None)
commands=[]
def run(name,cmd,extra=None):
 print('starting '+name,flush=True); logfile=raw/(name+'.log')
 with logfile.open('w') as f:r=subprocess.run(cmd,env={**env,**(extra or {})},stdout=f,stderr=subprocess.STDOUT)
 payload=logfile.read_bytes();archive=out/('integrated-'+name+'.log.gz');archive.write_bytes(gzip.compress(payload,mtime=0))
 record={'command':cmd,'exit_code':r.returncode,'environment_overrides':extra or {},'log':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
 counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',payload.decode(errors='replace'))
 if counts:record['tests']={k:sum(int(c[i]) for c in counts) for i,k in enumerate(('passed','failed','ignored'))}
 commands.append(record);print(json.dumps(record),flush=True);(raw/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return payload.decode(errors='replace')
# Compile to target only, compare each binary against the already committed shader.
from vulkan_surface_texture_shaders import surface_shader_variants
from vulkan_mesh_edge_shaders import mesh_edge_shader_variants
from vulkan_fixed_lighting_shaders import fixed_lighting_shader_variants
from vulkan_oit_shaders import oit_geometry_shader_variants
from vulkan_fragment_alpha_shaders import fragment_alpha_variants
variants=[(s,'surface.frag',f) for s,f in surface_shader_variants()]
variants += [(s,'surface.frag',f) for s,stage,f in mesh_edge_shader_variants() if stage=='frag']
variants += [(s,'surface.frag',f) for s,stage,f in fixed_lighting_shader_variants() if stage=='frag' and s.startswith('surface')]
variants += list(oit_geometry_shader_variants())
variants += [(s+'.native-alpha',src,f+('-DMARTENSITE_NATIVE_FRAGMENT_ALPHA=1',)) for s,src,f in fragment_alpha_variants()]
shader_records=[];compiled=raw/'shaders';compiled.mkdir()
with (raw/'shader-check.log').open('w') as log:
 for stem,source,flags in variants:
  if source!='surface.frag':continue
  binary=compiled/(stem+'.frag.spv');cmd=['glslangValidator',*flags,'--target-env','vulkan1.3','-V',str(root/'crates/vulkan/shaders'/source),'-o',str(binary)]
  subprocess.run(cmd,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['spirv-val','--target-env','vulkan1.3',str(binary)],env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
  assert binary.read_bytes()==(root/'crates/vulkan/shaders'/binary.name).read_bytes(),binary
  shader_records.append({'binary':binary.name,'defines':flags,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
print('shader variants verified '+str(len(shader_records)),flush=True)
repeats=[]
for driver,icd in [('amd','radeon'),('lavapipe','lvp')]:
 extra={'VK_DRIVER_FILES':f'/usr/share/vulkan/icd.d/{icd}_icd.json','VK_ICD_FILENAMES':f'/usr/share/vulkan/icd.d/{icd}_icd.json'}
 run('full-'+driver,['cargo','+1.99.0','test','-p','martensite-vulkan','--all-targets','--all-features','--locked','--no-fail-fast','--','--test-threads=1'],extra)
 capture_sets=[]
 for index in (1,2):
  text=run(f'repeat-{driver}-{index}',['cargo','+1.99.0','test','-p','martensite-vulkan','--test','toolkit','--all-features','--locked','unlit_face_color_gpu','--','--test-threads=1','--nocapture'],extra)
  captures=[]
  for line in text.splitlines():
   marker='{"unlit_side_capture_bytes":'
   if marker in line:
    row=json.loads(line[line.index(marker):])['unlit_side_capture_bytes'];captures.append(bytes(row['rgba'])+bytes(row['depth']))
  capture_sets.append(captures)
 repeats.append({'driver':driver,'capture_count':len(capture_sets[0]),'byte_identical_between_processes':len(capture_sets[0])==20 and capture_sets[0]==capture_sets[1],'capture_sha256':[hashlib.sha256(c).hexdigest() for c in capture_sets[0]]})
run('clippy',['cargo','+1.99.0','clippy','-p','martensite-vulkan','--all-targets','--all-features','--locked','--','-D','warnings'])
run('docs',['cargo','+1.99.0','test','-p','martensite-vulkan','--doc','--all-features','--locked'])
run('fmt',['cargo','+1.99.0','fmt','--all','--','--check'])
after=renderer_input_hashes(root);book=out/'integrated-source-bookends.json.gz';book.write_bytes(gzip.compress(json.dumps({'before':before,'after':after},sort_keys=True).encode(),mtime=0))
shaderfile=out/'integrated-shader-provenance.json.gz';shaderfile.write_bytes(gzip.compress(json.dumps(shader_records,indent=2).encode(),mtime=0))
fixture=hashlib.sha256((root/'crates/vulkan/tests/fixtures/unlit-side-color/legacy-v1.txt').read_bytes()).hexdigest()
receipt={'integration_revision':revision,'candidate':'be2db095851c798ddaa63af17ac2189bc1408b12','platform':platform.platform(),'environment':{k:env.get(k) for k in ['CARGO_BUILD_JOBS','VK_LAYER_PATH','LD_LIBRARY_PATH','VK_INSTANCE_LAYERS','VK_LAYER_SETTINGS_PATH','VK_LAYER_ENABLES','VK_LAYER_DISABLES']},'validation_library_sha256':hashlib.sha256((root/'target/vulkan-validation/extracted/usr/lib/x86_64-linux-gnu/libVkLayer_khronos_validation.so').read_bytes()).hexdigest(),'commands':commands,'shader_variants':len(shader_records),'shader_provenance_sha256':hashlib.sha256(shaderfile.read_bytes()).hexdigest(),'raw_repeat_comparisons':repeats,'source_inputs_unchanged':before==after,'source_bookends_sha256':hashlib.sha256(book.read_bytes()).hexdigest(),'v1_fixture_sha256':fixture,'limitations':['Five existing ignored Vulkan tests remain explicit per driver.','Older system validation layer failures and precise upstream ordering fix are preserved in candidate and display comparison evidence.','No live OCCT execution, GL source-string legacy mapping credit, default migration, release, application, native-window, cross-platform or performance acceptance.','No loaded-library runtime trace; manifest/library search paths and file hashes are explicit.']}
receipt['checks_passed']=all(c['exit_code']==0 for c in commands) and before==after and all(r['byte_identical_between_processes'] for r in repeats) and len(shader_records)==192 and fixture=='00c99f1202402cfc0fda6300bdd260fccefa72124555b40d855a8d909714f27b'
(out/'integrated-main.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'checks_passed':receipt['checks_passed'],'revision':revision}),flush=True)
sys.exit(0 if receipt['checks_passed'] else 1)
