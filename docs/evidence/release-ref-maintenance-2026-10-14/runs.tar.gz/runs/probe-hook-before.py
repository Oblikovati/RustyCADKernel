#!/usr/bin/env python3
import pathlib,subprocess,sys,json,os
updates=sys.stdin.read();rows=[]
for line in updates.splitlines():
 old,new,ref=line.split()
 if ref.startswith('refs/tags/'):
  current=subprocess.run(['git','rev-parse','--verify','--quiet','--end-of-options',ref],capture_output=True,text=True)
  peeled=subprocess.run(['git','rev-parse',ref+'^{commit}'],capture_output=True,text=True)
  rows.append({'old':old,'new':new,'ref':ref,'current_oid':current.stdout.strip(),'current_status':current.returncode,'peeled_commit':peeled.stdout.strip()})
with pathlib.Path('/tmp/martensite-release-ref-red-9gjjtyfy/probe.jsonl').open('a') as stream:stream.write(json.dumps({'state':sys.argv[1],'cwd':os.getcwd(),'rows':rows})+'\n')
raise SystemExit(subprocess.run(['python3','/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/tools/release_tag_guard.py',*sys.argv[1:]],input=updates,text=True).returncode)
