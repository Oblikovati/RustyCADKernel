use rustycad_tkernel::ncollection::{Array1, HArray1};
#[derive(Copy)]
struct Trivial(i32);
impl Clone for Trivial { fn clone(&self) -> Self { panic!("Clone hook called") } }
fn main() {
    let mut buffer = [Trivial(7), Trivial(9)];
    let source = Array1::from_slice(&mut buffer);
    #[cfg(not(trivial_policy))]
    let copy = HArray1::from_array(&source);
    #[cfg(trivial_policy)]
    let copy = HArray1::from_array_trivial(&source);
    assert_eq!(copy.array1().first().unwrap().0, 7);
}
