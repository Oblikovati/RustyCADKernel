use rustycad_tkernel::{ncollection::HSequence, standard::Handle};
struct Derived {
    base: HSequence<i32>,
}
rustycad_tkernel::impl_transient!(Derived, "HSequenceAppendProbe", HSequence<i32>, base);
fn main() {
    let source = Handle::new(Derived { base: HSequence::default() });
    source.get().unwrap().base.append(7);
    let destination = HSequence::<i32>::default();
    #[cfg(not(projected_adapter))]
    destination.append_handle(&source).unwrap();
    #[cfg(projected_adapter)]
    destination.append_handle_projected(&source, |derived| &derived.base).unwrap();
    assert_eq!(destination.sequence(|s| s.first().copied()), Some(7));
    assert!(source.get().unwrap().base.sequence(|s| s.is_empty()));
}
