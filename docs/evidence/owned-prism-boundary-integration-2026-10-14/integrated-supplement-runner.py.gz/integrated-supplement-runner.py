import ast,gzip,hashlib,json,os,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd();out=root/'docs/evidence/owned-prism-boundary-integration-2026-10-14';refusal=root/'docs/evidence/owned-prism-refusal-v1-2026-10-14';prep=root/'docs/evidence/owned-polynomial-request-v1';pub=root/'docs/evidence/prism-publication-v1-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
def archive(p,prefix=''):
 with tarfile.open(p) as t:return {m.name.removeprefix(prefix):t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
def cases(p,name):return next(ast.literal_eval(n.value) for n in ast.parse(p.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
ref_receipt=json.loads((refusal/'receipt.json').read_text())
for path,digest in ref_receipt['archives'].items():assert sha((refusal/path).read_bytes())==digest,path
for path,entry in json.loads((prep/'artifacts.json').read_text()).items():assert sha((prep/path).read_bytes())==entry['sha256'],path
r=archive(refusal/'reconciled-gate.tar.gz','owned-refusal-reconciled/');p=archive(prep/'checks.tar.gz')
for name,digest in json.loads(r['artifact-manifest.json']).items():assert sha(r[name])==digest,name
assert json.loads(r['source-before.json'])==json.loads(r['source-after.json'])
rs=json.loads(r['supplement.json']);assert rs['before']==rs['after']
for prefix in ('','pre-boxing-'):assert json.loads(p[prefix+'source-before.json'])==json.loads(p[prefix+'source-after.json'])
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M))
ref_names=names(r['all-targets.log']);prep_names=names(p['frozen-prism-tests.log']);actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert ref_names|prep_names<=actual
replay_cases=cases(pub/'run_gate.py','CASES')+[row for row in cases(refusal/'replay_supplement.py','cases') if row[0] in ('semantic','owned-refusal')]
replay_cases.append(('volume','frozen::joined_volume::tests::joined_volume_process_replay','joined-volume-v1='))
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for kind,needle,marker in replay_cases:
 if kind in ('semantic','owned-refusal'):expected=r[f'{kind}-supplement-1.bin']
 elif kind=='volume':expected=gzip.decompress((root/'docs/evidence/prism-joined-volume-v1/final/replay-1.bin.gz').read_bytes())
 else:expected=gzip.decompress((pub/f'{kind}-1.bin.gz').read_bytes())
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked','sketch_region_prism::'+needle,'--','--exact','--nocapture','--test-threads=1'];run=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{kind}-process-{i}.log.gz').write_bytes(gzip.compress(run.stdout,mtime=0));assert run.returncode==0
  pattern=re.escape(marker)+(r'(\[[^\n]+\])' if kind=='semantic' else r'([0-9a-f]+)');found=re.findall(pattern,run.stdout.decode());assert len(found)==1
  blob=bytes(ast.literal_eval(found[0])) if kind=='semantic' else bytes.fromhex(found[0]);assert blob==expected
  (out/f'{kind}-process-{i}.bin.gz').write_bytes(gzip.compress(blob,mtime=0));replays.append({'kind':kind,'process':i,'bytes':len(blob),'sha256':sha(blob)})
run=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(run.stdout,mtime=0));assert run.returncode==0;assert before==snapshot()
for label in ('check','fmt'):(out/f'request-merge-{label}.log.gz').write_bytes(gzip.compress(pathlib.Path(f'/tmp/martensite-request-merge-{label}.log').read_bytes(),mtime=0))
receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'source_unchanged':True,'refusal_test_names_retained':len(ref_names),'preparation_test_names_retained':len(prep_names),'missing_tests':sorted((ref_names|prep_names)-actual),'candidate_archives_verified':True,'refusal_archive_payload_hashes':{k:sha(v) for k,v in r.items()},'preparation_archive_payload_hashes':{k:sha(v) for k,v in p.items()},'replays':replays,'docs_exit':run.returncode,'limits':['Private preparation plus bounded optional refusal projection; no whole owned-operation replay, semantic resolver, public body or release acceptance.','ThreadSanitizer remains incomplete.']}
(out/'integrated-supplement.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('owned-boundary supplement passed',flush=True)
