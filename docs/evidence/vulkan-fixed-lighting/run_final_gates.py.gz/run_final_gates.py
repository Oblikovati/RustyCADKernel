import os,subprocess,json
from pathlib import Path
root=Path.cwd();rows=[]
for profile,icd in [('software','lvp'),('host','radeon')]:
 env=os.environ.copy();env.update(PATH='/home/vmiguel/.cargo/bin:'+env['PATH'],CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',DISPLAY=':1',GALLIUM_OVERRIDE_CPU_CAPS='sse2',LP_NATIVE_VECTOR_WIDTH='128',MARTENSITE_VULKAN_DEVICE='0',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/'+icd+'_icd.json');env.pop('LLVM_TARGET_FEATURES',None)
 cmd=['python3','tools/with_vulkan_validation.py','--cache',str((root/'../RustyCADKernel/target/vulkan-validation').resolve()),'--','cargo','test','-p','martensite-vulkan','--all-targets']
 log=root/f'target/fixed-lighting-proof/final-all-targets-corrected-{profile}.log'
 with log.open('w') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row={'profile':profile,'exit':r.returncode,'log':str(log),'command':cmd};rows.append(row);print(json.dumps(row),flush=True)
 if r.returncode:break
(root/'target/fixed-lighting-proof/final-all-targets-corrected.json').write_text(json.dumps(rows,indent=2)+'\n')
