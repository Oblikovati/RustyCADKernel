from pathlib import Path
import os,subprocess
root=Path('/tmp/rustycad-buffer-raw-adoption');path=root/'crates/tkernel/src/ncollection/allocator/owned.rs';final=path.read_text()
start=final.index('    fn allocate_owned_address(');end=final.index('    /// Transfers initialized raw-policy bytes',start)
baseline=final[:start]+'''    fn allocate_owned_address(&self, size: usize) -> Option<NonNull<u8>> {
        let address = self.allocate_policy(size, true)?;
        self.acquire_owned_byte_lease();
        Some(address)
    }

'''+final[end:]
Path('/tmp/buffer-owned-lease-baseline.rs').write_text(baseline)
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/tmp/rustycad-sparse-base-miri',MIRIFLAGS='-Zmiri-strict-provenance -Zmiri-seed=0 -Zmiri-preemption-rate=1.0')
command=['cargo','+nightly-2026-09-25','miri','test','-p','rustycad-tkernel','--test','buffer_raw_adoption_contracts','owned_allocation_and_lease_are_atomic_against_concurrent_reset']
try:
 path.write_text(baseline)
 with open('/tmp/buffer-raw-adoption-baseline-race.log','w') as output:result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 Path('/tmp/buffer-raw-adoption-baseline-race.exit').write_text(str(result.returncode))
 print('baseline',result.returncode,flush=True)
finally:path.write_text(final)
