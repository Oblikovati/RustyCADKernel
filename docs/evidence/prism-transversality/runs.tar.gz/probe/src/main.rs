use rustycad_tkmath::predicates::roots::metric_bounds::{affine_prism_jacobian,MetricEmbedding};
fn compute(extrusion:[f64;3])->String {
    let frame=MetricEmbedding {linear:[[2.,7.],[3.,11.],[5.,13.]],origin:[7.,11.,13.],scale:2.};
    let placement=MetricEmbedding {linear:[[1.,2.,0.],[0.,-1.,1.],[2.,0.,1.]],origin:[-7.,-11.,-13.],scale:0.5};
    affine_prism_jacobian(frame,placement,extrusion,||false).unwrap().to_string()
}
fn main() {
    let vectors=[[17.,19.,23.],[-17.,-19.,-23.],[0.;3],[8.,2.,9.]];
    let expected=vectors.map(compute);
    assert_eq!(expected,["501 * 2^0","-501 * 2^0","0 * 2^0","0 * 2^0"]);
    std::thread::scope(|scope| {
        for _ in 0..8 {
            let expected=&expected;
            scope.spawn(move||for _ in 0..128 {assert_eq!(&vectors.map(compute),expected);});
        }
    });
    println!("{{\"version\":1,\"exact_jacobians\":{expected:?},\"threads\":8,\"repeats\":128}}");
}
