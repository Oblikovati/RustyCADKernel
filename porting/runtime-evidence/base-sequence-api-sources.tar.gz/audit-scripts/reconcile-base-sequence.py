import collections,gzip,hashlib,json,pathlib,re,subprocess,sys
ROOT=pathlib.Path('/tmp/rustycad-base-sequence-reconciliation')
MAIN=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
sys.path.insert(0,str(ROOT/'tools'))
from normalize_rustdoc_inventory import make_reachable_inventory
from api_crosswalk import cpp_indexes,cpp_candidates,rust_crates,row_rust_candidates
from api_binding_replay import BindingReplay,verify_binding_ledger
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
PREFIX='rustycad_tkernel::ncollection::'
cpp=[json.loads(l)for l in gzip.open(ROOT/'porting/api-inventory/occt-declarations.jsonl.gz','rt')if 'NCollection_BaseSequence' in l]
cpp=[r for r in cpp if r['qualified_name'].startswith('NCollection_BaseSequence')]
by_name,_,_=cpp_indexes(cpp,{cpp[0]['source']:{'TKernel'}})
raw_path=pathlib.Path('/tmp/rustycad-base-api-check/doc/rustycad_tkernel.json')
raw=json.loads(raw_path.read_text());inventory={'crates':[make_reachable_inventory(raw,ROOT,'rustycad_tkernel')]}
rust=inventory['crates'][0]['declarations'];rust_index=rust_crates(inventory)
parity=json.loads((ROOT/'porting/parity.json').read_text());claims={}
for p in parity['api']:
 if not p['upstream_id'].startswith('NCollection_BaseSequence'):continue
 status,ms=cpp_candidates(p['upstream_id'],'TKernel',by_name)
 assert status=='unique',(p,status)
 claims[ms[0]['id']]=p
configs={}
def assign(prefixes,target,group='storage',selector=None,note=None):
 for prefix in prefixes.split():
  matches=[r for r in cpp if r['id'].startswith(prefix)];assert len(matches)==1,prefix
  assert matches[0]['id']not in configs,prefix
  configs[matches[0]['id']]={'target':target,'group':group,'selector':selector,'note':note}
assign('00721084','BaseSequence::allocator')
assign('22312b46','BaseSequence::length')
assign('65765854','BaseSequence::size')
assign('723a6377','BaseSequence::is_empty')
assign('4b4d0309','BaseSequence::new')
assign('837abfbb','BaseSequenceRawIterator::<core::default::Default>::default')
assign('b2dea1cb','BaseSequenceRawIterator::new')
assign('8586f2e1','BaseSequenceRawIterator::init')
assign('f3233d37','BaseSequenceRawIterator::previous')
assign('df6a61d7','BaseSequenceRawIterator::current_node')
assign('47258ab0','BaseSequenceRawIterator::previous_node')
assign('04cdc1ce 40813b61','BaseSequence::exchange')
assign('159e5f4a aa1ff060','BaseSequence::remove')
assign('69e4cb2d 91049b5d','BaseSequence::remove_range')
assign('7dd85d7a fbc12c99','BaseSequence::remove_cursor')
assign('1b4e46a1 f9962c47','BaseSequence::clear_seq')
assign('17fdb989 5dc78841','BaseSequence::prepend_node')
assign('c5a7b117 da8fbb79','BaseSequence::append_node')
assign('568ef6d8 841f0cf4','BaseSequence::prepend_sequence',note='Disjoint transfer; native self-splice also has explicit prepend_self with native cycle/metadata behavior. No simultaneous aliasing &mut parameters are permitted.')
assign('375ccb27 816beb0a','BaseSequence::append_sequence',note='Disjoint transfer; native self-splice also has explicit append_self with native cycle/metadata behavior. No simultaneous aliasing &mut parameters are permitted.')
assign('3a3e3827 8137d870','BaseSequence::insert_after_cursor')
assign('606fe726 b2656605','BaseSequence::insert_after',note='Valid native index/node domain; Rust also checks out-of-range indices where the native protected node overload assumes valid input.')
assign('1fed78d0 a564b57b','BaseSequence::insert_sequence_after',note='Disjoint sequence transfer; insert_self_after separately reproduces native self-splice cycles and metadata clearing.')
assign('4b9fd4e2 8de98140','BaseSequence::split',note='Distinct destination with retained caller allocation ownership; split_self separately represents native Standard_DomainError without aliasing Rust mutable borrows.')
assign('3fbdbb63 824fe6a8','BaseSequence::reverse')
assign('6af04c11 d62d72aa','BaseSequence::find')
assign('142c23aa','BaseSequence','nominal')
assign('6fdf0362','BaseSequenceRawIterator','nominal')
assign('271d6281 cf037fc0','BaseSequenceBasicIterator','nominal')
assign('1217f0f4','BaseSequence::last','field')
assign('547b2f94','BaseSequence::size','field')
assign('778e9a92','BaseSequence::first','field')
assign('871001c5','BaseSequence::allocator','field')
assign('d5d0891f','BaseSequence::current','field')
assign('e5687dcf','BaseSequence::current_index','field')
assign('2eaf50f2','BaseSequenceRawIterator::previous','field')
assign('d80c546e','BaseSequenceRawIterator::current','field')
assign('010d9232','BaseSequenceBasicIterator::from_raw','basic')
assign('0253ed1a 3241d5e6 b3baa949 b915a6d1 d529f598','BaseSequenceBasicIterator::assign','basic',note='One generic Rust method copies both raw links for same-specialization and both historical conversion directions; native SFINAE cases remain separate exact records.')
assign('1170bc67 85778592','BaseSequenceBasicIterator::change_value','basic','true')
assign('135d3e33 8a94e76c 6da2d737 cc1253f0','BaseSequenceBasicIterator::init','basic',note='Generic Rust initialization only copies base metadata and accepts a shared base for both MUTABLE values; subsequent writable dereference remains unsafe. C++ const-reference constraints are not identical.')
assign('1aeb5c32 480586be c79717d9 fc9c4b9b','BaseSequenceBasicIterator::initialize','basic',note='Generic Rust initialization only copies base metadata and accepts a shared base for both MUTABLE values; subsequent writable dereference remains unsafe. C++ const-reference constraints are not identical.')
assign('20971478 e8c97a7c','BaseSequenceBasicIterator::<core::cmp::PartialEq<rustycad_tkernel::ncollection::sequence::basic_iterator::BaseSequenceBasicIterator<N, OTHER>>>::eq','basic')
assign('53171b06 e2215c42','BaseSequenceBasicIterator::<core::cmp::PartialEq<rustycad_tkernel::ncollection::sequence::basic_iterator::BaseSequenceBasicIterator<N, OTHER>>>::eq','basic',note='Rust != uses standard PartialEq::ne default; the eq project body is not proof of a separately compiler-observed ne body.')
assign('2211276f','BaseSequenceBasicIterator::current_node','basic')
assign('a73a12de','BaseSequenceBasicIterator::previous_node','basic')
assign('25919058 3605e657 475217be eb1a6325','BaseSequenceBasicIterator::new','basic',note='One generic Rust constructor copies base metadata for both MUTABLE values. Native mutable/const overload records are retained separately, with explicit bool arguments in Rust.')
assign('267cabad','BaseSequenceBasicIterator::post_advance','basic')
assign('3acf1ac9','BaseSequenceBasicIterator::<core::clone::Clone>::clone','basic')
assign('b66c2485','BaseSequenceBasicIterator::<core::default::Default>::default','basic')
assign('584650c4','BaseSequenceBasicIterator::post_retreat','basic')
assign('589f9e9c 6072af2c 7f28a39a e504d378','BaseSequenceBasicIterator::convert','basic',note='Both C++ historical const-to-mutable and mutable-to-const constructors are retained. Rust convert::<OTHER> performs raw-link copy; writable access always requires unsafe caller obligations.')
assign('5c4026df','BaseSequenceBasicIterator::next','basic')
assign('f7df1818','BaseSequenceBasicIterator::previous','basic')
assign('6eab51e8','BaseSequenceBasicIterator::more','basic')
assign('1a3342bf 7cb3e0b1','BaseSequenceBasicIterator::mutable_node','basic','true')
assign('e81e8a8b f6e804d6','BaseSequenceBasicIterator::mutable_previous_node','basic','true')
assign('952d5077','BaseSequenceBasicIterator::arrow','basic','both')
assign('c941dbc6','BaseSequenceBasicIterator::dereference','basic','both')
assign('e561ad0d','BaseSequenceBasicIterator::node','basic','both')
assign('9b5a8991 ab775e0d','BaseSequenceBasicIterator::is_equal','basic')
assign('d37d8284','BaseSequenceBasicIterator::advance','basic')
assign('f26d913f','BaseSequenceBasicIterator::retreat','basic')
assign('e5fb702b','BaseSequenceBasicIterator::value','basic',note='Unlike BaseList Value, native BaseSequence Value is readonly in both specializations. Mutable operator* and operator-> use ChangeValue separately.')
assign('fd71075c','BaseSequenceBasicIterator::copy_to','basic')

def stripped(value):
 if isinstance(value,list):return [stripped(v)for v in value]
 if not isinstance(value,dict):return value
 return {k:stripped(v)for k,v in value.items()if k not in ('id','resolved_item_path')}
def span_record(item):
 span=item['span'];begin,end=span['begin'],span['end'];lines=(ROOT/span['filename']).read_text().splitlines(keepends=True)
 text=''.join(lines[begin[0]-1:end[0]])[begin[1]-1:];excess=len(lines[end[0]-1])-end[1]+1
 if excess:text=text[:-excess]
 return {'raw_rustdoc_item_id':item['id'],'span':span,'declaration_source_span_sha256':hashlib.sha256(text.encode()).hexdigest()}
catalog={}
def register(candidate):
 key=candidate['declaration_sha256']
 if key in catalog:return key
 assert sha(ROOT/candidate['source_file'])==candidate['source_sha256'];entry=dict(candidate)
 if candidate['kind']=='function':
  matches=[i for i in raw['index'].values()if i['name']==candidate['path'].rsplit('::',1)[-1] and i.get('span',{}).get('filename')==candidate['source_file'] and 'function' in i['inner'] and stripped(i['inner']['function'])==stripped(candidate['signature'])]
  assert matches,candidate['path'];entry['raw_body_source_matches']=[span_record(i)for i in matches]
 catalog[key]=entry;return key
def const_args(candidate):
 args=candidate.get('impl_context',{}).get('for',{}).get('resolved_path',{}).get('args')or{}
 return [a['const']['expr']for a in args.get('angle_bracketed',{}).get('args',[])if 'const'in a]
def identity(native):
 suffix=re.search(r'\)\s*((?:const\s*)?(?:noexcept)?)$',native['signature']).group(1)
 return native['qualified_name']+'('+','.join(native.get('written_parameter_types',native.get('parameter_types',[])))+')'+(' '+suffix if suffix else '')
rows=[];records=[];replay=BindingReplay(by_name,rust_index,lambda p:sha(ROOT/p))
for native in cpp:
 row={'native':{k:v for k,v in native.items()if k!='_toolkits'},'previous_ledger_row':claims.get(native['id']),'candidate_binding_keys':[]};cfg=configs.get(native['id'])
 if not cfg:
  name=native['qualified_name'];kind=native['kind']
  if 'operator new'in name or 'operator delete'in name:status='missing_object_allocation_surface'
  elif kind=='CXXDestructor':status='virtual_destructor_drop_glue_without_exact_body_proof'
  elif kind=='TypeAlias':status='missing_native_iterator_alias_contract'
  elif kind in ('TemplateTypeParm','NonTypeTemplateParm'):status='template_parameter_not_separate_api_candidate'
  elif native['access']=='private':status='private_non_candidate_no_public_mapping_required'
  else:raise AssertionError((native['id'],name,kind))
  row['status']=status;rows.append(row);continue
 kind={'field':'struct_field','nominal':'struct'}.get(cfg['group'],'function');candidates=[c for c in rust if c['path']==PREFIX+cfg['target'] and c['kind']==kind]
 if cfg['selector']and cfg['selector']!='both':candidates=[c for c in candidates if cfg['selector']in const_args(c)]
 assert len(candidates)==(2 if cfg['selector']=='both'else 1),(native['id'],cfg,len(candidates))
 row['candidate_binding_keys']=[register(c)for c in candidates];row['domain']='partial';row['evidence_group']=cfg['group'];row['review_note']=cfg['note']
 row['status']='partial_body_binding'if kind=='function'else'partial_nominal_or_field_binding'
 if cfg['selector']=='both':row['status']='conditional_body_requires_impl_selector'
 if 'operator!='in native['qualified_name']:row['status']='trait_default_without_project_body_proof'
 if kind=='function'and native['api_visible']and row['status']=='partial_body_binding':
  claim=claims.get(native['id']);selector=claim['upstream_id']if claim else identity(native);target=PREFIX+cfg['target']
  proposed={'upstream_id':selector,'toolkit':'TKernel','source':native['source'],'rust_item':target,'rust_items':[target],'rust_kind':'function','status':'partial','notes':'Exact BaseSequence base/generic cursor body on valid raw-node and caller borrow domains; metadata, callback, and generic fixtures support scoped behavior. Native virtual destructor, object allocation macros, iterator aliases, ABI/noexcept/configuration closure remain open. See porting/audits/base-sequence-api-reconciliation.json.'+(' '+cfg['note']if cfg['note']else'')}
  cpp_status,cpp_matches=cpp_candidates(selector,'TKernel',by_name);rust_status,rust_matches=row_rust_candidates(proposed,rust_index)
  row['proposal_resolution']={'cpp_status':cpp_status,'cpp_ids':[r['id']for r in cpp_matches],'rust_status':rust_status,'rust_declaration_keys':[r['declaration_sha256']for r in rust_matches]}
  assert cpp_status==rust_status=='unique'and cpp_matches[0]['id']==native['id'],row
  row['proposed_row']=proposed;record={'cpp_id':native['id'],'cpp_signature':native['signature'],'proposed_row':proposed,'rust_body':candidates[0]};replay.verify(record);records.append(record)
 rows.append(row)
before=json.loads(json.dumps(parity));added=replaced=0
for record in records:
 p=record['proposed_row'];matches=[i for i,r in enumerate(parity['api'])if r['upstream_id']==p['upstream_id']]
 assert len(matches)<=1
 if matches:parity['api'][matches[0]]=p;replaced+=1
 else:parity['api'].append(p);added+=1
assert before['tests']==parity['tests']
other=lambda d:[r for r in d['api']if not r['upstream_id'].startswith('NCollection_BaseSequence')]
assert other(before)==other(parity)
verify_binding_ledger(records,parity['api']);(ROOT/'porting/parity.json').write_text(json.dumps(parity,indent=2)+'\n')
summary={'schema':'rustycad.exact-partial-binding-transaction.v1','source_revision':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'native_revision':'3d097a0328e71b826377d4814ab05ec3c3d23871','status':'partial_bindings_pending_root_integration','scope':'Every captured NCollection_BaseSequence record, including raw Iterator, generic BasicIterator, protected methods/fields, macro allocations, aliases and non-candidates. Exact unique callable mappings only are added/corrected in the ledger.','counts':{'native_records':len(rows),'api_visible_candidates':sum(r['native']['api_visible']for r in rows),'non_candidate_records':sum(not r['native']['api_visible']for r in rows),'previous_ledger_rows':len(claims),'previous_unclaimed_visible':sum(r['native']['api_visible']and not r['previous_ledger_row']for r in rows),'partial_proposals':len(records),'partial_rows_added':added,'rows_replaced':replaced,'implemented_corrected_to_partial':sum(r['previous_ledger_row']is not None and r['previous_ledger_row']['status']=='implemented'and'proposed_row'in r for r in rows),'excluded_corrected_to_partial':sum(r['previous_ledger_row']is not None and r['previous_ledger_row']['status']=='excluded'and'proposed_row'in r for r in rows),'catalog_records':len(catalog),'exact_public_bodies':len({r['rust_body']['declaration_sha256']for r in records}),'statuses':dict(collections.Counter(r['status']for r in rows))},'original_test_rows_unchanged':True,'other_class_rows_unchanged':True,'legacy_test_credit_delta':0,'fresh_tkernel_capture':True,'source_body_sha256':{r['rust_body']['source_file']:r['rust_body']['source_sha256']for r in records},'api_parity_complete':False}
files={
 'matrix':('porting/audits/base-sequence-api-matrix.jsonl',''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n'for r in rows).encode()),
 'catalog':('porting/audits/base-sequence-api-rust-bodies.jsonl',''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n'for r in catalog.values()).encode()),
 'bindings':('porting/audits/base-sequence-ledger-records.jsonl',''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n'for r in records).encode()),
 'rust_inventory':('porting/runtime-evidence/base-sequence-normalized.json.gz',gzip.compress(json.dumps(inventory,separators=(',',':')).encode(),mtime=0)),
 'rust_raw':('porting/runtime-evidence/base-sequence-rustdoc.json.gz',gzip.compress(raw_path.read_bytes(),mtime=0))}
for label,(filename,payload)in files.items():
 path=ROOT/filename;path.write_bytes(payload);summary[label+'_path']=filename;summary[label+'_sha256']=sha(path)
(ROOT/'porting/audits/base-sequence-api-reconciliation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['counts'],indent=2))
