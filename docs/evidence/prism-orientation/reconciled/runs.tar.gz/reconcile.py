import importlib.util,json,re,subprocess
from pathlib import Path
spec=importlib.util.spec_from_file_location('runner','/tmp/martensite-prism-orientation-checks/run_matrix.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
r.OUT=Path('/tmp/martensite-prism-orientation-reconciled'); r.OUT.mkdir(exist_ok=False)
before=r.snapshot('source-before.json')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r.ROOT).decode().strip()
base=['cargo','test','-p','rustycad-tkbo','--offline','--locked','--all-features']
embedding='sketch_region_prism::region_certificate::embedding::tests::replay_tests::prism_embedding_process_receipt'
commands=[('toolchain',['rustc','-Vv']),('focused',base+['region_certificate::orientation','--','--nocapture']),('embedding-baseline',base+[embedding,'--','--exact','--nocapture']),('clippy',['cargo','clippy','-p','rustycad-tkbo','--offline','--locked','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check'])]
rows=[r.run(name,command) for name,command in commands]
after=r.snapshot('source-after.json')
report=dict(revision=revision,merged_main='e6955e6db',original_source='e60b9542f',original_evidence='d9632ae2b',source_unchanged=before==after,source_files=len(before),commands=rows)
(r.OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
assert before==after
assert all(row['exit_code']==0 for row in rows)
