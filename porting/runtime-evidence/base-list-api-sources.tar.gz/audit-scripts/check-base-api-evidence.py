import os, pathlib, subprocess, json
root=pathlib.Path('/tmp/rustycad-base-api-reconciliation')
main=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
env=os.environ|{'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/tmp/rustycad-base-api-check'}
steps=[('rust',['cargo','test','--locked','-p','rustycad-tkernel','--test','base_list_storage_contracts','--test','base_list_basic_iterator_contracts'])]
lib=main/'target/occt-modeling-full/lin64/gcc/libi'
include=main/'target/occt-modeling-full/include/opencascade'
for scope in ('storage','basic_iterator'):
 stem='tkernel_base_list_'+scope+'_contracts'
 steps.append((scope+'-compile',['g++','-std=c++17','-O2','-I'+str(include),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(lib),'-Wl,-rpath,'+str(lib),'-lTKernel','-o',f'/tmp/base-api-{scope}-oracle']))
 steps.append((scope+'-run',[f'/tmp/base-api-{scope}-oracle']))
results=[]
for name,command in steps:
 log=pathlib.Path(f'/tmp/base-api-{name}.log')
 with log.open('wb') as out: result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 results.append({'stage':name,'command':command,'exit_code':result.returncode,'log':str(log)})
 if result.returncode:break
 if name.endswith('-run'):
  scope=name[:-4];expected=root/'tools/oracle'/f'tkernel_base_list_{scope}_contracts.expected'
  assert log.read_bytes()==expected.read_bytes(),name
pathlib.Path('/tmp/base-api-check-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
