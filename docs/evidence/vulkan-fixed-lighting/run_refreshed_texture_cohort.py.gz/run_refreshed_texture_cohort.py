from pathlib import Path
import os,subprocess,json,struct
root=Path.cwd();out=root/'target/fixed-lighting-proof/refreshed-texture-cohort';out.mkdir(exist_ok=True)
catalog=json.loads((root/'crates/vulkan/tests/fixtures/fixed-lighting/catalog.json').read_text())
cases=[(mode,True) for mode in catalog['textures']]
rows=[];commands=[]
for profile,icd in [('software','lvp'),('host','radeon')]:
 env=os.environ.copy();env.update(DISPLAY=':1',GALLIUM_OVERRIDE_CPU_CAPS='sse2',LP_NATIVE_VECTOR_WIDTH='128',MARTENSITE_VULKAN_DEVICE='0',VK_DRIVER_FILES='/usr/share/vulkan/icd.d/'+icd+'_icd.json',VK_LAYER_PATH=str((root/'../RustyCADKernel/target/vulkan-layer-ab/extracted/usr/share/vulkan/explicit_layer.d').resolve()),LD_LIBRARY_PATH=str((root/'../RustyCADKernel/target/vulkan-layer-ab/extracted/usr/lib/x86_64-linux-gnu').resolve()));env.pop('LLVM_TARGET_FEATURES',None)
 if profile=='software':env['LIBGL_ALWAYS_SOFTWARE']='1'
 else:env.pop('LIBGL_ALWAYS_SOFTWARE',None)
 for mode,texture in cases:
  native_name='native-fixed-lighting-cap' if mode.startswith('cap-') else 'native-fixed-lighting'
  ported_name='fixed_lighting_cap_capture' if mode.startswith('cap-') else 'fixed_lighting_texture_capture' if texture else 'fixed_lighting_capture'
  for kind,binary in [('native',root/'target/fixed-lighting-proof'/native_name),('repeat',root/'target/fixed-lighting-proof'/native_name),('ported',root/'target/debug/examples'/ported_name)]:
   prefix=out/f'{profile}-{mode}-{kind}';actual_mode=('texture-'+mode) if texture and kind!='ported' else mode;cmd=[str(binary),actual_mode,str(prefix)];r=subprocess.run(cmd,env=env,capture_output=True,text=True);prefix.with_suffix('.log').write_text(r.stdout+r.stderr);commands.append(dict(profile=profile,mode=mode,kind=kind,exit=r.returncode,command=cmd))
  row=dict(profile=profile,mode=mode)
  a=out/f'{profile}-{mode}-native';b=out/f'{profile}-{mode}-ported';repeat=out/f'{profile}-{mode}-repeat'
  if a.with_suffix('.rgba').exists() and b.with_suffix('.rgba').exists():
   n=a.with_suffix('.rgba').read_bytes();v=b.with_suffix('.rgba').read_bytes();row.update(color_differences=sum(x!=y for x,y in zip(n,v)),max_color_delta=max(abs(x-y) for x,y in zip(n,v)),native_repeat_exact=all(a.with_suffix(ext).read_bytes()==repeat.with_suffix(ext).read_bytes() for ext in ['.rgba','.depth','.lighting-trace']))
   nd=struct.unpack('<4096f',a.with_suffix('.depth').read_bytes());vd=struct.unpack('<4096f',b.with_suffix('.depth').read_bytes());row['max_depth_delta']=max(abs(x-y) for x,y in zip(nd,vd))
  rows.append(row);print(json.dumps(row),flush=True)
(out/'commands.json').write_text(json.dumps(commands,indent=2));(out/'comparison.json').write_text(json.dumps(rows,indent=2))
