import pathlib,json,hashlib,subprocess,os,time,platform,re,gzip
root=pathlib.Path.cwd();out=pathlib.Path('/tmp/martensite-prism-complete-history');evidence=root/'docs/evidence/prism-complete-history-v1-2026-10-14';env=os.environ.copy();env['PATH']='/home/vmiguel/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
files=subprocess.check_output(['git','ls-files','crates/tkbo','Cargo.toml','Cargo.lock']).decode().splitlines()
def snapshot(): return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=snapshot();receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'source_revision':'test-only extraction after c3ea3d687','platform':platform.platform(),'rustc':subprocess.check_output(['rustc','+1.99.0','-Vv'],env=env).decode(),'jobs':2,'commands':[]}
for label,needle in [('projection','lineage::projection_tests'),('history','complete_history::'),('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads'),('frozen','frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations')]:
 cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib',needle,'--locked','--','--nocapture','--test-threads=1'];start=time.monotonic()
 path=out/f'final-test-extraction-{label}.log'
 with path.open('wb') as log: code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 entry={'command':cmd,'exit_code':code,'seconds':time.monotonic()-start,'source_unchanged':before==snapshot()};receipt['commands'].append(entry);(out/'final-test-extraction.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(entry),flush=True)
 if code or before!=snapshot():raise SystemExit(1)
 (evidence/f'final-test-extraction-{label}.log.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for label,cmd in [('clippy',['cargo','+1.99.0','clippy','-p','rustycad-tkbo','--all-targets','--all-features','--locked','--','-D','warnings']),('fmt',['cargo','+1.99.0','fmt','--all','--','--check'])]:
 start=time.monotonic();path=out/f'final-test-extraction-{label}.log'
 with path.open('wb') as log:code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 entry={'command':cmd,'exit_code':code,'seconds':time.monotonic()-start,'source_unchanged':before==snapshot()};receipt['commands'].append(entry);print(json.dumps(entry),flush=True)
 (evidence/f'final-test-extraction-{label}.log.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
 if code or before!=snapshot():raise SystemExit(1)
replays={}
for label,marker in [('history','complete-prism-history-v1'),('lineage','prism-copy-lineage-v1'),('frozen','frozen-prism-v1')]:
 raw=(out/f'final-test-extraction-{label}.log').read_text();matches=re.findall(marker+r':([0-9a-f]+)',raw);assert len(matches)==1,(label,len(matches));blob=bytes.fromhex(matches[0]);replays[label]={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}
 assert blob == gzip.decompress((evidence/f'pre-style-{label}-replay.bin.gz').read_bytes()), label
legacy=json.loads((evidence/'pre-style-replay.json').read_text())
assert all(replays[k]==v for k,v in legacy.items())
(evidence/'final-test-extraction-replay.json').write_text(json.dumps(replays,indent=2)+'\n')
(evidence/'final-test-extraction-source.json.gz').write_bytes(gzip.compress((json.dumps(before,indent=2)+'\n').encode(),mtime=0))
(evidence/'final-test-extraction.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(replays),flush=True)
