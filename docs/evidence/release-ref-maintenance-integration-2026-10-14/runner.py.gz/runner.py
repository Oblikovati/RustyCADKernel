import ast,gzip,hashlib,json,os,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd();out=root/'docs/evidence/release-ref-maintenance-integration-2026-10-14';out.mkdir(exist_ok=True);base=root/'docs/evidence/release-ref-maintenance-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def hashes():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','tools','.githooks']).decode().split('\0') if p}
before=hashes();rec=json.loads((base/'receipt.json').read_text())
for p,h in rec['source_hashes'].items():assert sha((root/p).read_bytes())==h,p
for row in (base/'SHA256SUMS').read_text().splitlines():
 h,p=row.split(maxsplit=1);assert sha((base/p).read_bytes())==h,p
archive=next(base.glob('*.tar.gz'))
with tarfile.open(archive) as t:
 lines=t.extractfile('SHA256SUMS').read().decode().splitlines()
 for row in lines:
  h,p=row.split(maxsplit=1);assert sha(t.extractfile(p).read())==h,p
expected=rec['unchanged_verification_functions']
def functions(payload):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(payload).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
original=functions(subprocess.check_output(['git','show',rec['base_revision']+':tools/release_tag_guard.py']).decode());actual=functions((root/'tools/release_tag_guard.py').read_text());assert all(original[n]==actual[n] for n in expected)
env={**os.environ,'PYTHONPATH':str(root/'tools'),'PYTHONDONTWRITEBYTECODE':'1'};commands=[]
for name,cmd in [('release',['python3','-m','unittest','discover','-s','tools/tests','-p','test_release_*.py','-v']),('pre-release',['python3','tools/run_tool_tests.py','--jobs','2','--pattern','test_pre_release*.py']),('verification',['python3','-m','unittest','discover','-s','tools/tests','-p','test_verify_release_gate.py','-v'])]:
 p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{name}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));counts=re.findall(r'Ran (\d+) tests?',p.stdout.decode());row={'name':name,'command':cmd,'exit_code':p.returncode,'test_counts':counts};commands.append(row);print(json.dumps(row),flush=True);assert p.returncode==0
assert before==hashes();(out/'source-bookends.json.gz').write_bytes(gzip.compress(json.dumps({'before':before,'after':hashes()},sort_keys=True).encode(),mtime=0))
r={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_source':rec['source_revision'],'candidate_source_files_exact':True,'candidate_archive_payload_hashes_verified':len(lines),'verification_functions_ast_identical':expected,'commands':commands,'source_bookends_equal':True,'source_count':len(before),'scope':'Installed hook exercised only in isolated temporary repositories; no actual main tags, config, host protections, release publication or remote writes','formatting':'Candidate Black25.1.0 gate retained; source identical'}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(out/'runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('guard root integration passed',flush=True)
