#!/bin/bash
cd /tmp/rustycad-allocator-method-reconciliation || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-target
cargo test -p rustycad-tkernel --lib --test standard_memory_storage --test standard_services_api_behavior --test packed_map_object_storage --test inc_allocator_block_operations --test inc_allocator_block_borrowing --test allocator_protected_operations --test acc_allocator_aligned_reservation --test acc_allocator_alignment_safety --test acc_allocator_owned_release --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers --test ncollection_ordered_map --test ncollection_ordered_data_map --test ordered_canonical_storage --test ordered_node_contracts > /tmp/standard-memory-rust.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-rust.exit
cargo test -p rustycad-tkernel --doc > /tmp/standard-memory-doc.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-doc.exit
cargo clippy -p rustycad-tkernel --all-targets -- -D warnings > /tmp/standard-memory-clippy.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-clippy.exit
cargo fmt --all -- --check > /tmp/standard-memory-fmt.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-fmt.exit

#!/bin/bash
cd /tmp/rustycad-allocator-method-reconciliation || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-miri MIRIFLAGS=-Zmiri-strict-provenance
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_memory_storage --test packed_map_object_storage --test inc_allocator_block_operations --test inc_allocator_block_borrowing --test allocator_protected_operations --test acc_allocator_aligned_reservation --test acc_allocator_alignment_safety --test acc_allocator_owned_release --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers --test ncollection_ordered_map --test ncollection_ordered_data_map --test ordered_canonical_storage --test ordered_node_contracts > /tmp/standard-memory-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::allocator > /tmp/standard-memory-allocator-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-allocator-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::ordered_table::canonical_contracts > /tmp/standard-memory-ordered-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-ordered-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::cell_filter > /tmp/standard-memory-cell-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-cell-unit-miri.exit

cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib standard::memory > /tmp/standard-memory-storage-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-storage-unit-miri.exit

cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_services_api_behavior memory -- --skip memory::allocate_optimal_returns_null_instead_of_raising > /tmp/standard-memory-services-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-services-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_services_api_behavior mmgr:: > /tmp/standard-memory-mmgr-miri.log 2>&1
printf '%s\n' "$?" > /tmp/standard-memory-mmgr-miri.exit
