import json,re
from pathlib import Path
rows=[]
for path in Path('crates/tkbo/src/sketch_region_prism/region_certificate').glob('*.rs'):
    lines=path.read_text().splitlines()
    assert len(lines)<500,(path,len(lines))
    start=None;depth=0;begun=False
    for index,line in enumerate(lines,1):
        if start is None:
            match=re.search(r'\bfn\s+(\w+)',line)
            if match:start=index;name=match[1]
        if start is None:continue
        line=re.sub(r'"(?:\\.|[^"\\])*"','""',line.split('//')[0])
        begun|='{' in line
        depth+=line.count('{')-line.count('}')
        if begun and depth==0:
            length=index-start+1
            rows.append({'path':str(path),'function':name,'line':start,'length':length})
            assert 4<=length<=20,(path,name,length)
            start=None;begun=False

path=Path('crates/tkbo/src/sketch_region_contact_transport/world.rs')
lines=path.read_text().splitlines()
for name in ['recertify_contact_point','singleton_point_inputs']:
    start=next(i for i,line in enumerate(lines) if re.search(r'fn '+name+r'\b',line));depth=0;begun=False
    for index in range(start,len(lines)):
        line=re.sub(r'"(?:\\.|[^"\\])*"','""',lines[index].split('//')[0])
        begun|='{' in line;depth+=line.count('{')-line.count('}')
        if begun and depth==0:break
    length=index-start+1
    assert 4<=length<=20,(name,length)
    rows.append({'path':str(path),'function':name,'line':start+1,'length':length})
print(json.dumps({'count':len(rows),'functions':rows,'region_module_file_count':len(list(Path('crates/tkbo/src/sketch_region_prism/region_certificate').glob('*.rs')))},indent=2))
