import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd();base=root/'docs/evidence/ordered-prism-validation-v1-2026-10-14';out=root/'docs/evidence/ordered-prism-validation-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def hashes():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=hashes();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
manifest=json.loads((base/'sha256.json').read_text())
for p,h in manifest.items():assert sha((base/p).read_bytes())==h,p
for prefix in ('reconciled-','measure-reconciliation/'):
 first=json.loads(gzip.decompress((base/(prefix+'source-before.json.gz')).read_bytes()));last=json.loads(gzip.decompress((base/(prefix+'source-after.json.gz')).read_bytes()));assert first['source_files']==last['source_files'];assert first['revision']==last['revision']
fixtures=json.loads(gzip.decompress((base/'reconciled-tracked-fixtures-from-revision.json.gz').read_bytes()))
for p,row in fixtures['files'].items():assert sha((root/p).read_bytes())==row['revision_sha256']==row['working_sha256'],p
selectors=[('ordered','sketch_region_prism::frozen::ordered_validation::replay_tests::ordered_validation_process_receipt','ordered-validation-v1:'),('containment-v1','sketch_region_prism::frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('topology','sketch_region_prism::frozen::topology::replay_tests::exact_topology_report_replays_across_threads_and_processes','frozen-topology-v1:'),('join','sketch_region_prism::frozen::proof_join::tests::joined_math_byte_receipt','same-body-prism-proof-v1:'),('orientation','sketch_region_prism::frozen::joined_orientation::tests::replay_tests::joined_orientation_process_receipt','joined-orientation-v1:'),('tolerance','sketch_region_prism::exact_tolerance::joined_replay_tests::exact_tolerance_bytes_replay_across_threads_and_operations','prism-exact-tolerance-v2:')]
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for label,selector,prefix in selectors:
 expected=gzip.decompress((base/f'reconciled-{label}-process-1.bin.gz').read_bytes())
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-{label}-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  lines=re.findall(re.escape(prefix)+r'([0-9a-f]+)',p.stdout.decode());assert len(lines)==1;actual=bytes.fromhex(lines[0]);assert actual==expected
  (out/f'integrated-{label}-{i}.bin.gz').write_bytes(gzip.compress(actual,mtime=0))
 row={'kind':label,'bytes':len(expected),'sha256':sha(expected),'two_processes_match_candidate':True};replays.append(row);print(json.dumps(row),flush=True)
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=lambda payload:set(re.findall(r'^test (.+?) \.\.\. ok$',payload.decode(),re.M))
candidate=names(gzip.decompress((base/'reconciled-all-targets.log.gz').read_bytes()));actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual
assert before==hashes()
r={'integration_revision':json.loads((out/'integrated-main.json').read_text())['integration_revision'],'supplement_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_artifacts_verified':len(manifest),'both_candidate_bookends_equal':True,'legacy_fixture_files_verified':len(fixtures['files']),'source_unchanged_since_matrix':True,'candidate_test_names':len(candidate),'integrated_test_names':len(actual),'missing_test_names':sorted(candidate-actual),'replays':replays,'warning_denied_docs_exit':p.returncode,'sanitizer':'Incomplete; startup control SIGSEGV before main and actual ordered suite unbuilt/unexecuted'}
(out/'integrated-supplement.json').write_text(json.dumps(r,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('ordered validation supplement passed',flush=True)
