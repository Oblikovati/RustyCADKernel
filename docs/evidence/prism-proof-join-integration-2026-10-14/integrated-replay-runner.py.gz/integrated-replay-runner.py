import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd();out=root/'docs/evidence/prism-proof-join-integration-2026-10-14';baseline=root/'docs/evidence/prism-proof-join-v1-2026-10-14';env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
def hashes():
 names=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0')
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in names if p}
before=hashes();bookends=json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()));assert before==bookends['after']
selectors=[('join','sketch_region_prism::frozen::proof_join::tests::joined_math_byte_receipt','same-body-prism-proof-v1:'),('frozen_v1','sketch_region_prism::frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('complete_corrected','sketch_region_prism::region_certificate::measurements::tests::complete_tests::replay_tests::complete_prism_measure_process_receipt','{"operation":'),('cap_subset','sketch_region_prism::region_certificate::measurements::tests::replay_tests::portable_prism_measure_process_receipt','{"operation":')]
replays=[]
for label,selector,prefix in selectors:
 values=[]
 for process in (1,2):
  p=subprocess.run(['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-{label}-{process}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  text=p.stdout.decode();assert '1 passed; 0 failed' in text
  lines=[line for line in text.splitlines() if line.startswith(prefix)];assert len(lines)==1
  value=bytes.fromhex(lines[0][len(prefix):]) if label in ('join','frozen_v1') else (lines[0]+'\n').encode();values.append(value)
  (out/f'integrated-{label}-{process}.bin.gz').write_bytes(gzip.compress(value,mtime=0))
 assert values[0]==values[1]==gzip.decompress((baseline/f'{label}-process-1.bin.gz').read_bytes())
 item={'kind':label,'bytes':len(values[0]),'sha256':hashlib.sha256(values[0]).hexdigest(),'two_processes_equal_to_candidate':True};replays.append(item);print(json.dumps(item),flush=True)
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
assert before==hashes()
source=json.loads(gzip.decompress((baseline/'tests.log.gz').read_bytes()).decode() and (baseline/'receipt.json').read_text())
def passed_names(payload):return set(re.findall(r'^test (.+?) \.\.\. ok$',payload,re.M))
candidate=passed_names(gzip.decompress((baseline/'tests.log.gz').read_bytes()).decode());integrated=passed_names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()).decode());assert candidate<=integrated
receipt={'integration_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'source_bookends_equal_to_matrix':True,'replays':replays,'docs_exit':p.returncode,'candidate_test_names':len(candidate),'integrated_test_names':len(integrated),'missing_test_names':sorted(candidate-integrated)}
(out/'integrated-replay.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-replay-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('replay and documentation integration complete',flush=True)
