import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd();base=root/'docs/evidence/prism-joined-volume-v1';out=root/'docs/evidence/prism-joined-volume-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
for phase in ('prestyle','final'):
 d=json.loads(gzip.decompress((base/phase/'source-bookends.json.gz').read_bytes()));assert d['before']==d['after']
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M))
candidate=names(gzip.decompress((base/'final/focused-1.log.gz').read_bytes()))
previous=names(gzip.decompress((root/'docs/evidence/prism-publication-integration-2026-10-14/integrated-tests.log.gz').read_bytes()))
actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate|previous<=actual
publication=root/'docs/evidence/prism-publication-v1-2026-10-14'
cases=[('volume','joined_volume_process_replay','joined-volume-v1=',base/'final/replay-1.bin.gz'),('measures','joined_measure_process_replay','joined-measures-v1=',publication/'measures-1.bin.gz'),('publication','publication_process_replay','named-prism-publication-v1=',publication/'publication-1.bin.gz')]
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for kind,needle,marker,fixture in cases:
 expected=gzip.decompress(fixture.read_bytes())
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',needle,'--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{kind}-process-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  found=re.findall(re.escape(marker)+r'([0-9a-f]+)',p.stdout.decode());assert len(found)==1;blob=bytes.fromhex(found[0]);assert blob==expected
  (out/f'{kind}-process-{i}.bin.gz').write_bytes(gzip.compress(blob,mtime=0));replays.append({'kind':kind,'process':i,'bytes':len(blob),'sha256':sha(blob)})
commands=[]
for label,cmd in [('docs',['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked']),('independent-error',['python3',str(base/'verify_error_enclosures.py')])]:
 p=subprocess.run(cmd,env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-{label}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0;commands.append({'command':cmd,'exit_code':p.returncode})
assert before==snapshot()
r={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_test_names_retained':len(candidate),'previous_main_test_names_retained':len(previous),'missing_tests':sorted((candidate|previous)-actual),'source_unchanged':True,'candidate_artifact_hashes':{str(p.relative_to(base)):sha(p.read_bytes()) for p in sorted(base.rglob('*')) if p.is_file()},'replays':replays,'commands':commands,'limits':['Private conditional physical quantity; no construction-domain widening, public outcome or release acceptance.','ThreadSanitizer remains incomplete.']}
(out/'integrated-supplement.json').write_text(json.dumps(r,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('volume supplement passed',flush=True)
