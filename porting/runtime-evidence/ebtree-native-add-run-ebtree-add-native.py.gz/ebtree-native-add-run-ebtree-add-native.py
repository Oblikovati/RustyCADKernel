from pathlib import Path
import os,subprocess
root=Path('/tmp/rustycad-ebtree-native-add');build=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full');libs=build/'lin64/gcc/libi';env=dict(os.environ,LD_LIBRARY_PATH=str(libs))
for stem in ['tkernel_ebtree_add_contracts','tkernel_ubtree_add_contracts','tkernel_ebtree_implicit_contracts','tkernel_ubtree_pair_contracts','tkernel_ubtree_gemmate_parent_contracts','tkernel_ebtree_remove_contracts','tkernel_data_map_storage_contracts','tkernel_ebtree_move_assignment_contracts','tkernel_ubtree_move_assignment_contracts','tkernel_ubtree_clear_contracts','tkernel_ubtree_node_default_contracts','tkernel_ubtree_kill_contracts','tkernel_ubtree_payload_contracts','tkernel_ubtree_method_contracts']:
 subprocess.run(['g++','-std=c++17',*(['-fno-access-control'] if stem=='tkernel_ubtree_node_default_contracts' else []),'-I'+str(build/'include/opencascade'),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(libs),'-lTKernel','-o','/tmp/'+stem],check=True)
 output=subprocess.check_output(['/tmp/'+stem],env=env)
 assert output==(root/'tools/oracle'/f'{stem}.expected').read_bytes()
 Path('/tmp/ebtree-add-native-'+stem+'.log').write_bytes(output);print(stem,len(output.splitlines()),'matched',flush=True)
with open('/tmp/ebtree-add-legacy.log','w') as output:
 result=subprocess.run([str(build/'lin64/gcc/bini/OpenCascadeGTest'),'--gtest_filter=NCollection_UBTreeTest.*:NCollection_EBTreeTest.*:NCollection_DataMapTest.*'],env=env,stdout=output,stderr=subprocess.STDOUT)
print('legacy',result.returncode,flush=True);assert result.returncode==0
result=subprocess.run(['g++','-std=c++17','-fsyntax-only','-I'+str(build/'include/opencascade'),str(root/'tools/oracle/tkernel_ubtree_node_default_contracts.cxx')],capture_output=True)
assert result.returncode!=0 and b'private within this context' in result.stderr
Path('/tmp/ebtree-add-private-access.log').write_bytes(result.stdout+result.stderr)
print('private access rejection confirmed',flush=True)

rows=[]
for mode in ["H1","H2","H3","Q1","Q2","Q3"]:
 result=subprocess.run(["/tmp/tkernel_ebtree_add_contracts",mode],env=env,capture_output=True,text=True)
 assert result.returncode==86 and not result.stderr, (mode,result.returncode,result.stderr)
 rows.append(f"{mode} {result.returncode} {result.stdout}")
output="".join(rows)
assert output==(root/"tools/oracle/tkernel_ebtree_add_noexcept.expected").read_text()
Path("/tmp/ebtree-add-native-noexcept.log").write_text(output)
print("noexcept",len(rows),"matched",flush=True)
