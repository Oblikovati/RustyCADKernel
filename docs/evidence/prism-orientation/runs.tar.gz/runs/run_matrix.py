import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-orientation')
OUT = Path('/tmp/martensite-prism-orientation-checks/frozen')
OUT.mkdir(exist_ok=True)
ENV = dict(os.environ, PATH='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin', CARGO_BUILD_JOBS='2')


def snapshot(name):
    tracked = subprocess.check_output(['git', 'ls-files', 'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo'], cwd=ROOT).decode().splitlines()
    hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in tracked if (ROOT / p).is_file()}
    (OUT / name).write_text(json.dumps(hashes, indent=2, sort_keys=True)+'\n')
    return hashes


def run(name, command, env=ENV):
    start = time.time()
    with (OUT / (name+'.log')).open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, cwd=str(ROOT), elapsed_seconds=time.time()-start, exit_code=result.returncode)
    (OUT / (name+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    return row


def main():
    before = snapshot('source-before.json')
    revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
    (OUT/'revision.txt').write_text(revision+'\n')
    packages = ['-p','rustycad-tkmath','-p','rustycad-tkbo']
    commands = [('toolchain',['rustc','-Vv']), ('cargo-version',['cargo','-V']),
        ('focused',['cargo','test','-p','rustycad-tkbo','--offline','--locked','--all-features','region_certificate::orientation','--','--nocapture']),
        ('tests',['cargo','test',*packages,'--offline','--locked','--all-targets','--all-features']),
        ('doctests',['cargo','test',*packages,'--offline','--locked','--doc','--all-features']),
        ('clippy',['cargo','clippy',*packages,'--offline','--locked','--all-targets','--all-features','--','-D','warnings']),
        ('fmt',['cargo','fmt','--all','--','--check']),
        ('embedding-baseline',['cargo','test','-p','rustycad-tkbo','--offline','--locked','--all-features','sketch_region_prism::region_certificate::embedding::tests::replay_tests::prism_embedding_process_receipt','--','--exact','--nocapture'])]
    rows = [run(name,command) for name,command in commands]
    after = snapshot('source-after.json')
    (OUT/'matrix.json').write_text(json.dumps(dict(revision=revision, source_unchanged=before==after, commands=rows),indent=2)+'\n')


if __name__ == '__main__':
    main()
