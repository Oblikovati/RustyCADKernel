from pathlib import Path
import os,subprocess,json,tarfile,hashlib
root=Path('/tmp/rustycad-ubtree-child-construction');target=Path('/tmp/rustycad-sparse-base-target')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(target))
paths=[root/'crates/tkernel/src/ncollection'/name for name in ['ubtree.rs','ubtree/navigation.rs','ubtree/destruction.rs','ubtree/removal.rs']]
final={p:p.read_bytes() for p in paths}
def compatibility(label):
 result=subprocess.run(['cargo','build','-p','rustycad-tkernel','--lib','--message-format=json'],cwd=root,env=env,capture_output=True)
 Path('/tmp/ubtree-pair-'+label+'-build.log').write_bytes(result.stdout+result.stderr);result.check_returncode()
 artifacts=[json.loads(line) for line in result.stdout.splitlines()]
 libraries=[p for item in artifacts if item.get('reason')=='compiler-artifact' and item['target']['name']=='rustycad_tkernel' for p in item['filenames'] if p.endswith('.rlib')]
 for probe,expected in [('compatibility',0),('negative-dropck',1),('negative-send',1),('negative-sync',1)]+([('native-binding',0)] if label=='candidate' else []):
  binary='/tmp/ubtree-pair-'+label+'-'+probe
  with open(binary+'.log','w') as output:
   result=subprocess.run(['rustc','--edition=2024','/tmp/ubtree-pair-'+probe+'.rs','--extern','rustycad_tkernel='+libraries[-1],'-L','dependency='+str(target/'debug/deps'),'-o',binary],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
   assert result.returncode==expected,(label,probe,result.returncode)
   if expected==0:subprocess.run([binary],stdout=output,stderr=subprocess.STDOUT,check=True)
  print(label,probe,result.returncode,flush=True)
 return hashlib.sha256(Path(libraries[-1]).read_bytes()).hexdigest()
def focused(label,expected):
 with open('/tmp/ubtree-pair-'+label+'-focused.log','w') as output:
  result=subprocess.run(['cargo','test','-p','rustycad-tkernel','--test','ubtree_pair_storage_regression'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 assert result.returncode==expected,(label,result.returncode)
 print(label,'focused',result.returncode,flush=True)
try:
 for p in paths:p.write_bytes(subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(root))],cwd=root))
 selected=paths+[root/'crates/tkernel/tests/ubtree_pair_storage_regression.rs']
 with tarfile.open('/tmp/ubtree-pair-baseline-source.tar.gz','w:gz') as archive:
  for p in selected:archive.add(p,arcname=str(p.relative_to(root)))
 baseline=compatibility('baseline');focused('baseline',101)
finally:
 for p,content in final.items():p.write_bytes(content)
candidate=compatibility('candidate');focused('candidate',0)
Path('/tmp/ubtree-pair-baseline-proof.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'baseline_rlib_sha256':baseline,'candidate_rlib_sha256':candidate,'baseline_kind':'Actual HEAD UBTree modules with final existing-entry-point tests; no reconstructed ordering.','candidate_source_restored':True},indent=2)+'\n')
