"""Replay the exact IndexedIterator partial transaction; pass the checkout root."""

from __future__ import annotations

import copy
import gzip
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
from collections.abc import Callable

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / "tools"))
from api_crosswalk import cpp_indexes, header_owners, rust_crates
from api_binding_replay import BindingReplay, verify_binding_ledger, binding_object
from api_inventory.inputs import JSONObject, object_rows, text_field
from api_rust_kind import RustCrateIndex
from normalize_rustdoc_inventory import make_reachable_inventory

ARCHIVE = "porting/runtime-evidence/base-map-indexed-comparisons-current-"


def read_json(relative: str) -> JSONObject:
    """Read captured metadata; `read_json(ARCHIVE + 'transaction.json.gz')`."""
    path = ROOT / relative
    content = (
        gzip.decompress(path.read_bytes())
        if path.suffix == ".gz"
        else path.read_bytes()
    )
    parsed: JSONObject = json.loads(content)
    return parsed


def source_hash(relative: str) -> str:
    """Hash current body input; `source_hash('crates/tkernel/src/lib.rs')`."""
    payload = (ROOT / relative).read_bytes()
    return hashlib.sha256(payload).hexdigest()


def native_index() -> dict[str, list[JSONObject]]:
    """Index pinned native declarations; `native_index()`."""
    with gzip.open(
        ROOT / "porting/api-inventory/occt-declarations.jsonl.gz", "rt"
    ) as stream:
        rows = (json.loads(line) for line in stream)
        selected = [
            row
            for row in rows
            if row.get("qualified_name", "").startswith("NCollection_BaseMap")
            or row.get("qualified_name") == "operator+"
        ]
    owners = header_owners(read_json("porting/api-header-manifest.json"))
    index, duplicate, malformed = cpp_indexes(selected, owners)
    assert not duplicate and not malformed
    return index


def verify_selector_only(record: JSONObject) -> None:
    """Preserve semantic/status fields during selector refresh; `verify_selector_only(record)`."""
    prior = object_rows(record["prior_rows"], "prior rows")
    assert len(prior) == 1
    after = binding_object(record, "proposed_row")
    before_fields = {
        k: v for k, v in prior[0].items() if k != "rust_declaration_selectors"
    }
    after_fields = {k: v for k, v in after.items() if k != "rust_declaration_selectors"}
    assert before_fields == after_fields


def strict_transaction(
    candidate: JSONObject, baseline: JSONObject, records: list[JSONObject]
) -> None:
    """Reject mutations outside original owned rows; `strict_transaction(after, before, proof)`."""
    expected = copy.deepcopy(baseline)
    api = object_rows(expected["api"], "base api")
    for record in records:
        verify_selector_only(record)
        for prior in object_rows(record["prior_rows"], "prior rows"):
            assert api.count(prior) == 1
            api.remove(prior)
        api.append(binding_object(record, "proposed_row"))
    expected["api"] = api
    assert (
        expected == candidate
    ), "candidate ledger differs from exact four-row selector-only replacement"


def transaction_snapshots(transaction: JSONObject) -> tuple[JSONObject, JSONObject]:
    """Read immutable Git transaction snapshots; `transaction_snapshots(transaction)`."""
    baseline_ref = text_field(transaction, "base_commit") + ":porting/parity.json"
    baseline = json.loads(
        subprocess.check_output(["git", "show", baseline_ref], cwd=ROOT)
    )
    blob = text_field(transaction, "candidate_ledger_blob")
    candidate = json.loads(
        subprocess.check_output(["git", "cat-file", "blob", blob], cwd=ROOT)
    )
    return candidate, baseline


def fresh_rust_index() -> RustCrateIndex:
    """Normalize captured compiler identities against current bodies; `fresh_rust_index()`."""
    capture = "porting/runtime-evidence/base-map-indexed-proxy-comparisons-"
    raw = gzip.decompress((ROOT / (capture + "rustdoc.json.gz")).read_bytes())
    captured = read_json(capture + "normalized.json.gz")
    assert hashlib.sha256(raw).hexdigest() == captured["raw_rustdoc_sha256"]
    compiler = json.loads(raw)
    assert compiler["format_version"] == 61
    inventory = make_reachable_inventory(compiler, ROOT, "rustycad_tkernel")
    return rust_crates({"crates": [inventory]})


def rejects(action: Callable[[], None]) -> bool:
    """Return whether a deliberately invalid proof fails; `rejects(check)`."""
    try:
        action()
    except (AssertionError, ValueError):
        return True
    return False


def wrong_binding_checks(record: JSONObject, replay: BindingReplay) -> dict[str, bool]:
    """Exercise ID, final body and selector failures; `wrong_binding_checks(record, replay)`."""
    wrong_id = dict(record, cpp_id="0" * 64)
    stale_hash = copy.deepcopy(record)
    object_rows(stale_hash["rust_bodies"], "bodies")[-1]["source_sha256"] = "0" * 64
    missing = copy.deepcopy(record)
    row = binding_object(missing, "proposed_row")
    object_rows(row["rust_declaration_selectors"], "selectors")[-1][
        "declaration_sha256"
    ] = ("0" * 64)
    return {
        "wrong_native_id_rejected": rejects(lambda: replay.verify(wrong_id)),
        "stale_last_body_hash_rejected": rejects(lambda: replay.verify(stale_hash)),
        "missing_last_selected_body_rejected": rejects(lambda: replay.verify(missing)),
    }


def changed_owned_ledger(
    candidate: JSONObject, records: list[JSONObject]
) -> list[JSONObject]:
    """Create a forbidden owned status change; `changed_owned_ledger(candidate, records)`."""
    changed_api = object_rows(copy.deepcopy(candidate)["api"], "changed api")
    name = binding_object(records[0], "proposed_row")["upstream_id"]
    changed = next(row for row in changed_api if row["upstream_id"] == name)
    changed["status"] = "implemented"
    return changed_api


def rejects_semantic_refresh(record: JSONObject) -> bool:
    """Reject a semantic mutation disguised as selector refresh; `rejects_semantic_refresh(record)`."""
    semantic = copy.deepcopy(record)
    binding_object(semantic, "proposed_row")["notes"] = "changed obligation"
    return rejects(lambda: verify_selector_only(semantic))


def transaction_scope_checks(
    candidate: JSONObject, baseline: JSONObject, records: list[JSONObject]
) -> dict[str, bool]:
    """Separate transaction integrity from integration scope; `transaction_scope_checks(after, before, proof)`."""
    unrelated = copy.deepcopy(candidate)
    unrelated_api = object_rows(unrelated["api"], "unrelated api")
    unrelated_api.append({"upstream_id": "Unrelated::method", "status": "partial"})
    verify_binding_ledger(records, unrelated_api)
    changed_api = changed_owned_ledger(candidate, records)
    original_rejects = rejects(lambda: strict_transaction(unrelated, baseline, records))
    owned_rejects = rejects(lambda: verify_binding_ledger(records, changed_api))
    return {
        "non_selector_refresh_rejected": rejects_semantic_refresh(records[0]),
        "unrelated_candidate_change_rejected": original_rejects,
        "unrelated_current_class_change_allowed": True,
        "owned_current_mapping_change_rejected": owned_rejects,
    }


def print_result(
    records: list[JSONObject], replay: BindingReplay, scope: dict[str, bool]
) -> None:
    """Report independent negative guards; `print_result(records, replay, scope)`."""
    multi = records[0]
    checks = wrong_binding_checks(multi, replay)
    checks.update(scope)
    assert all(checks.values()), checks
    result = {
        "native_ids": 6,
        "public_bodies": 8,
        "selector_only_rows_refreshed": 4,
        "checks": checks,
    }
    print(json.dumps(result))


def comparison_body(source: str, name: str) -> str:
    """Extract a scoped relation body with its signature; `comparison_body(source, 'is_less')`."""
    match = re.search(r"    pub fn " + name + r"[<(]", source)
    assert match is not None
    start = source.index("{", match.start())
    depth, position = 1, start + 1
    while depth:
        depth += (source[position] == "{") - (source[position] == "}")
        position += 1
    return source[match.start() : position]


def verify_relation_bodies() -> None:
    """Prove the four selector refreshes have unchanged source bodies; `verify_relation_bodies()`."""
    proof = read_json(ARCHIVE + "body-text.json.gz")
    records = object_rows(proof["records"], "body records")
    assert len(records) == 4
    for record in records:
        filename = text_field(record, "source_file")
        before_ref = text_field(proof, "before_commit") + ":" + filename
        before = subprocess.check_output(["git", "show", before_ref], cwd=ROOT).decode()
        after = (ROOT / filename).read_text()
        old_hash = hashlib.sha256(before.encode()).hexdigest()
        assert old_hash == record["before_source_sha256"]
        assert source_hash(filename) == record["after_source_sha256"]
        name = text_field(record, "path").rsplit("::", 1)[1]
        old, new = comparison_body(before, name), comparison_body(after, name)
        assert old == new
        body_hash = hashlib.sha256(new.encode()).hexdigest()
        assert body_hash == record["unchanged_method_text_sha256"]


def replay_all() -> None:
    """Verify four selector updates and all six current comparison proofs; `replay_all()`."""
    transaction = read_json(ARCHIVE + "transaction.json.gz")
    records = object_rows(transaction["records"], "transaction records")
    assert len(records) == 4
    candidate, baseline = transaction_snapshots(transaction)
    strict_transaction(candidate, baseline, records)
    current = object_rows(
        read_json(ARCHIVE + "bindings.json.gz")["records"], "current records"
    )
    assert len(current) == 6 and len({r["cpp_id"] for r in current}) == 6
    ledger = object_rows(read_json("porting/parity.json")["api"], "current api")
    verify_binding_ledger(current, ledger)
    replay = BindingReplay(native_index(), fresh_rust_index(), source_hash)
    for record in current:
        replay.verify(record)
    scope = transaction_scope_checks(candidate, baseline, records)
    print_result(current, replay, scope)


verify_relation_bodies()
replay_all()
