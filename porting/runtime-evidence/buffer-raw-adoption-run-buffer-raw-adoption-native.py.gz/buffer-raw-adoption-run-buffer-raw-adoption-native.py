from pathlib import Path
import os,subprocess
root=Path('/tmp/rustycad-buffer-raw-adoption');build=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full');libs=build/'lin64/gcc/libi';env=dict(os.environ,LD_LIBRARY_PATH=str(libs))
for stem in ['tkernel_buffer_raw_adoption','tkernel_buffer_adopted_size']:
 subprocess.run(['g++','-std=c++17','-I'+str(build/'include/opencascade'),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(libs),'-lTKernel','-o','/tmp/'+stem],check=True)
 output=subprocess.check_output(['/tmp/'+stem],env=env)
 assert output==(root/'tools/oracle'/f'{stem}.expected').read_bytes()
 Path('/tmp/buffer-raw-adoption-native-'+stem+'.log').write_bytes(output)
 print(stem,len(output.splitlines()),'matched',flush=True)
with open('/tmp/buffer-raw-adoption-legacy.log','w') as output:
 result=subprocess.run([str(build/'lin64/gcc/bini/OpenCascadeGTest'),'--gtest_filter=NCollection_*AllocatorTest.*:NCollection_BufferTest.*'],env=env,stdout=output,stderr=subprocess.STDOUT)
print('legacy',result.returncode,flush=True)
assert result.returncode==0
