from pathlib import Path
import os,subprocess,json
root=Path('/tmp/rustycad-ubtree-move-assignment');target=Path('/tmp/rustycad-sparse-base-target')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(target))
paths=[root/'crates/tkernel/src/ncollection'/name for name in ['ubtree.rs']];final={p:p.read_bytes() for p in paths}
def check(label):
 result=subprocess.run(['cargo','build','-p','rustycad-tkernel','--lib','--message-format=json'],cwd=root,env=env,capture_output=True)
 Path('/tmp/ubtree-move-assignment-'+label+'-build.log').write_bytes(result.stdout+result.stderr);result.check_returncode()
 artifacts=[json.loads(line) for line in result.stdout.splitlines()]
 paths=[p for item in artifacts if item.get('reason')=='compiler-artifact' and item['target']['name']=='rustycad_tkernel' for p in item['filenames'] if p.endswith('.rlib')]
 binary='/tmp/ubtree-move-assignment-dropck-'+label
 with open('/tmp/ubtree-move-assignment-'+label+'-dropck.log','w') as output:
  result=subprocess.run(['rustc','--edition=2024','/tmp/ubtree-move-assignment-dropck.rs','--extern','rustycad_tkernel='+paths[-1],'-L','dependency='+str(target/'debug/deps'),'-o',binary],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
  result.check_returncode();result=subprocess.run([binary],stdout=output,stderr=subprocess.STDOUT);result.check_returncode()
 Path('/tmp/ubtree-move-assignment-'+label+'-dropck.exit').write_text('0');print(label,'dropck 0',flush=True)
try:
 for p in paths:
  original=subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(root))],cwd=root)
  Path('/tmp/ubtree-move-assignment-baseline-'+p.name).write_bytes(original);p.write_bytes(original)
 check('baseline')
finally:
 for p,content in final.items():p.write_bytes(content)
check('candidate')
