import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-joined-orientation')
OUT=Path('/tmp/martensite-joined-orientation-checks/frozen')
OUT.mkdir(exist_ok=False)
ENV=dict(os.environ,PATH='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin',CARGO_BUILD_JOBS='2')
def snapshot(name):
    paths=subprocess.check_output(['git','ls-files','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],cwd=ROOT).decode().splitlines()
    report={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if (ROOT/p).is_file()}
    (OUT/name).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    return report
def run(name,command,env=ENV):
    started=time.time()
    with (OUT/(name+'.log')).open('wb') as stream:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
    report=dict(name=name,command=command,cwd=str(ROOT),seconds=time.time()-started,exit_code=result.returncode)
    (OUT/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
    return report
before=snapshot('source-before.json')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
base=['cargo','test','-p','rustycad-tkbo','--offline','--locked','--all-features']
commands=[('toolchain',['rustc','-Vv']),('cargo-version',['cargo','-V']),
 ('focused',base+['frozen::joined_orientation','--','--nocapture']),
 ('legacy',base+['region_certificate::orientation','--','--nocapture']),
 ('tests',['cargo','test','-p','rustycad-tkbo','--offline','--locked','--all-targets','--all-features']),
 ('doctests',['cargo','test','-p','rustycad-tkbo','--offline','--locked','--doc','--all-features']),
 ('clippy',['cargo','clippy','-p','rustycad-tkbo','--offline','--locked','--all-targets','--all-features','--','-D','warnings']),
 ('fmt',['cargo','fmt','--all','--','--check'])]
rows=[run(name,command) for name,command in commands]
after=snapshot('source-after.json')
(OUT/'receipt.json').write_text(json.dumps(dict(revision=revision,source_files=len(before),source_unchanged=before==after,commands=rows),indent=2)+'\n')
assert before==after
assert all(row['exit_code']==0 for row in rows)
