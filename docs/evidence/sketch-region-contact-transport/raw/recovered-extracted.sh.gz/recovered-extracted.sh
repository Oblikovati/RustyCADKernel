#!/bin/bash
set -euo pipefail
stage="$PWD/target/contact-transport/extracted"
exec bwrap --ro-bind / / --tmpfs /tmp --bind "$stage" /tmp/work --tmpfs /home/vmiguel/git/oblikovati-workspace --bind /home/vmiguel/.cargo /home/vmiguel/.cargo --proc /proc --dev /dev --unshare-net --clearenv --setenv PATH /home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin --setenv HOME /home/vmiguel --setenv CARGO_HOME /home/vmiguel/.cargo --setenv CARGO_TARGET_DIR /tmp/work/target --chdir /tmp/work /bin/bash -c 'set -e; cargo test -p rustycad-tkbo -p rustycad-tkmath --all-targets --all-features --locked --offline; cargo test -p rustycad-tkbo -p rustycad-tkmath --doc --all-features --locked --offline'
