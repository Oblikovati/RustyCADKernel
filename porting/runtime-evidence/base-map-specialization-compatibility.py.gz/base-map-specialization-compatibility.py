import json, pathlib, subprocess, sys, types, itertools, gzip

root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "tools"))
import api_crosswalk as updated

baseline = types.ModuleType("baseline_crosswalk")
exec(
    subprocess.check_output(
        [
            "git",
            "show",
            "72e52d58a62167bf2cbfd6401308fc8caadfcd64:tools/api_crosswalk.py",
        ],
        cwd=root,
    ),
    baseline.__dict__,
)
ledger = json.load(open(root / "porting/parity.json"))
rust = updated.rust_crates(
    json.load(
        gzip.open(
            root
            / "porting/runtime-evidence/base-map-specialization-normalized.json.gz",
            "rt",
        )
    )
)
rows = [row for row in ledger["api"] if "rust_declaration_selectors" not in row]
for row in rows:
    assert baseline.row_rust_candidates(row, rust) == updated.row_rust_candidates(
        row, rust
    ), row["upstream_id"]
statuses = [
    "unique",
    "ambiguous",
    "missing",
    "no_rust_target_declared",
    "unknown_rust_crate",
    "unverifiable_source",
    "invalid_rust_kind",
    "invalid_rust_targets",
]
checks = list(
    itertools.product(
        ["implemented", "partial", "excluded", "todo", "missing_status"],
        statuses,
        statuses,
        [True, False],
    )
)
for args in checks:
    assert baseline.resolve_status(*args) == updated.resolve_status(*args), args
print(
    json.dumps(
        {
            "old_rows_candidate_semantics_unchanged": len(rows),
            "old_status_matrix_cells_unchanged": len(checks),
            "new_selector_rows_excluded_from_comparison": 15,
        }
    )
)
