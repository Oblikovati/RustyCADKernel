use rustycad_tkernel::ncollection::{IndexedMapNode, IndexedDataMapNode};
#[repr(C,align(32))]
#[derive(Default)]
struct Wide { value:u8 }
fn map_row<K:Default>(label:&str) {
 let mut node=IndexedMapNode::new(K::default(),1,std::ptr::null_mut());
 let start=std::ptr::addr_of!(node) as usize;
 let key=node.key1() as *const K as usize-start;
 let index=node.index() as *const i32 as usize-start;
 println!("{label} {} {} {key} {index}",size_of_val(&node),align_of_val(&node));
}
fn data_row<K:Default,V:Default>(label:&str) {
 let mut node=IndexedDataMapNode::new(K::default(),1,V::default(),std::ptr::null_mut());
 let start=std::ptr::addr_of!(node) as usize;
 let key=node.key1() as *const K as usize-start;
 let value=node.value() as *const V as usize-start;
 let index=node.index() as *const i32 as usize-start;
 println!("{label} {} {} {key} {value} {index}",size_of_val(&node),align_of_val(&node));
}
fn main() {
 map_row::<u8>("map_u8");map_row::<i32>("map_i32");map_row::<Wide>("map_wide");
 data_row::<u8,u8>("data_u8_u8");data_row::<i32,u8>("data_i32_u8");data_row::<u8,i32>("data_u8_i32");data_row::<i32,i32>("data_i32_i32");
 data_row::<Wide,u8>("data_wide_u8");data_row::<u8,Wide>("data_u8_wide");data_row::<Wide,Wide>("data_wide_wide");
}
