import subprocess,os,pathlib,json,hashlib,sys
ROOT=pathlib.Path(sys.argv[1]).resolve();OUT=pathlib.Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
BINARY=pathlib.Path(sys.argv[3]).resolve()
cases=[('projection','owned_projection_refusal_process_receipt','MARTENSITE_PROJECTION_REFUSAL_RECEIPT'),('complete','complete_operation_replay_across_processes','MARTENSITE_COMPLETE_OWNED_RECEIPT'),('preparation','full_typed_refusal_process_receipt','MARTENSITE_TYPED_DIAGNOSTIC_RECEIPT'),('publication','full_publication_diagnostic_process_receipt','MARTENSITE_PUBLICATION_DIAGNOSTIC_RECEIPT')]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
binary_before=digest(BINARY);rows=[]
for name,test,key in cases:
 copies=[]
 for index in range(2):
  path=OUT/f'{name}-{index}.bin';env=os.environ.copy();env[key]=str(path)
  command=[str(BINARY),test,'--nocapture','--test-threads=1']
  with (OUT/f'{name}-{index}.log').open('w') as log:subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  copies.append(path.read_bytes())
 assert copies[0]==copies[1],name
 baseline=ROOT/'target/owned-projection-failure/baseline'/f'{name}.bin'
 if baseline.exists():assert copies[0]==baseline.read_bytes(),name+' old baseline changed'
 row={'name':name,'filter':test,'environment':key,'bytes':len(copies[0]),'sha256':digest(OUT/f'{name}-0.bin'),'processes_equal':True,'legacy_baseline_equal':True if baseline.exists() else None}
 rows.append(row);print(json.dumps(row),flush=True)
assert binary_before==digest(BINARY)
(OUT/'replay.json').write_text(json.dumps({'binary':str(BINARY),'binary_sha256':binary_before,'binary_after_sha256':digest(BINARY),'rows':rows},indent=2)+'\n')
