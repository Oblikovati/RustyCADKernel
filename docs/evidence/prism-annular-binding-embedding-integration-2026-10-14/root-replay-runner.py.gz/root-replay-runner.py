import ast,gzip,hashlib,json,os,subprocess,tarfile
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/prism-annular-binding-embedding-integration-2026-10-14';raw=root/'target/annular-integrated-replay';raw.mkdir(exist_ok=True)
exe=root/'target/two-loop-integrated-cold/debug/deps/rustycad_tkbo-3743221922cb8a91'
assert exe.exists()
base=root/'docs/evidence/prism-body-view-v1/actual-checkpoint'
probes=[('body','publication::body_view::actual_replay_tests::actual_body_process_receipt',None),('symbolic','publication::body_view::row_replay_tests::symbolic_body_row_process_replay','SYMBOLIC_BODY_ROWS='),('publication','publication::replay_tests::publication_process_replay','named-prism-publication-v1='),('map','owned_request::names::body_map::tests::semantic_map_replay_probe','SEMANTIC_MAP_REPLAY='),('frozen','frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('ordered','frozen::ordered_validation::replay_tests::ordered_validation_process_receipt','ordered-validation-v1:'),('joined-measures','frozen::joined_measures::tests::replay_tests::joined_measure_process_replay','joined-measures-v1='),('complete-measures','region_certificate::measurements::tests::complete_tests::replay_tests::complete_prism_measure_process_receipt','{"operation":'),('resolver','owned_request::resolver::replay_tests::actual_resolver_process_replay','actual-semantic-resolver-v2=')]
def digest(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0')
 return {p:digest((root/p).read_bytes()) for p in names if p}
before=snapshot();rows=[]
with tarfile.open(root/'docs/evidence/prism-actual-semantic-resolver-v2/final/checks.tar.gz') as archive:
 resolver=archive.extractfile('frozen/actual-replay-1.bin').read()
for name,test,marker in probes:
 expected=resolver if name=='resolver' else gzip.decompress((base/(name+'-1.bin.gz')).read_bytes())
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
  env={**os.environ,'MARTENSITE_ACTUAL_BODY_RECEIPT':str(path)}
  cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();assert result.returncode==0 and '1 passed;' in text,label
  if marker:
   line=next(line[line.index(marker):] for line in text.splitlines() if marker in line)
   payload=bytes(ast.literal_eval(line[len(marker):])) if name=='map' else line.encode() if name=='complete-measures' else bytes.fromhex(line[len(marker):])
  else:payload=path.read_bytes()
  assert payload==expected,(label,'candidate full-byte mismatch')
  payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
  (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
with tarfile.open(root/'docs/evidence/prism-diagnostic-envelope-v1-2026-10-14/publication-adapter-frozen.tar.gz') as archive:
 source=archive.extractfile('publication-diagnostic-frozen/replay.py').read().decode()
 start=source.index('specs = ['); end=source.index('expected = {')
 namespace={};exec(source[start:end],namespace)
 for name,test,form,marker in namespace['specs']:
  expected=archive.extractfile('publication-diagnostic-frozen/'+name+'-0.bin').read()
  payloads=[]
  for ordinal in (1,2):
   label=f'root-diagnostic-{name}-{ordinal}';path=raw/(label+'.bin');log=raw/(label+'.log')
   env={**os.environ}
   if form=='env':env[marker]=str(path)
   cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
   with log.open('wb') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
   content=log.read_text();assert result.returncode==0 and '1 passed;' in content,label
   if form=='env':payload=path.read_bytes()
   else:
    line=next(line[line.index(marker)+len(marker):] for line in content.splitlines() if marker in line)
    payload=bytes(ast.literal_eval(line)) if form=='list' else bytes.fromhex(line)
   assert payload==expected,(label,'candidate full-byte mismatch')
   payloads.append(payload)
   (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
   (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
  assert payloads[0]==payloads[1]
  row={'name':'diagnostic-'+name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)
extra=[
 ('annular-embedding','region_certificate::embedding::annular_operation::replay_tests::actual_annular_embedding_process_receipt','annular-prism-embedding-v2=', 'actual-entry/corrected-embedding-1.bin.gz'),
 ('legacy-embedding','region_certificate::embedding::tests::replay_tests::prism_embedding_process_receipt','{', 'structural-passed/embedding-1.bin.gz'),
 ('legacy-join','frozen::proof_join::tests::joined_math_byte_receipt','same-body-prism-proof-v1:', 'structural-passed/join-1.bin.gz')]
base_extra=root/'docs/evidence/plural-prism-embedding-v2-2026-10-14'
for name,test,marker,fixture in extra:
 if name=='legacy-embedding':expected=(root/'crates/tkbo/src/sketch_region_prism/region_certificate/embedding/tests/embedding-v1.json').read_bytes().strip()
 elif name=='legacy-join':expected=gzip.decompress((root/'docs/evidence/prism-publication-v1-2026-10-14/join-1.bin.gz').read_bytes())
 else:expected=gzip.decompress((base_extra/fixture).read_bytes())
 payloads=[]
 for ordinal in (1,2):
  label=f'root-{name}-{ordinal}';log=raw/(label+'.log')
  cmd=[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();assert result.returncode==0 and '1 passed;' in text,label
  line=next(line[line.index(marker):] for line in text.splitlines() if marker in line)
  payload=line.encode() if name=='legacy-embedding' else bytes.fromhex(line[len(marker):])
  assert payload==expected,(label,'candidate full-byte mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
  (out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':name,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)

import re
binding_base=root/'docs/evidence/annular-prism-binding-v2-2026-10-14'
completed_tests={'sketch_region_prism::'+item[1] for item in probes}|{item[1] for item in namespace['specs']}
def emitted(log,case):
 if case=='portable_region_certificate_process_receipt':
  return re.search(rb'(\{"operation":"martensite.region-certificate"[^\n]+)',log).group(1)
 found=re.findall(rb'([a-z0-9-]+)[:=]([0-9a-f]{100,})',log);assert len(found)==1,(case,len(found))
 return bytes.fromhex(found[0][1].decode())
for row in json.loads((binding_base/'final-exact-first.json').read_text())['commands']:
 case=row['filter'];test=row['command'][6]
 if test in completed_tests:continue
 expected=emitted(gzip.decompress((binding_base/row['log']).read_bytes()),case);payloads=[]
 for ordinal in (1,2):
  label=f'root-binding-{case}-{ordinal}';log=raw/(label+'.log');cmd=[str(exe),'--exact',test,'--nocapture','--test-threads=1']
  with log.open('wb') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  assert result.returncode==0 and b'1 passed;' in log.read_bytes(),label
  payload=emitted(log.read_bytes(),case);assert payload==expected,(label,'candidate bytes mismatch');payloads.append(payload)
  (out/(label+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0));(out/(label+'.bin.gz')).write_bytes(gzip.compress(payload,mtime=0))
 assert payloads[0]==payloads[1]
 row={'name':'binding-'+case,'bytes':len(expected),'sha256':digest(expected),'processes':2,'candidate_bytes_equal':True};rows.append(row);print(json.dumps(row),flush=True)

after=snapshot();assert before==after
(out/'root-replay-source.json.gz').write_bytes(gzip.compress(json.dumps({'before':before,'after':after},sort_keys=True).encode(),mtime=0))
(out/'root-replays.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'executable_sha256':digest(exe.read_bytes()),'source_unchanged':True,'replays':rows},indent=2)+'\n')
(out/'root-replay-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
