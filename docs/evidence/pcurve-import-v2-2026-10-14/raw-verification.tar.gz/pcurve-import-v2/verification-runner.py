from __future__ import annotations
import gzip, hashlib, json, os, platform, re, shutil, subprocess, sys, tarfile, time
from pathlib import Path
ROOT = Path('/home/vmiguel/git/oblikovati-workspace/Martensite-seam-pcurve-import')
EVIDENCE = ROOT / 'docs/evidence/pcurve-import-v2-2026-10-14'
RAW = Path('/tmp/martensite-pcurve-final-raw')
RAW.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV['PATH'] = '/home/vmiguel/.cargo/bin:' + ENV.get('PATH', '')
ENV['CARGO_BUILD_JOBS'] = '2'
CARGO = ['cargo', '+1.99.0']

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_bookend() -> dict[str, str]:
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    selected = [p for p in tracked if p.startswith('crates/') or p in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'rustfmt.toml', '.cargo/config.toml')]
    return {p: sha(ROOT / p) for p in selected if (ROOT / p).is_file()}

def run(name: str, command: list[str]) -> dict[str, object]:
    print(json.dumps({'phase': name, 'event': 'started'}), flush=True)
    began = time.monotonic()
    with (RAW / (name + '.log')).open('wb') as output:
        completed = subprocess.run(command, cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'command': command, 'exit_code': completed.returncode, 'elapsed_seconds': round(time.monotonic()-began, 3), 'log_sha256': sha(RAW/(name+'.log'))}
    print(json.dumps(row), flush=True)
    return row

before = source_bookend()
(RAW/'source-before.json').write_text(json.dumps(before, sort_keys=True, indent=2)+'\n')
receipt: dict[str, object] = {'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'platform': platform.platform(), 'jobs': 2, 'commands': [], 'requested_import_behavior': 2, 'default_import_behavior': 1}
commands = [
 ('toolchain', ['rustc','+1.99.0','-Vv']),
 ('tkbrep-all-targets', CARGO+['test','-p','rustycad-tkbrep','--all-targets','--all-features']),
 ('tkbo-all-targets', CARGO+['test','-p','rustycad-tkbo','--all-targets','--all-features']),
 ('doctests', CARGO+['test','-p','rustycad-tkbrep','-p','rustycad-tkbo','--doc','--all-features']),
 ('clippy', CARGO+['clippy','-p','rustycad-tkbrep','-p','rustycad-tkbo','--all-targets','--all-features','--','-D','warnings']),
 ('format', CARGO+['fmt','--all','--check']),
 ('test-format', ['rustfmt','+1.99.0','--edition','2024','--check','crates/tkbrep/tests/graph_pcurve_placement.rs']),
 ('binary-discovery', CARGO+['test','-p','rustycad-tkbrep','--test','toolkit','--no-run','--message-format=json']),
]
for name, command in commands:
    receipt['commands'].append(run(name, command))
artifacts=[]
for line in (RAW/'binary-discovery.log').read_text().splitlines():
    try:
        entry=json.loads(line)
    except json.JSONDecodeError:
        continue
    if entry.get('reason')=='compiler-artifact' and entry.get('executable') and entry.get('target',{}).get('name')=='toolkit':
        artifacts.append(entry['executable'])
if len(artifacts) != 1:
    raise RuntimeError(f'expected one TKBRep toolkit executable, got {artifacts}')
executable=Path(artifacts[0])
receipt['process_executable']={'path':str(executable.relative_to(ROOT)), 'sha256':sha(executable)}
case='graph_pcurve_placement::contracts::cumulative_v2_owned_process_snapshot'
for index in range(2):
    receipt['commands'].append(run(f'process-{index}',[str(executable),case,'--exact','--nocapture','--test-threads=1']))
process_rows=[]
for index in range(2):
    lines=(RAW/f'process-{index}.log').read_bytes().splitlines()
    process_rows.append([line for line in lines if line.startswith(b'{"pcurve_import_behavior":')])
receipt['two_process_bytes_equal']=process_rows[0]==process_rows[1] and len(process_rows[0])==1
receipt['process_snapshot']=process_rows[0][0].decode() if process_rows[0] else None
results={}
for name in ('tkbrep-all-targets','tkbo-all-targets','doctests'):
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (RAW/(name+'.log')).read_text())
    results[name]={'passed':sum(int(row[0]) for row in matches), 'failed':sum(int(row[1]) for row in matches), 'ignored':sum(int(row[2]) for row in matches), 'summaries':len(matches)}
receipt['test_counts']=results
after=source_bookend()
(RAW/'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2)+'\n')
receipt['source_bookends_equal']=before==after
receipt['source_file_count']=len(before)
receipt['source_manifest_sha256']=sha(RAW/'source-before.json')
fixture='crates/tkbrep/tests/fixtures/graph-pcurve-import-v1.txt'
baseline=subprocess.check_output(['git','show',f'adcb2c311:{fixture}'],cwd=ROOT)
receipt['legacy_fixture_sha256']=sha(ROOT/fixture)
receipt['legacy_fixture_unchanged']=hashlib.sha256(baseline).hexdigest()==receipt['legacy_fixture_sha256']
receipt['scope']={'live_occt':False,'polygon_lookup_changed':False,'graph_wide_v2_certificate':False,'immutable_graph_publication':False,'full_api_test_parity':False,'tsan_acceptance':'incomplete: unchanged host startup limitation recorded in native-display-lifecycle-v1-2026-10-14/TSAN.md; not executed for this slice','performance_acceptance':False}
receipt['all_checks_passed']=all(row['exit_code']==0 for row in receipt['commands']) and receipt['source_bookends_equal'] and receipt['two_process_bytes_equal'] and receipt['legacy_fixture_unchanged']
for path in Path('/tmp').glob('martensite-import-*.log'):
    shutil.copy2(path,RAW/path.name)
shutil.copy2(__file__,RAW/'verification-runner.py')
with tarfile.open(EVIDENCE/'raw-verification.tar.gz','w:gz') as archive:
    archive.add(RAW,arcname='pcurve-import-v2')
receipt['raw_archive_sha256']=sha(EVIDENCE/'raw-verification.tar.gz')
(EVIDENCE/'verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete':True,'all_checks_passed':receipt['all_checks_passed'],'tests':results}),flush=True)
sys.exit(0 if receipt['all_checks_passed'] else 1)
