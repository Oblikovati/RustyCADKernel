import os,subprocess,pathlib,hashlib,json,time
ROOT=pathlib.Path.cwd(); OUT=ROOT/'target/owned-projection-failure/frozen'
ENV=os.environ.copy(); ENV['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+ENV['PATH'];ENV['CARGO_BUILD_JOBS']='2'
def snapshot(name):
 paths=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
 hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if p and (ROOT/p).is_file()}
 (OUT/name).write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n');return hashes
def run(name,command):
 start=time.time()
 with (OUT/(name+'.log')).open('w') as log: status=subprocess.run(command,env=ENV,stdout=log,stderr=subprocess.STDOUT).returncode
 item={'name':name,'command':command,'exit':status,'seconds':time.time()-start};rows.append(item)
 (OUT/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(item),flush=True)
 if status: raise SystemExit(status)
rows=[];before=snapshot('source-before.json')
(OUT/'provenance.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'toolchain':subprocess.check_output(['rustc','-Vv'],env=ENV,text=True),'cargo':subprocess.check_output(['cargo','-V'],env=ENV,text=True),'jobs':2,'platform':os.uname()._asdict() if hasattr(os.uname(),'_asdict') else list(os.uname()),'source_files':len(before),'environment':{k:os.environ.get(k) for k in ['RUSTFLAGS','LD_PRELOAD','LD_LIBRARY_PATH','CARGO_TARGET_DIR']}},indent=2)+'\n')
run('all-targets',['cargo','test','-p','rustycad-tkbo','--all-targets','--all-features','--','--test-threads=1'])
run('doctests',['cargo','test','-p','rustycad-tkbo','--doc','--all-features'])
run('clippy',['cargo','clippy','-p','rustycad-tkbo','--all-targets','--all-features','--','-D','warnings'])
run('fmt',['cargo','fmt','--all','--check'])
run('docs',['cargo','doc','-p','rustycad-tkbo','--all-features','--no-deps'])
after=snapshot('source-after.json');assert before==after
print(json.dumps({'bookends_equal':True,'files':len(before)}),flush=True)
