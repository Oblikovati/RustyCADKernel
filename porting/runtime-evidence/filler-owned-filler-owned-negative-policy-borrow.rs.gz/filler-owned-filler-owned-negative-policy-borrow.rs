use rustycad_tkernel::ncollection::{BoundingVolume, UBTree, UBTreeFiller};
#[derive(Clone)] struct Bounds;
impl BoundingVolume for Bounds { fn add(&mut self,_:&Self){} fn is_out(&self,_:&Self)->bool{false} fn square_extent(&self)->f64{0.0} }
fn require_send<T:Send>(_: &T){} fn require_sync<T:Sync>(_: &T){}
fn main(){let mut tree=UBTree::<i32,Bounds>::default();let filler;{let capture=String::from("local");filler=UBTreeFiller::new(&mut tree,None,true).with_self_assignment_policy(|_|{std::hint::black_box(&capture);});}drop(filler);}