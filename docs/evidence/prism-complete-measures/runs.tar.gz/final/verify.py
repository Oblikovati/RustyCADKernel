from pathlib import Path
import hashlib,json,subprocess,os,time,shutil,re
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-complete-measures');stage=Path('/tmp/martensite-complete-measures-final')
env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
paths=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0') if p.startswith(('crates/tkbo/','crates/tkmath/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/adr/0031-complete-conditional-prism-measurements.md']]
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
initial=hashes();(stage/'source-before.json').write_text(json.dumps(initial,indent=2)+'\n');(stage/'revision.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
extracted=stage/'extracted';(extracted/'src').mkdir(parents=True,exist_ok=True)
shutil.copytree(repo/'crates/tkmath/src/predicates',extracted/'src/predicates',dirs_exist_ok=True);shutil.copy2(repo/'crates/tkmath/src/predicates.rs',extracted/'src/predicates.rs')
for relative in ['tests/support/metric_residual_cases.rs','tests/fixtures/certified_bezier_pairs/native.tsv']:
 target=extracted/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'crates/tkmath'/relative,target)
shutil.copytree(repo/'crates/tkmath/tests/fixtures/prism_complete_measures',extracted/'tests/fixtures/prism_complete_measures',dirs_exist_ok=True)
(extracted/'Cargo.toml').write_text('[package]\nname="martensite-prism-complete-measures-extracted"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\nnum-bigint={version="=0.4.6",default-features=false}\n');(extracted/'src/lib.rs').write_text('pub mod predicates;\n')
matching=[]
for target in sorted(extracted.rglob('*')):
 if not target.is_file() or str(target.relative_to(extracted)) in ['Cargo.toml','src/lib.rs','Cargo.lock'] or 'target' in target.relative_to(extracted).parts:continue
 original=repo/'crates/tkmath'/target.relative_to(extracted)
 assert target.read_bytes()==original.read_bytes()
 matching.append({'source':str(original.relative_to(repo)),'extracted':str(target.relative_to(extracted)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(stage/'extraction-equality.json').write_text(json.dumps(matching,indent=2)+'\n')
commands=[('sum-focused',['cargo','test','-p','rustycad-tkmath','--lib','enclosure_sum','--locked']),('full-focused',['cargo','test','-p','rustycad-tkbo','--lib','complete_tests','--locked']),('subset-replay',['cargo','test','-p','rustycad-tkbo','--lib','additive_complete_measurements_preserve_subset_v1_baseline','--locked']),('all-targets',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked']),('doctests',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--doc','--all-features','--locked']),('clippy',['cargo','clippy','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked','--','-D','warnings']),('fmt',['cargo','fmt','-p','rustycad-tkbo','-p','rustycad-tkmath','--check']),('extract-lock',['cargo','generate-lockfile','--manifest-path',str(extracted/'Cargo.toml'),'--offline']),('extract-tests',['cargo','test','--manifest-path',str(extracted/'Cargo.toml'),'--offline','--locked','--lib']),('oracle-regeneration',['python3',str(extracted/'tests/fixtures/prism_complete_measures/generate.py')])]
for label in ['first','second']:
 commands.append(('process-'+label,['cargo','test','-p','rustycad-tkbo','--lib','complete_prism_measure_process_receipt','--locked','--','--nocapture','--test-threads=1']))
results=[];bookends={}
for label,command in commands:
 before=hashes();start=time.time()
 with (stage/'logs'/f'{label}.log').open('w') as out:code=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 after=hashes();result={'label':label,'command':command,'cwd':str(repo),'exit_code':code,'elapsed_seconds':time.time()-start,'source_unchanged':initial==before==after};results.append(result);bookends[label]={'before':before,'after':after}
 (stage/'commands.json').write_text(json.dumps(results,indent=2)+'\n');(stage/'source-bookends.json').write_text(json.dumps(bookends,indent=2)+'\n');print(json.dumps(result),flush=True)
 assert code==0 and result['source_unchanged'],result
for row in matching:assert hashlib.sha256((extracted/row['extracted']).read_bytes()).hexdigest()==row['sha256']
for label in ['first','second']:
 lines=(stage/'logs'/f'process-{label}.log').read_text().splitlines();receipts=[line[line.index('{"operation"'):] for line in lines if '{"operation":"martensite.prism-complete-measures"' in line];assert len(receipts)==1
 (stage/f'process-{label}.json').write_text(receipts[0]+'\n')
assert (stage/'process-first.json').read_bytes()==(stage/'process-second.json').read_bytes()
(stage/'source-after.json').write_text(json.dumps(hashes(),indent=2)+'\n');print('portable scalar process receipts and regenerated oracle bytes equal',flush=True)
