import gzip,hashlib,json,os,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd(); base=root/'docs/evidence/prism-joined-orientation'; out=root/'docs/evidence/prism-joined-orientation-integration-2026-10-14'
def sha(b): return hashlib.sha256(b).hexdigest()
def hashes():
 return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=hashes();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
for row in (base/'SHA256SUMS').read_text().splitlines():
 h,p=row.split(maxsplit=1);assert sha((base/p).read_bytes())==h
with tarfile.open(base/'runs.tar.gz') as t:
 def read(p):return t.extractfile(p).read()
 manifest=read('SHA256SUMS').decode().splitlines()
 for row in manifest:
  h,p=row.split(maxsplit=1);assert sha(read(p))==h,p
 for prefix in ('','tsan-'):
  assert read('frozen/'+prefix+'source-before.json')==read('frozen/'+prefix+'source-after.json')
 rec=json.loads((base/'receipt.json').read_text())
 for p,h in rec['candidate_files'].items():assert sha((root/p).read_bytes())==sha(read('candidate-source/'+p))==h,p
 expected=read('frozen/joined-orientation.bin')
 candidate_names=set(re.findall(r'^test (.+?) \.\.\. ok$',read('frozen/tests.log').decode(),re.M))
selector='sketch_region_prism::frozen::joined_orientation::tests::replay_tests::joined_orientation_process_receipt';prefix='joined-orientation-v1:'
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
for i in (1,2):
 cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture']
 p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-replay-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
 lines=[s[len(prefix):] for s in p.stdout.decode().splitlines() if s.startswith(prefix)];assert len(lines)==1
 actual=bytes.fromhex(lines[0]);assert actual==expected
 (out/f'integrated-replay-{i}.bin.gz').write_bytes(gzip.compress(actual,mtime=0))
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=set(re.findall(r'^test (.+?) \.\.\. ok$',gzip.decompress((out/'integrated-tests.log.gz').read_bytes()).decode(),re.M));assert candidate_names<=names
assert before==hashes()
receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'outer_artifacts_verified':3,'inner_artifacts_verified':len(manifest),'candidate_files_verified':len(rec['candidate_files']),'candidate_source_and_tsan_bookends_match':True,'integration_source_unchanged':True,'candidate_test_names':len(candidate_names),'integrated_test_names':len(names),'missing_test_names':sorted(candidate_names-names),'two_processes_equal_to_candidate':True,'replay_bytes':len(expected),'replay_sha256':sha(expected),'warning_denied_docs_exit':p.returncode,'legacy_orientation_fixture_bytes':752,'legacy_callback_fixture_bytes':1949,'legacy_fixtures_exact_and_unchanged_tests_passed':True,'tsan':'incomplete; prior instrumented test crashed before test output'}
(out/'integrated-supplement.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print(json.dumps(receipt),flush=True)
