import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-joined-orientation')
OUT=Path('/tmp/martensite-joined-orientation-checks/frozen')
ENV=dict(os.environ,PATH='/home/vmiguel/.rustup/toolchains/nightly-2026-09-25-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin',CARGO_BUILD_JOBS='2',RUSTFLAGS='-Zsanitizer=thread',CARGO_TARGET_DIR='/tmp/martensite-joined-orientation-checks/tsan-target')
def snapshot(name):
    paths=subprocess.check_output(['git','ls-files','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],cwd=ROOT).decode().splitlines()
    hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if (ROOT/p).is_file()}
    (OUT/name).write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
    return hashes
def run(name,command):
    start=time.time()
    with (OUT/(name+'.log')).open('wb') as stream:
        result=subprocess.run(command,cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT)
    report=dict(command=command,cwd=str(ROOT),seconds=time.time()-start,exit_code=result.returncode)
    (OUT/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    return report
before=snapshot('tsan-source-before.json')
run('tsan-toolchain',['rustc','-Vv'])
command=['cargo','test','-p','rustycad-tkbo','--offline','--locked','-Zbuild-std','--target','x86_64-unknown-linux-gnu','--lib','sketch_region_prism::frozen::joined_orientation::tests::replay_tests::independent_workers_and_two_processes_match_complete_owned_bytes','--','--exact','--nocapture']
result=run('ordinary-host-tsan',command)
after=snapshot('tsan-source-after.json')
report=dict(command=result,source_unchanged=before==after,host_instrumentation_changes=False,environment_changes={name:ENV[name] for name in ['PATH','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_TARGET_DIR']})
report['status']='passed' if result['exit_code']==0 else 'incomplete'
report['test_output_started']='running 1 test' in (OUT/'ordinary-host-tsan.log').read_text()
(OUT/'sanitizer.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
assert before==after
