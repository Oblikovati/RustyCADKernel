from pathlib import Path
import tarfile,json,hashlib,subprocess,gzip
root=Path.cwd();archives=json.loads((root/'target/partition-binding/archive-build-receipt.json').read_text())['archives'];members={};vcs={}
for archive in archives:
 with tarfile.open(archive) as stream:
  for member in stream.getmembers():
   if not member.isfile():continue
   relative=Path(member.name).relative_to(Path(member.name).parts[0]);blob=stream.extractfile(member).read()
   if str(relative)=='.cargo_vcs_info.json':vcs[Path(archive).name]=json.loads(blob);continue
   if relative.suffix!='.rs':continue
   package=Path(archive).name.split('-0.')[0]
   crate=[p for p in (root/'crates').iterdir() if p.is_dir() and (p/'Cargo.toml').is_file() and f'name = "{package}"' in (p/'Cargo.toml').read_text()][0]
   source=crate/relative
   assert source.read_bytes()==blob,(str(source),'different archived source')
   members[str(source.relative_to(root))]=hashlib.sha256(blob).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert all(info['git']['sha1']==head and not info['git'].get('dirty',False) for info in vcs.values())
with gzip.GzipFile(filename=str(root/'target/partition-binding/archive-source-equality.json.gz'),mode='wb',mtime=0) as stream:stream.write(json.dumps({'head':head,'archive_count':len(archives),'vcs':vcs,'rust_members':members},sort_keys=True).encode())
print(json.dumps({'head':head,'archives':len(archives),'rust_members':len(members),'all_equal':True}))
