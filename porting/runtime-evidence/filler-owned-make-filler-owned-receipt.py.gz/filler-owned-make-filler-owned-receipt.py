import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/tmp/rustycad-ubtree-filler-owned-policy');digest=lambda b:hashlib.sha256(b).hexdigest();rel=lambda p:str(p.relative_to(root))
paths={root/"crates/tkernel/src/ncollection/mod.rs"}
for stem in ['ubtree','ubtree_filler','ebtree','data_map','owned_bucket_chains','base_map','allocator','dynamic_array']:
 paths.add(root/f'crates/tkernel/src/ncollection/{stem}.rs');paths.update(root.glob(f'crates/tkernel/src/ncollection/{stem}/**/*.rs'))
for stem in ['data_map_node','map_payload','hash_policy','node_owner','node_release','destructor_unwind']:
 paths.add(root/f'crates/tkernel/src/ncollection/{stem}.rs')
for name in ['bounding_tree_trace','ubtree_allocation_trace','ubtree_failed_pair_repair','ubtree_observed_key']:paths.add(root/f'crates/tkernel/tests/support/{name}.rs')
suites=Path('/tmp/ubtree-gemmate-parent-suites.txt').read_text().splitlines()+['ubtree_pair_contracts','ubtree_pair_storage_regression','ubtree_add_contracts','ebtree_implicit_contracts','ebtree_native_add_contracts','ubtree_failed_pair_contracts','ubtree_filler_dispatch_contracts','ubtree_filler_payload_contracts','ubtree_filler_owned_policy_contracts','ncollection_dynamic_array']
for suite in suites:
 paths.add(root/f'crates/tkernel/tests/{suite}.rs');paths.update(root.glob(f'crates/tkernel/tests/{suite}/**/*.rs'))
stems=['tkernel_ubtree_filler_owned_policy_contracts','tkernel_ubtree_filler_payload_contracts','tkernel_ubtree_filler_dispatch_contracts','tkernel_ubtree_filler_phase_observations','tkernel_ubtree_failed_pair_contracts','tkernel_ebtree_add_contracts','tkernel_ubtree_add_contracts','tkernel_ebtree_implicit_contracts','tkernel_ubtree_pair_contracts','tkernel_ubtree_gemmate_parent_contracts','tkernel_ebtree_remove_contracts','tkernel_data_map_storage_contracts','tkernel_ebtree_move_assignment_contracts','tkernel_ubtree_move_assignment_contracts','tkernel_ubtree_clear_contracts','tkernel_ubtree_node_default_contracts','tkernel_ubtree_kill_contracts','tkernel_ubtree_payload_contracts','tkernel_ubtree_method_contracts']
for stem in stems:
 for extension in ['cxx','expected']:paths.add(root/f'tools/oracle/{stem}.{extension}')
paths.add(root/'tools/oracle/tkernel_ebtree_add_noexcept.expected')
for name in ['tkernel_ubtree_trace.hxx','tkernel_ubtree_payload_trace.hxx','tkernel_ubtree_allocation_trace.hxx']:paths.add(root/'tools/oracle'/name)
names=['rust-children','negative-policy-send','negative-policy-sync','negative-policy-borrow','normal-array','miri-array','clippy-array','unit','miri-unit','normal','miri','docs','clippy','fmt','legacy','private-access','native-noexcept','candidate-build']+['native-'+stem for stem in stems]+['candidate-'+p for p in ['compatibility','negative-dropck','negative-send','negative-sync']]
logs={name:Path('/tmp/filler-owned-'+name+'.log').read_bytes() for name in names}
passed=lambda b:sum(map(int,re.findall(rb'test result: ok\. (\d+) passed',b)))
assert passed(logs['normal'])==235 and passed(logs['miri'])==233 and passed(logs['docs'])==278
assert passed(logs['normal-array'])==52 and passed(logs['miri-array'])==52
assert passed(logs['unit'])==3 and passed(logs['miri-unit'])==3
assert b'error:' not in logs['clippy'] and logs['fmt']==b''
joins=[]
for native,count in [('UBTree',9),('EBTree',7),('DataMap',36),('DynamicArray',52)]:
 suite='NCollection_'+native+'Test';original=sorted(re.findall(r'\[ RUN      \] '+suite+r'\.(\w+)',logs['legacy'].decode()))
 selected=logs['normal-array' if native=='DynamicArray' else 'normal'].decode()
 observed=re.findall(r'test ((?:\w+::)*'+suite+r'__(\w+)) \.\.\. ok',selected)
 rust=sorted(name for _,name in observed);assert original==rust and len(original)==count
 target={'UBTree':'ncollection_ubtree','EBTree':'ncollection_ubtree','DataMap':'ncollection_data_map','DynamicArray':'ncollection_dynamic_array'}[native]
 joins.extend({'native':suite+'.'+name,'rust':target+'::'+path} for path,name in sorted(observed))
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w') as tar:
 for p in sorted(paths):
  b=p.read_bytes();info=tarfile.TarInfo(rel(p));info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
artifacts={}
def artifact(name,b):
 p=root/f'porting/runtime-evidence/filler-owned-{name}.gz';p.write_bytes(gzip.compress(b,mtime=0));artifacts[rel(p)]=digest(p.read_bytes())
artifact('source.tar',archive.getvalue())
for name,b in logs.items():artifact(name+'.log',b)
artifact('original-test-joins.json',json.dumps(joins,indent=2).encode())
for name in ['make-filler-owned-receipt.py','run-filler-owned-rust-children.py','run-filler-owned-checks.py','run-filler-owned-native.py','run-filler-owned-prior-native.py','check-filler-owned-policy-captures.py','check-filler-owned-compatibility.py','ubtree-gemmate-parent-suites.txt']+['filler-owned-'+p+'.rs' for p in ['compatibility','negative-dropck','negative-send','negative-sync','negative-policy-send','negative-policy-sync','negative-policy-borrow']]:artifact(name,Path('/tmp/'+name).read_bytes())
artifact('selected-suites.txt','\n'.join(suites).encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
upstream=Path('/home/vmiguel/git/oblikovati-workspace/OCCT');headers=[upstream/'src/FoundationClasses/TKernel/NCollection'/f'NCollection_{n}.hxx' for n in ['UBTree','EBTree','DataMap','DefineAlloc','DefaultHasher','UBTreeFiller','DynamicArray']]
record={
 'schema':'rustycad.native-behavior-audit.v1',
 'scope':'Opt-in owning UBTreeFiller self-assignment policy for explicit Fill and noexcept automatic Fill',
 'integration_status':'Candidate; coordinating root integration/check/deletion required.',
 'base_revision':base,'dependency_revision':'f41305b6989ed03f5fb5ef34ed662459e3648630',
 'occt_revision':'3d097a0328e71b826377d4814ab05ec3c3d23871',
 'source_sha256':{rel(p):digest(p.read_bytes()) for p in sorted(paths)},
 'artifact_sha256':artifacts,
 'occt_source_sha256':{str(p.relative_to(upstream)):digest(p.read_bytes()) for p in headers},
 'source_scope':'Scoped tree/filler/map/allocator/DynamicArray sources, selected tests and native probes; not a complete dependency closure or whole-workspace checkpoint.',
 'prior_receipts':{f'porting/audits/{name}':digest((root/'porting/audits'/name).read_bytes()) for name in ['ubtree-filler-payload-methods.json','ubtree-filler-native-dispatch-methods.json','ubtree-method-batch.json']},
 'api_parity_credit':0,'original_declaration_mapping_credit':0,'compiler_body_binding_performed':False,'class_status':'partial',
 'method_bindings':[
  {'cpp':'NCollection_UBTreeFiller<T,B>::Fill selected-slot implicit copy assignment',
   'rust':'UBTreeFiller::with_self_assignment_policy -> UBTreeFillerWithSelfAssignment::fill -> existing fill_with_self_assignment',
   'domain':'Explicit caller capability handles identical slots on retained ObjBnd fields. Distinct slots, random generator, queue, insertion target and tree topology use the existing actual engine. No copied queue or shadow topology.'},
  {'cpp':'NCollection_UBTreeFiller<T,B>::~NCollection_UBTreeFiller invokes Fill when queue is nonempty; implicitly noexcept',
   'rust':'UBTreeFillerWithSelfAssignment::drop -> catch_unwind(fill) -> abort on error; successful inner Drop observes empty original queue',
   'domain':'Opt-in native automatic assignment behavior. Measured assignment failures terminate before member destruction or repeated insertion. C++ custom terminate-handler behavior and Rust process abort are not identical exit-code or handler APIs.'}
 ],
 'native_observations':[
  'The pinned native Filler and its DynamicArray member are nothrow-destructible. Two explicit Fill assignment failures propagate, preserving original queue and partial tree; a second Fill repeats insertion and matches full native default/assignment/destructor traces.',
  'Four child modes reject object or bounds self-assignment during ordinary destruction and during an existing outer unwind. Native custom terminate handler records exact callback prefixes and published root/allocator state, then exits86. Rust aborts with SIGABRT on Unix; its panic hook records the same prefix.',
  'Rust subprocesses separately observe exactly one genuine tree insertion, one retained policy call, and no payload or policy-capture destructor. Therefore a rejected automatic Fill does not fall into the old inner Filler Drop and replay the pending insertion.',
  'Ten prior full native success rows now match through the owning policy: both random modes, one/two/three objects, EBTree duplicate rejection, explicit Fill and implicit Drop. Actual pending allocator allocations reach zero after wrapper destruction. Full traces include pending Add construction and temporaries, insertion, assignment and queue cleanup.',
  'The native fixture uses GCC right-to-left call-argument construction. Rust test argument locals deliberately reproduce corresponding object-before-bounds destruction outside Add; this fixture ordering is not inferred as a portable C++ argument-order requirement.',
  'All prior308 ordinary/observation rows and6 pretermination snapshots regenerate unchanged; all104 relevant original test names join exactly.'
 ],
 'native_row_test_bindings':{
  'traits nothrow1/1':'native probe establishes implicit noexcept destructor domain; not a Rust trait equivalence',
  'Oe/Be caught+retry':'phases::explicit_failure_preserves_native_queue_and_partial_tree_for_retry',
  'Od/Bd/Ou/Bu termination':'termination::automatic_failure_aborts_before_inner_replay_or_capture_cleanup, invoking child_drop_failure_probe; native handler exit86 and Rust UnixSIGABRT are intentionally distinct',
  'prior full-phase tenrows':'phases::complete_native_success_stream_has_no_second_fill_or_cleanup_callbacks',
  'Reset and inherited CheckTree':'phases::reset_cancels_automatic_insertion_and_deref_preserves_check_tree',
  'borrowed policy/object and Clone-only bounds':'compatibility::policy_can_borrow_local_state_and_object_without_default_bounds',
  'old/new inferred Send+Sync+Unpin and actual scoped-thread Drop':'compatibility::inferred_ordinary_and_owning_filler_keep_thread_and_pin_traits'
 },
 'ownership_and_compatibility':{
  'existing_api':'Ordinary UBTreeFiller fields, generic parameters, inference and Drop are unchanged. No additional bounds or unsafe trait implementations. Its default identical-slot no-op remains an explicit separate domain.',
  'wrapper':'Owns the complete existing filler and a generic FnMut capability. Deref/DerefMut expose existing queue/reset/query methods; inherent fill selects retained policy. Callers who explicitly project the inner filler can deliberately use ordinary methods; no claim that this opt-in Rust adapter prohibits such escape hatches.',
  'panic':'Explicit fill remains recoverable and retains native retry semantics. Automatic fill catches a panic then aborts before inner fields can unwind; success empties the queue so inner Drop has no callbacks. Policy capture destruction itself is a Rust-only capability outside the native payload contract.',
  'compiler_evidence':'Existing covariance/dropck and positive trait probes remain accepted; existing invalid borrows/Send/Sync probes remain rejected. New owning-policy probes reject short captured borrows, captured Rc Send and captured Cell Sync. Runtime tests cover nonstatic object/policy borrows and scoped-thread destruction.',
  'source_constraints':'All new Rust functions/helpers are at most20 body lines and files are below500 lines. No DynamicArray or allocator engine changes.'
 },
 'checks':{
  'rust_primary_integration_passed':235,'rust_dynamic_array_original_passed':52,'rust_private_owner_passed':3,
  'miri_primary_integration_passed':233,'miri_dynamic_array_original_passed':52,'miri_private_owner_passed':3,
  'rust_total_passed':290,'miri_total_passed':288,
  'new_rust_tests':7,'new_miri_tests':5,
  'subprocess_exclusion':'Two subprocess test declarations are cfg(not(miri)); four termination scenarios run under ordinary Rust children. They are not claimed checked by Miri.',
  'miri_toolchain':'nightly-2026-09-25','miri_flags':'-Zmiri-strict-provenance',
  'rust_targets':suites,'miri_targets':suites,
  'private_owner_filter':'ncollection::ubtree::storage::pair::failed_contracts',
  'native_new_ordinary_observation_rows':5,'native_new_pretermination_rows':4,
  'native_prior_ordinary_observation_rows':308,'native_prior_pretermination_rows':6,
  'native_original_passed':104,'native_original_breakdown':{'UBTree':9,'EBTree':7,'DataMap':36,'DynamicArray':52},
  'native_rust_original_names_exactly_joined':True,'tkernel_doctests_passed':278,
  'strict_selected_clippy_exit':0,'strict_array_clippy_exit':0,'workspace_fmt_exit':0
 },
 'remaining_gaps':[
  'Existing default Fill/Drop still omit observable identical-slot assignment; callers select the explicit owning capability for this measured native behavior. Native class is not declared feature-complete.',
  'Rust abort has no OCCT/C++ set_terminate replacement API. The oracle uses a custom terminate handler exiting86; Rust children abort with SIGABRT. Panic hooks and arbitrary Rust policy-capture destructors have separate semantics. General C++ exception versus Rust unwind cleanup outside the measured assignment-failure domain is not equated.',
  'Existing add/add_ref do not infer native move/copy capabilities. Explicit add_ref_with_constructor handles the proven construction domain. ObjBnd/TreeNode ABI layout/request sizes and self-address-sensitive construction remain open.',
  'Standalone destructor-time link nulling, raw reentrant observers, null move allocator state, and generic native inheritance/ABI surfaces remain open. No global API or test-declaration completion credit is added.'
 ],
 'validation_history':'Final formatted candidate validates290 scoped Rust tests and288 strict-provenance Miri tests (subprocess tests excluded),278doctests,strict selected Clippy and fmt. Native313ordinary/observation rows plus10pretermination rows are archived, with104exact original joins. Source and proof artifacts are committed for checkout deletion.'
}
(root/'porting/audits/ubtree-filler-owned-policy-methods.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'sources':len(paths),'artifacts':len(artifacts),'legacy_joins':len(joins),'rust':290,'miri':288}))
