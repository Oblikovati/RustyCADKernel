from pathlib import Path
import json,os,subprocess
root=Path('/tmp/rustycad-ubtree-filler-owned-policy');target=Path('/tmp/rustycad-sparse-base-target')
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'])
items=[json.loads(line) for line in Path('/tmp/filler-owned-candidate-build.log').read_bytes().splitlines() if line.startswith(b'{')]
lib=[p for item in items if item.get('reason')=='compiler-artifact' and item['target']['name']=='rustycad_tkernel' for p in item['filenames'] if p.endswith('.rlib')][-1]
preamble='''use rustycad_tkernel::ncollection::{BoundingVolume, UBTree, UBTreeFiller};
#[derive(Clone)] struct Bounds;
impl BoundingVolume for Bounds { fn add(&mut self,_:&Self){} fn is_out(&self,_:&Self)->bool{false} fn square_extent(&self)->f64{0.0} }
fn require_send<T:Send>(_: &T){} fn require_sync<T:Sync>(_: &T){}
'''
bodies={
'negative-policy-send':'''fn main(){let mut tree=UBTree::<i32,Bounds>::default();let capture=std::rc::Rc::new(1);let filler=UBTreeFiller::new(&mut tree,None,true).with_self_assignment_policy(move |_|{std::hint::black_box(&capture);});require_send(&filler);}''',
'negative-policy-sync':'''fn main(){let mut tree=UBTree::<i32,Bounds>::default();let capture=std::cell::Cell::new(1);let filler=UBTreeFiller::new(&mut tree,None,true).with_self_assignment_policy(move |_|{std::hint::black_box(&capture);});require_sync(&filler);}''',
'negative-policy-borrow':'''fn main(){let mut tree=UBTree::<i32,Bounds>::default();let filler;{let capture=String::from("local");filler=UBTreeFiller::new(&mut tree,None,true).with_self_assignment_policy(|_|{std::hint::black_box(&capture);});}drop(filler);}'''}
for name,body in bodies.items():
 source=Path('/tmp/filler-owned-'+name+'.rs');source.write_text(preamble+body)
 result=subprocess.run(['rustc','--edition=2024',str(source),'--extern','rustycad_tkernel='+lib,'-L','dependency='+str(target/'debug/deps'),'-o','/tmp/filler-owned-'+name],cwd=root,env=env,capture_output=True)
 Path('/tmp/filler-owned-'+name+'.log').write_bytes(result.stdout+result.stderr)
 assert result.returncode==1
 expected=b'does not live long enough' if name.endswith('borrow') else (b'cannot be sent' if name.endswith('send') else b'cannot be shared')
 assert expected in result.stderr,(name,result.stderr)
 print(name,result.returncode)
