//! `SelectMgr_Frustum<N>`: the separating axis tests of a frustum of `N` side planes (4 for the
//! rectangular frustum, 3 for the triangular one) against boxes, points, segments, polygons
//! and triangles. The quadric tests are in frustum_quadrics.rs.
use rustycad_tkernel::ncollection::Vec3;
use rustycad_tkernel::precision::confusion;
use rustycad_tkernel::standard::Failure;
use rustycad_tkernel::standard::exceptions::program_error;
use rustycad_tkernel::standard::real::{real_first, real_last};
use rustycad_tkmath::bvh::{std_max, std_min};
use rustycad_tkmath::gp::{Point3, Xyz};

/// The planes, vertices, cached projections and edge directions of a frustum.
#[derive(Clone, Debug)]
pub struct SelectMgrFrustumCore {
    /// `N`: the number of side planes.
    pub n: usize,
    /// `myPlanes` (`N + 2` unnormalized normals).
    pub planes: Vec<Xyz>,
    /// `myVertices` (`2 N` points).
    pub vertices: Vec<Point3>,
    /// `myMaxVertsProjections`.
    pub max_verts_projections: Vec<f64>,
    /// `myMinVertsProjections`.
    pub min_verts_projections: Vec<f64>,
    /// `myMaxOrthoVertsProjections`.
    pub max_ortho_verts_projections: [f64; 3],
    /// `myMinOrthoVertsProjections`.
    pub min_ortho_verts_projections: [f64; 3],
    /// `myEdgeDirs`.
    pub edge_dirs: [Xyz; 6],
}

/// The coordinate of a vector along an axis index.
pub(crate) fn axis_of(v: &Vec3<f64>, axis: usize) -> f64 {
    match axis {
        0 => v.x,
        1 => v.y,
        _ => v.z,
    }
}

/// The `Standard_ProgramError` of a box projection whose maximum is below its minimum (NaN).
fn projection_error() -> Failure {
    program_error("Error! Failed to project box; expected finite box corners")
}

/// The projections of a box on a direction: the minimum and maximum corners chosen by sign.
fn box_projection(dir: &Xyz, min: &Vec3<f64>, max: &Vec3<f64>, bound: f64) -> (f64, f64) {
    let pick = |d: f64, lo: f64, hi: f64| if d < bound { hi } else { lo };
    let proj_min = dir.x() * pick(dir.x(), min.x, max.x)
        + dir.y() * pick(dir.y(), min.y, max.y)
        + dir.z() * pick(dir.z(), min.z, max.z);
    let proj_max = dir.x() * pick(dir.x(), max.x, min.x)
        + dir.y() * pick(dir.y(), max.y, min.y)
        + dir.z() * pick(dir.z(), max.z, min.z);
    (proj_min, proj_max)
}

impl SelectMgrFrustumCore {
    /// A zeroed frustum of `n` side planes (the native constructor clears the projections).
    /// Example: `SelectMgrFrustumCore::new(4)`.
    pub fn new(n: usize) -> Self {
        Self {
            n,
            planes: vec![Xyz::new(0.0, 0.0, 0.0); n + 2],
            vertices: vec![Point3::default(); 2 * n],
            max_verts_projections: vec![0.0; n + 2],
            min_verts_projections: vec![0.0; n + 2],
            max_ortho_verts_projections: [0.0; 3],
            min_ortho_verts_projections: [0.0; 3],
            edge_dirs: [Xyz::new(0.0, 0.0, 0.0); 6],
        }
    }
    /// The plane step: the opposite planes of an orthographic rectangular frustum are skipped.
    fn inc_factor(&self, is_ortho: bool) -> usize {
        if is_ortho && self.n == 4 { 2 } else { 1 }
    }
    /// The number of edge directions tested (4 for an orthographic camera).
    fn directions_nb(is_ortho: bool) -> usize {
        if is_ortho { 4 } else { 6 }
    }
    /// `isSeparated(box, direction, inside)`: the box and the frustum projections on a
    /// direction do not overlap; refines the full-inside flag.
    fn is_separated_box(
        &self,
        min: &Vec3<f64>,
        max: &Vec3<f64>,
        direct: &Xyz,
        inside: &mut Option<&mut bool>,
    ) -> Result<bool, Failure> {
        let (min_b, max_b) = box_projection(direct, min, max, 0.0);
        if !(max_b >= min_b) {
            return Err(projection_error());
        }
        let (mut min_f, mut max_f) = (f64::MAX, -f64::MAX);
        for vertex in &self.vertices {
            let proj = vertex.xyz().dot(*direct);
            min_f = std_min(min_f, proj);
            max_f = std_max(max_f, proj);
            if min_f <= max_b && max_f >= min_b && inside.as_ref().is_none_or(|flag| !**flag) {
                return Ok(false);
            }
        }
        if min_f > max_b || max_f < min_b {
            return Ok(true);
        }
        if let Some(flag) = inside.as_mut() {
            **flag &= min_b >= min_f && max_b <= max_f;
        }
        Ok(false)
    }
    /// `isSeparated(triangle, axis)`: the triangle and frustum projections do not overlap.
    pub(crate) fn is_separated_triangle(
        &self,
        p1: &Point3,
        p2: &Point3,
        p3: &Point3,
        axis: &Xyz,
    ) -> bool {
        let (mut min_f, mut max_f) = (real_last(), real_first());
        let (mut min_tr, mut max_tr) = (real_last(), real_first());
        for p in [p1, p2, p3] {
            let proj = axis.dot(p.xyz());
            min_tr = std_min(min_tr, proj);
            max_tr = std_max(max_tr, proj);
        }
        for vertex in &self.vertices {
            let proj = vertex.xyz().dot(*axis);
            min_f = std_min(min_f, proj);
            max_f = std_max(max_f, proj);
            if min_f <= max_tr && max_f >= min_tr {
                return false;
            }
        }
        min_f > max_tr || max_f < min_tr
    }
    /// The axis-aligned test of `hasBoxOverlap`; false when separated.
    fn box_ortho_overlap(
        &self,
        min: &Vec3<f64>,
        max: &Vec3<f64>,
        inside: &mut Option<&mut bool>,
    ) -> bool {
        for axis in 0..3 {
            let (lo, hi) = (axis_of(min, axis), axis_of(max, axis));
            if lo > self.max_ortho_verts_projections[axis]
                || hi < self.min_ortho_verts_projections[axis]
            {
                return false;
            }
            if let Some(flag) = inside.as_mut() {
                **flag &= lo >= self.min_ortho_verts_projections[axis]
                    && hi <= self.max_ortho_verts_projections[axis];
            }
        }
        true
    }
    /// The frustum plane test of `hasBoxOverlap`; false when separated.
    fn box_planes_overlap(
        &self,
        min: &Vec3<f64>,
        max: &Vec3<f64>,
        is_ortho: bool,
        inside: &mut Option<&mut bool>,
    ) -> Result<bool, Failure> {
        for plane_idx in (0..self.n + 1).step_by(self.inc_factor(is_ortho)) {
            // The native comparison is against `0.f`.
            let (proj_min, proj_max) = box_projection(&self.planes[plane_idx], min, max, 0.0);
            if !(proj_max >= proj_min) {
                return Err(projection_error());
            }
            if proj_min > self.max_verts_projections[plane_idx]
                || proj_max < self.min_verts_projections[plane_idx]
            {
                return Ok(false);
            }
            if let Some(flag) = inside.as_mut() {
                **flag &= proj_min >= self.min_verts_projections[plane_idx]
                    && proj_max <= self.max_verts_projections[plane_idx];
            }
        }
        Ok(true)
    }
    /// `hasBoxOverlap`: the separating axis test of a box (refining the full-inside flag); a
    /// NaN box raises the `Standard_ProgramError` of the projection assert.
    /// Example: `core.has_box_overlap(&min, &max, false, None)?`.
    pub fn has_box_overlap(
        &self,
        min: &Vec3<f64>,
        max: &Vec3<f64>,
        is_ortho: bool,
        inside: Option<&mut bool>,
    ) -> Result<bool, Failure> {
        let mut inside = inside;
        if !self.box_ortho_overlap(min, max, &mut inside)
            || !self.box_planes_overlap(min, max, is_ortho, &mut inside)?
        {
            return Ok(false);
        }
        for dim in 0..3 {
            let (next, next_next) = ((dim + 1) % 3, (dim + 2) % 3);
            for vol_dir in 0..Self::directions_nb(is_ortho) {
                let edge = self.edge_dirs[vol_dir];
                let mut direction = [f64::MAX; 3];
                direction[dim] = 0.0;
                direction[next] = -edge.coordinates()[next_next];
                direction[next_next] = edge.coordinates()[next];
                let direction = Xyz::new(direction[0], direction[1], direction[2]);
                if self.is_separated_box(min, max, &direction, &mut inside)? {
                    return Ok(false);
                }
            }
        }
        Ok(true)
    }
    /// `hasPointOverlap`: the point is between every pair of frustum planes.
    /// Example: `core.has_point_overlap(&p, false)`.
    pub fn has_point_overlap(&self, point: &Point3, is_ortho: bool) -> bool {
        (0..self.n + 1)
            .step_by(self.inc_factor(is_ortho))
            .all(|plane_idx| {
                let proj = self.planes[plane_idx].dot(point.xyz());
                !(proj > self.max_verts_projections[plane_idx]
                    || proj < self.min_verts_projections[plane_idx])
            })
    }
    /// The min and max projections of the frustum vertices on a direction.
    fn vertex_range(&self, dir: &Xyz, init: (f64, f64)) -> (f64, f64) {
        self.vertices.iter().fold(init, |(lo, hi), v| {
            let proj = dir.dot(v.xyz());
            (std_min(lo, proj), std_max(hi, proj))
        })
    }
    /// `hasSegmentOverlap`: the separating axis test of a segment (a degenerate segment overlaps).
    /// Example: `core.has_segment_overlap(&a, &b, false)`.
    pub fn has_segment_overlap(&self, start: &Point3, end: &Point3, is_ortho: bool) -> bool {
        let dir = end.xyz() - start.xyz();
        if dir.modulus() < confusion() {
            return true;
        }
        for plane_idx in (0..self.n + 1).step_by(self.inc_factor(is_ortho)) {
            let plane = self.planes[plane_idx];
            let (p1, p2) = (plane.dot(start.xyz()), plane.dot(end.xyz()));
            if std_min(p1, p2) > self.max_verts_projections[plane_idx]
                || std_max(p1, p2) < self.min_verts_projections[plane_idx]
            {
                return false;
            }
        }
        let (min2, max2) = self.vertex_range(&dir, (f64::MAX, -f64::MAX));
        let (p1, p2) = (dir.dot(start.xyz()), dir.dot(end.xyz()));
        if std_min(p1, p2) > max2 || std_max(p1, p2) < min2 {
            return false;
        }
        for edge_idx in 0..Self::directions_nb(is_ortho) {
            let test_dir = dir.crossed(self.edge_dirs[edge_idx]);
            let (p1, p2) = (test_dir.dot(start.xyz()), test_dir.dot(end.xyz()));
            let (min_f, max_f) = self.vertex_range(&test_dir, (f64::MAX, -f64::MAX));
            if std_min(p1, p2) > max_f || std_max(p1, p2) < min_f {
                return false;
            }
        }
        true
    }
    /// The min and max projections of points on a direction (starting at RealLast/RealFirst).
    fn points_range(points: &[Point3], dir: &Xyz) -> (f64, f64) {
        points
            .iter()
            .fold((real_last(), real_first()), |(lo, hi), p| {
                let proj = dir.dot(p.xyz());
                (std_min(lo, proj), std_max(hi, proj))
            })
    }
    /// `hasPolygonOverlap`: the separating axis test of a polygon, with its normal from the
    /// first three points. Example: `core.has_polygon_overlap(&points, false)`.
    pub fn has_polygon_overlap(&self, points: &[Point3], is_ortho: bool) -> (bool, Xyz) {
        let (p1, p2, p3) = (points[0].xyz(), points[1].xyz(), points[2].xyz());
        let normal = (p3 - p2).crossed(p1 - p2);
        let polyg_proj = normal.dot(p1);
        let (min, max) = self.vertex_range(&normal, (real_last(), real_first()));
        if polyg_proj > max || polyg_proj < min {
            return (false, normal);
        }
        for plane_idx in (0..self.n + 1).step_by(self.inc_factor(is_ortho)) {
            let (min_polyg, max_polyg) = Self::points_range(points, &self.planes[plane_idx]);
            if min_polyg > self.max_verts_projections[plane_idx]
                || max_polyg < self.min_verts_projections[plane_idx]
            {
                return (false, normal);
            }
        }
        let len = points.len();
        for iter in 0..len {
            let segm_dir = points[(iter + 1) % len].xyz() - points[iter].xyz();
            for vol_dir in 0..Self::directions_nb(is_ortho) {
                let test_dir = segm_dir.crossed(self.edge_dirs[vol_dir]);
                let (min_polyg, max_polyg) = Self::points_range(points, &test_dir);
                let (min_f, max_f) = self.vertex_range(&test_dir, (real_last(), real_first()));
                if min_polyg > max_f || max_polyg < min_f {
                    return (false, normal);
                }
            }
        }
        (true, normal)
    }
    /// `hasTriangleOverlap`: the separating axis test of a triangle, with its normal.
    /// Example: `core.has_triangle_overlap(&a, &b, &c, false)`.
    pub fn has_triangle_overlap(
        &self,
        p1: &Point3,
        p2: &Point3,
        p3: &Point3,
        is_ortho: bool,
    ) -> (bool, Xyz) {
        let edges = [
            p2.xyz() - p1.xyz(),
            p3.xyz() - p2.xyz(),
            p1.xyz() - p3.xyz(),
        ];
        let unset = Xyz::new(real_last(), real_last(), real_last());
        for plane_idx in (0..self.n + 1).step_by(self.inc_factor(is_ortho)) {
            let plane = self.planes[plane_idx];
            let proj = plane.dot(p1.xyz());
            let (mut lo, mut hi) = (proj, proj);
            for p in [p2, p3] {
                let proj = plane.dot(p.xyz());
                lo = std_min(lo, proj);
                hi = std_max(hi, proj);
            }
            if lo > self.max_verts_projections[plane_idx]
                || hi < self.min_verts_projections[plane_idx]
            {
                return (false, unset);
            }
        }
        let normal = edges[2].crossed(edges[0]);
        if self.is_separated_triangle(p1, p2, p3, &normal) {
            return (false, normal);
        }
        for edge in &edges {
            for vol_dir in 0..Self::directions_nb(is_ortho) {
                let test = self.edge_dirs[vol_dir].crossed(*edge);
                if self.is_separated_triangle(p1, p2, p3, &test) {
                    return (false, normal);
                }
            }
        }
        (true, normal)
    }
}
