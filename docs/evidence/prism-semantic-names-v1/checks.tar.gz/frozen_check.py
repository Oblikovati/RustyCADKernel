import hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd(); out=root/'target/semantic-names-prefix'
files=subprocess.check_output(['git','ls-files','crates','Cargo.toml','Cargo.lock']).decode().splitlines()
def bookend():
 return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files if (root/name).is_file()}
(out/'source-before.json').write_text(json.dumps(bookend(),sort_keys=True))
commands=[
 ['cargo','test','-p','rustycad-tkbo','--lib','owned_request::names','--jobs','2'],
 ['cargo','test','-p','rustycad-tkbo','--lib','frozen::replay_tests','--jobs','2'],
 ['cargo','clippy','-p','rustycad-tkbo','--lib','--all-features','--jobs','2','--','-D','warnings'],
 ['cargo','fmt','--all','--','--check'],
]
results=[]
for n,command in enumerate(commands):
 with (out/f'frozen-{n}.log').open('w') as log:
  done=subprocess.run(['/home/vmiguel/.cargo/bin/rustup','run','1.99.0',*command],stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit':done.returncode,'log':f'frozen-{n}.log'})
 if done.returncode: break
(out/'source-after.json').write_text(json.dumps(bookend(),sort_keys=True))
(out/'commands.json').write_text(json.dumps(results,indent=2))
