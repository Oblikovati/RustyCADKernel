import pathlib,json,hashlib,tarfile,re,subprocess
root=pathlib.Path.cwd(); staging=root/'target/owned-projection-failure'; frozen=staging/'frozen'; out=root/'docs/evidence/owned-projection-refusal-v1'
before=json.loads((frozen/'source-before.json').read_text());after=json.loads((frozen/'source-after.json').read_text());assert before==after
commands=json.loads((frozen/'commands.json').read_text());assert len(commands)==5 and all(x['exit']==0 for x in commands)
def results(name):
 return [{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (frozen/(name+'.log')).read_text())]
archive=out/'frozen.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(frozen.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(staging)))
 for p in sorted(staging.glob('*.log')):tar.add(p,arcname='development/'+p.name)
 tar.add(staging/'seal.py',arcname='seal.py')
receipt={'source_revision':json.loads((frozen/'provenance.json').read_text())['revision'],'provenance':json.loads((frozen/'provenance.json').read_text()),'commands':commands,'all_target_results':results('all-targets'),'all_target_passed':sum(x['passed'] for x in results('all-targets')),'doctests':results('doctests'),'tracked_file_bookends':{'count':len(before),'equal':True},'replay':json.loads((frozen/'processes/replay.json').read_text()),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'Private actual Projection family only. Other scoped families returned in identical original Box. Accepted publication is failure context, not outer success.','review':{'reviewer':'coordinator','source':'9699a8adf','scope':'ownership/move, classification, full request and accepted-publication envelope, body/volume typed encoders','finding':'No blocker found in reviewed scope','reviewer_executed_tests':False},'retained_development_failures':['baseline/key-seam.log: system rustc1.95 selected by missing PATH pin; corrected1.99 invocation passed','focused-first.log: test AuthoredPrismId import corrected to frozen facade','clippy-prefix.log: redundant let-return and176byte Err; corrected with identical boxed unsupported error return'],'exclusions':['ThreadSanitizer incomplete at retained unchanged-host startup control; no repeat or bypass','No live OCCT/native GPU runs','No release performance or application acceptance claim','Preparation, Resolution and Publication full owned refusal families remain incomplete']}
(out/'frozen.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'all_target_passed':receipt['all_target_passed'],'doctests':receipt['doctests'],'archive_sha256':receipt['archive_sha256']}))
