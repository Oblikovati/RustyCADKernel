import hashlib,json,platform,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-joined-orientation')
RUN=Path('/tmp/martensite-joined-orientation-checks')
STAGE=Path('/tmp/martensite-joined-orientation-evidence')
OUT=ROOT/'docs/evidence/prism-joined-orientation'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)
def count(name):
    return sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(RUN/'frozen'/(name+'.log')).read_text())))
def replay(path,prefix):
    rows=[line[len(prefix):] for line in path.read_text().splitlines() if line.startswith(prefix)]
    assert len(rows)==1,(str(path),len(rows))
    return rows[0]
assert not STAGE.exists()
matrix=json.loads((RUN/'frozen/receipt.json').read_text())
san=json.loads((RUN/'frozen/sanitizer.json').read_text())
assert matrix['source_unchanged'] and san['source_unchanged']
assert all(row['exit_code']==0 for row in matrix['commands'])
joined=replay(RUN/'frozen/focused.log','joined-orientation-v1:')
assert joined==replay(RUN/'full-entry-corrected.log','joined-orientation-v1:')
(RUN/'frozen/joined-orientation.bin').write_bytes(bytes.fromhex(joined))
legacy_root=ROOT/'crates/tkbo/src/sketch_region_prism/region_certificate/orientation/tests'
for name,prefix in [('orientation-v1.json','{"operation":"martensite.prism-orientation"'),('callbacks-v1.json','{"legacy_orientation_polls"')]:
    observed=prefix+replay(RUN/'frozen/legacy.log',prefix)
    assert observed==(legacy_root/name).read_text().strip()
for p in RUN.iterdir():
    if p.is_file():copy(p,STAGE/'development'/p.name)
for p in (RUN/'frozen').iterdir():
    if p.is_file():copy(p,STAGE/'frozen'/p.name)
names=subprocess.check_output(['git','diff','--name-only','93fac56f2','HEAD','--','crates','docs/adr'],cwd=ROOT).decode().splitlines()
for name in names:copy(ROOT/name,STAGE/'candidate-source'/name)
report=dict(operation='Martensite private joined prism orientation',behavior_version=1,
 source_revision=matrix['revision'],base_revision='979aa17b2',dependency_revision='93fac56f2',
 baseline_revision='9026f7e51',borrowed_extraction_revision='7863c33ee',owned_error_revision='07922628f',
 platform=platform.platform(),matrix=matrix,sanitizer=san,
 candidate_files={name:digest(ROOT/name) for name in names},
 checks={name:count(name) for name in ['focused','legacy','tests','doctests']},
 replay=dict(complete_joined_bytes=len(bytes.fromhex(joined)),unchanged_from_e6ed_prefix=True,
             unchanged_legacy_orientation=True,unchanged_legacy_callbacks=1949,
             independent_workers=8,operations_per_worker=4,separate_processes=2),
 independent_expectations=dict(pole_traversal_extrusion_combinations=8,faces_per_case=3,trims_per_case=6,
                              algebra_source='ADR0034 retained exact algebra; no new evaluator'),
 review_correction=dict(source='e6ed1e400',finding='pure error type admitted unreachable mutable legacy Embedding/Binding diagnostics',
                        correction='07922628f narrow owned five-cause/two-phase enum and exhaustive unchanged legacy adapters'),
 scope=dict(body='incomplete; conditional exact directions only',freshness='owned join; explicit live rebind remains join-owner responsibility'),
 exclusions=['no native OCCT execution or new native fixtures','no tessellation or GPU acceptance','no live capture or second mapping engine',
             'no host protection or instrumentation changes','no public body or Kernel#10 completion','no performance claim'])
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
files=sorted(p for p in STAGE.rglob('*') if p.is_file())
(STAGE/'SHA256SUMS').write_text(''.join(digest(p)+'  '+str(p.relative_to(STAGE))+'\n' for p in files))
with tarfile.open(OUT/'runs.tar.gz','w:gz') as archive:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():archive.add(p,arcname=str(p.relative_to(STAGE)),recursive=False)
print(json.dumps(dict(candidate_files=len(names),retained_files=len(files)+1,checks=report['checks'],joined_bytes=report['replay']['complete_joined_bytes'],archive_bytes=(OUT/'runs.tar.gz').stat().st_size)))
