use super::OrderedItems;
impl<'a, K, V> OrderedItems<'a, K, V> {
    pub fn current_pair(&self) -> Option<(&'a K, &'a V)> {
        let node = self.slots.get(self.current?)?.as_ref()?;
        Some((&node.key, &node.value))
    }
    pub fn restart(&mut self) {
        self.current = self.first;
    }
    pub fn advance(&mut self) {
        self.current = self
            .current
            .and_then(|slot| self.slots[slot].as_ref()?.next);
    }
}
impl<'a, K, V> Iterator for OrderedItems<'a, K, V> {
    type Item = (&'a K, &'a V);
    fn next(&mut self) -> Option<Self::Item> {
        let pair = self.current_pair()?;
        self.advance();
        Some(pair)
    }
}
impl<K, V> Clone for OrderedItems<'_, K, V> {
    fn clone(&self) -> Self {
        Self {
            slots: self.slots,
            current: self.current,
            first: self.first,
        }
    }
}
impl<K, V> Default for OrderedItems<'_, K, V> {
    fn default() -> Self {
        Self {
            slots: &[],
            current: None,
            first: None,
        }
    }
}
impl<K, V> PartialEq for OrderedItems<'_, K, V> {
    fn eq(&self, other: &Self) -> bool {
        self.current_pair().map(|(key, _)| key as *const K)
            == other.current_pair().map(|(key, _)| key as *const K)
    }
}
impl<K, V> Eq for OrderedItems<'_, K, V> {}
