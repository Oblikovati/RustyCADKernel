from pathlib import Path
import os,re,subprocess
log=Path('/tmp/filler-owned-normal.log').read_text()
exe=re.search(r'Running tests/ubtree_filler_owned_policy_contracts.rs \(([^)]+)\)',log).group(1)
rows=[]
for mode in ['Od','Bd','Ou','Bu']:
 result=subprocess.run([exe,'--exact','termination::child_drop_failure_probe','--nocapture'],env=dict(os.environ,RUSTYCAD_FILLER_DROP_PROBE=mode),capture_output=True,text=True)
 assert result.returncode==-6,(mode,result.returncode)
 assert result.stderr.count('insertion\n')==1 and result.stderr.count('policy\n')==1
 assert 'payload_drop' not in result.stderr and 'capture_drop' not in result.stderr
 rows.append(f'case {mode} status {result.returncode}\n'+result.stderr)
Path('/tmp/filler-owned-rust-children.log').write_text(''.join(rows))
print(''.join(rows),end='')
