import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

root = Path.cwd()
destination = root / 'target/side-integral-evidence/frozen-e60e9b30b'
destination.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment['PATH'] = '/home/vmiguel/.cargo/bin:' + environment['PATH']
environment['CARGO_BUILD_JOBS'] = '2'

def source_snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
    selected = [name for name in names if name.startswith(('crates/', '.cargo/')) or name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml')]
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in selected if (root / name).is_file()}

before = source_snapshot()
(destination / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
receipt = {
    'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
    'platform': platform.platform(),
    'rustc': subprocess.check_output(['rustc', '+1.99.0', '-Vv'], env=environment).decode(),
    'cargo_build_jobs': 2, 'test_threads': 1,
    'inherited_instrumentation': {key: environment.get(key) for key in ('LD_PRELOAD', 'RUSTFLAGS', 'RUSTDOCFLAGS', 'TSAN_OPTIONS')},
    'checks': [],
}
commands = [
    ('focused', ['cargo', '+1.99.0', 'test', '-p', 'rustycad-tkmath', '--lib', 'polynomial_side', '--locked', '--', '--nocapture', '--test-threads=1']),
    ('full-tests', ['cargo', '+1.99.0', 'test', '-p', 'rustycad-tkmath', '--all-features', '--locked', '--', '--test-threads=1']),
    ('docs', ['cargo', '+1.99.0', 'doc', '-p', 'rustycad-tkmath', '--no-deps', '--all-features', '--locked']),
    ('clippy', ['cargo', '+1.99.0', 'clippy', '-p', 'rustycad-tkmath', '--all-targets', '--all-features', '--locked', '--', '-D', 'warnings']),
    ('fmt', ['cargo', '+1.99.0', 'fmt', '-p', 'rustycad-tkmath', '--', '--check']),
    ('diff-check', ['git', 'diff', '--check']),
]
for name, command in commands:
    started = time.time()
    with (destination / (name + '.log')).open('wb') as output:
        result = subprocess.run(command, env=environment, stdout=output, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': time.time()-started}
    receipt['checks'].append(record)
    (destination / 'checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(record), flush=True)
after = source_snapshot()
(destination / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt['source_files'] = len(before)
receipt['source_unchanged'] = before == after
receipt['source_differences'] = [key for key in before.keys() | after.keys() if before.get(key) != after.get(key)]
receipt['test_binary_hashes'] = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in (root / 'target/debug/deps').iterdir() if path.is_file() and os.access(path, os.X_OK) and path.name.startswith(('rustycad_tkmath-', 'toolkit-'))}
(destination / 'checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source_unchanged': receipt['source_unchanged'], 'source_files': len(before)}), flush=True)
raise SystemExit(0 if before == after and all(row['exit_code'] == 0 for row in receipt['checks']) else 1)
