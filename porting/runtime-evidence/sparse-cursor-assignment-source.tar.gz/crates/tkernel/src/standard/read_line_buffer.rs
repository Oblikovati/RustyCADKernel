// Rust translation of FoundationClasses/TKernel/Standard/Standard_ReadLineBuffer.hxx at 3d097a0328e71b826377d4814ab05ec3c3d23871.

//! `Standard_ReadLineBuffer`: splits a stream into lines through a fixed-size read buffer.
use super::FreadStream;
use super::stream_fill::fill_from;
use super::{IstreamException, IstreamStream};
use std::io::Read;
mod scan;

#[cfg(test)]
#[path = "read_line_buffer/istream_exception_tests.rs"]
mod istream_exception_tests;
#[cfg(test)]
#[path = "read_line_buffer/stream_hook_tests.rs"]
mod stream_hook_tests;

/// Where the line a call returns lives.
#[derive(Clone, Copy)]
enum LineSpan {
    /// Bytes `start..start + length` of the read buffer.
    Buffer(usize, usize),
    /// The first `length` bytes of the carried-over partial line.
    Carried(usize),
}

/// Line reader over any stream; `ReadLineBuffer::new(4096).read_line(&mut stream)`.
///
/// A returned line excludes its `\n` (and a `\r` before it), which are overwritten with
/// NUL in the buffer as natively. A line split across reads is assembled in a carry-over
/// buffer; the final line of a stream without a newline is returned whole. In multiline
/// mode a backslash before the newline joins lines, optionally leaving a space.
pub struct ReadLineBuffer {
    read_buffer: Vec<u8>,
    carried: Vec<u8>,
    // True once the carry-over storage was ever allocated (NCollection_LinearVector keeps
    // a null Data() until its first non-empty Resize, and Clear keeps the storage).
    carried_allocated: bool,
    use_carried: bool,
    multiline: bool,
    put_gap: bool,
    position: usize,
    last_read: usize,
}

impl ReadLineBuffer {
    /// Allocates a zeroed read buffer of `max_buffer_size` bytes; `ReadLineBuffer::new(4096)`.
    pub fn new(max_buffer_size: usize) -> Self {
        Self {
            read_buffer: vec![0; max_buffer_size],
            carried: Vec::new(),
            carried_allocated: false,
            use_carried: false,
            multiline: false,
            put_gap: true,
            position: 0,
            last_read: 0,
        }
    }

    /// Forgets buffered data and resets the modes to their defaults; `buffer.clear()`.
    /// The read buffer keeps its bytes; the next call reads a fresh block.
    pub fn clear(&mut self) {
        self.carried.clear();
        self.use_carried = false;
        self.multiline = false;
        self.put_gap = true;
        self.position = 0;
        self.last_read = 0;
    }

    /// Reads the next line, or `None` at the end of the stream or on a read error;
    /// `buffer.read_line(&mut stream)`. Empty lines are returned as empty slices.
    pub fn read_line(&mut self, stream: &mut impl Read) -> Option<&[u8]> {
        let mut read_data = 0;
        self.read_line_counted(stream, &mut read_data)
    }

    /// Reads the next line and stores in `read_data` the size of the last block read
    /// during this call (0 when the line came from the buffer); `buffer.read_line_counted(&mut s, &mut n)`.
    pub fn read_line_counted(
        &mut self,
        stream: &mut impl Read,
        read_data: &mut i64,
    ) -> Option<&[u8]> {
        *read_data = 0;
        let span = self.next_line(|buffer| read_rust_stream(stream, buffer), read_data)?;
        Some(self.line_for_span(span))
    }

    /// Reads a line from an `fread`-style adapter, preserving sticky error state;
    /// `buffer.read_line_file(&mut file)`. Empty lines are returned as empty slices.
    pub fn read_line_file<R: Read>(&mut self, stream: &mut FreadStream<R>) -> Option<&[u8]> {
        let mut read_data = 0;
        self.read_line_file_counted(stream, &mut read_data)
    }

    /// Reads a file-adapted line and reports the last successful block size;
    /// `buffer.read_line_file_counted(&mut file, &mut count)`.
    pub fn read_line_file_counted<R: Read>(
        &mut self,
        stream: &mut FreadStream<R>,
        read_data: &mut i64,
    ) -> Option<&[u8]> {
        *read_data = 0;
        let span = self.next_line(|buffer| stream.read_block(buffer), read_data)?;
        Some(self.line_for_span(span))
    }

    /// Reads at most `len` bytes into the internal buffer like the protected native stream hook;
    /// `buffer.read_stream(&mut stream, 4, &mut count)`. `len` must not exceed the allocated buffer.
    pub fn read_stream(
        &mut self,
        stream: &mut impl Read,
        len: usize,
        read_len: &mut usize,
    ) -> bool {
        if len > self.read_buffer.len() {
            *read_len = 0;
            return false;
        }
        let filled = fill_from(stream, &mut self.read_buffer[..len]);
        *read_len = filled.count;
        !filled.failed
    }

    /// Uses the exception-mask-aware native stream protocol; `buffer.read_stream_istream(&mut stream, 4, &mut count)?`.
    pub fn read_stream_istream<R: Read>(
        &mut self,
        stream: &mut IstreamStream<R>,
        len: usize,
        read_len: &mut usize,
    ) -> Result<bool, IstreamException> {
        let Some(buffer) = self.read_buffer.get_mut(..len) else {
            *read_len = 0;
            return Ok(false);
        };
        let result = stream.read_block(buffer)?;
        *read_len = result.gcount();
        Ok(result.is_good())
    }

    /// Reads a line while preserving native exception-mask state transitions;
    /// `let line = buffer.read_line_istream(&mut stream, &mut length, &mut count)?`.
    pub fn read_line_istream<R: Read>(
        &mut self,
        stream: &mut IstreamStream<R>,
        line_length: &mut usize,
        read_data: &mut i64,
    ) -> Result<Option<&[u8]>, IstreamException> {
        *line_length = 0;
        *read_data = 0;
        let span = self.next_line_fallible(
            |buffer| {
                stream
                    .read_block(buffer)
                    .map(|result| (result.gcount(), result.is_good()))
            },
            read_data,
        )?;
        Ok(span.map(|span| self.line_for_span(span)))
    }

    /// Reads without exposing the block-byte count, matching the simpler native overload;
    /// `let line = buffer.read_line_istream_unaccounted(&mut stream, &mut length)?`.
    pub fn read_line_istream_unaccounted<R: Read>(
        &mut self,
        stream: &mut IstreamStream<R>,
        line_length: &mut usize,
    ) -> Result<Option<&[u8]>, IstreamException> {
        let mut ignored_read_data = 0;
        self.read_line_istream(stream, line_length, &mut ignored_read_data)
    }

    /// Reads a C-file-style block, preserving its sticky EOF/error indicators;
    /// `buffer.read_stream_file(&mut file, 4, &mut count)`.
    pub fn read_stream_file<R: Read>(
        &mut self,
        stream: &mut FreadStream<R>,
        len: usize,
        read_len: &mut usize,
    ) -> bool {
        let Some(buffer) = self.read_buffer.get_mut(..len) else {
            *read_len = 0;
            return false;
        };
        let (count, is_good) = stream.read_block(buffer);
        *read_len = count;
        is_good
    }

    /// True when backslash continuation is enabled (false by default); `buffer.is_multiline_mode()`.
    pub fn is_multiline_mode(&self) -> bool {
        self.multiline
    }

    /// True when joined lines keep a space for the continuation; `buffer.to_put_gap_in_multiline()`.
    pub fn to_put_gap_in_multiline(&self) -> bool {
        self.put_gap
    }

    /// Enables or disables multiline mode and the joining gap; `buffer.set_multiline_mode(true, true)`.
    pub fn set_multiline_mode(&mut self, multiline: bool, put_gap: bool) {
        self.multiline = multiline;
        self.put_gap = put_gap;
    }

    fn next_line<F>(&mut self, mut read_block: F, read_data: &mut i64) -> Option<LineSpan>
    where
        F: FnMut(&mut [u8]) -> (usize, bool),
    {
        match self.next_line_fallible(
            |buffer| Ok::<_, std::convert::Infallible>(read_block(buffer)),
            read_data,
        ) {
            Ok(span) => span,
            Err(never) => match never {},
        }
    }

    fn next_line_fallible<F, E>(
        &mut self,
        mut read_block: F,
        read_data: &mut i64,
    ) -> Result<Option<LineSpan>, E>
    where
        F: FnMut(&mut [u8]) -> Result<(usize, bool), E>,
    {
        let mut continued = false;
        loop {
            if self.position == 0 || self.position >= self.last_read {
                let (count, good) = read_block(&mut self.read_buffer)?;
                self.last_read = count;
                if !good {
                    return Ok(None);
                }
                *read_data = count as i64;
                if count == 0 {
                    return Ok(self.take_final_line());
                }
                self.position = 0;
            }
            if let Some(span) = self.scan_block(self.position, &mut continued) {
                return Ok(Some(span));
            }
        }
    }

    fn line_for_span(&self, span: LineSpan) -> &[u8] {
        match span {
            LineSpan::Buffer(start, length) => &self.read_buffer[start..start + length],
            LineSpan::Carried(length) => &self.carried[..length],
        }
    }

    /// At the end of the stream the carried-over text is the last line (no terminator).
    /// Native code returns the vector's `Data()`, which is NULL while the storage was
    /// never allocated, so an empty carry-over that never held a byte ends the stream.
    fn take_final_line(&mut self) -> Option<LineSpan> {
        if !self.use_carried {
            return None;
        }
        self.use_carried = false;
        self.carried_allocated
            .then_some(LineSpan::Carried(self.carried.len()))
    }

    /// Appends `start..end` of the read buffer to the carried text, or starts it.
    fn carry(&mut self, start: usize, end: usize) {
        if !self.use_carried {
            self.carried.clear();
            self.use_carried = true;
        }
        self.carried
            .extend_from_slice(&self.read_buffer[start..end]);
        self.carried_allocated |= end > start;
    }
}

fn read_rust_stream(stream: &mut impl Read, buffer: &mut [u8]) -> (usize, bool) {
    let filled = fill_from(stream, buffer);
    (filled.count, !filled.failed)
}
