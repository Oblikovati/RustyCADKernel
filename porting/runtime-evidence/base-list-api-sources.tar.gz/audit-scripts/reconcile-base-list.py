import collections, gzip, hashlib, json, pathlib, re, subprocess, sys
ROOT = pathlib.Path('/tmp/rustycad-base-api-reconciliation')
MAIN = pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel')
sys.path.insert(0, str(ROOT/'tools'))
from api_crosswalk import cpp_indexes, cpp_candidates, rust_crates, row_rust_candidates
PREFIX = 'rustycad_tkernel::ncollection::'
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read = lambda p: json.load(gzip.open(p,'rt') if str(p).endswith('.gz') else open(p))
cpp = [json.loads(l) for l in gzip.open(ROOT/'porting/api-inventory/occt-declarations.jsonl.gz','rt')]
cpp = [r for r in cpp if r['qualified_name'].startswith('NCollection_BaseList')]
rust_doc = read(MAIN/'porting/api-inventory/rust-api.json.gz')
rust = next(c for c in rust_doc['crates'] if c['crate']=='rustycad_tkernel')['declarations']
raw = read(MAIN/'target/api-proof/rustdoc-map-engines/crates/rustycad_tkernel.json')
ledger = read(MAIN/'porting/api-inventory/api-crosswalk.json.gz')['crosswalk_rows']
by_name,_,_=cpp_indexes(cpp,{cpp[0]['source']:{'TKernel'}})
rust_index=rust_crates(rust_doc)
configs={}
def assign(prefixes, target, group='storage', selector=None, note=None):
    for prefix in prefixes.split():
        matches=[r for r in cpp if r['id'].startswith(prefix)]
        assert len(matches)==1,(prefix,len(matches))
        assert matches[0]['id'] not in configs,prefix
        configs[matches[0]['id']]={'target':target,'group':group,'selector':selector,'note':note}
assign('0e6539b8','BaseListRawIterator::new')
assign('3c157e7f','BaseListRawIterator::<core::default::Default>::default')
assign('1b3652b8','BaseListRawIterator::initialize')
assign('ba50011d','BaseListRawIterator::init')
assign('4c8f01e5 dc204a00','BaseListRawIterator::init_after')
assign('ede67c30','BaseListRawIterator::more')
assign('1ea4eb28','BaseListRawIterator::<core::cmp::PartialEq>::eq')
assign('d07c339f','BaseListRawIterator::is_equal')
assign('afed48a6','BaseListStorage::new')
assign('d9a78c0c','BaseListStorage::extent')
assign('25a12e2a','BaseListStorage::length')
assign('24c345c7','BaseListStorage::size')
assign('34e80c09','BaseListStorage::is_empty')
assign('4de464fe','BaseListStorage::allocator')
assign('5aed45f4 6c0ac637','BaseListStorage::first')
assign('f0c066e7','BaseListStorage::first_mut')
assign('14ed2a68 dd0bd7fd','BaseListStorage::last')
assign('69eaaa83','BaseListStorage::last_mut')
assign('37f858d2 c2d34d4c','BaseListStorage::append_node')
assign('20844ecc b2401f5c','BaseListStorage::append_at')
assign('47f24025 fafc5dd6','BaseListStorage::append_list',note='Disjoint-chain operation; native self-append is represented separately by splice_self, because two aliasing &mut arguments are invalid Rust.')
assign('a363aa22 a7adbcac','BaseListStorage::prepend_node')
assign('96452178 ea4a8aa6','BaseListStorage::prepend_list',note='Disjoint-chain operation; native self-prepend is represented separately by splice_self, because two aliasing &mut arguments are invalid Rust.')
assign('90fc6657 e0da6921','BaseListStorage::clear')
assign('9e89d932 feefdd64','BaseListStorage::remove_first')
assign('1b953515 215d4d35','BaseListStorage::remove')
assign('a2fe2ce5 bb3531a5','BaseListStorage::insert_before_node')
assign('5a78f9f1 d590f154','BaseListStorage::insert_after_node')
assign('2bf6a0f1 bade5992','BaseListStorage::insert_list_before')
assign('1b7cf705 bbdd48f3','BaseListStorage::insert_list_after')
assign('43fdd6cf 59eca276','BaseListStorage::reverse')
assign('b81c5247 e4861484','BaseListStorage::exchange',note='Distinct exclusive borrows cover exchange; native self-exchange is a no-op but has no dedicated BaseListStorage call.')
assign('71cdb894','BaseListStorage','nominal')
assign('83a9cf80','BaseListRawIterator','nominal')
assign('df787a0a c601962e','BaseListBasicIterator','nominal')
assign('9f6e6f0f','BaseListStorage::allocator','field')
assign('917ef0c7','BaseListStorage::first','field')
assign('2f0c0d2e','BaseListStorage::last','field')
assign('8f523a40','BaseListStorage::length','field')
assign('56e89ebe','BaseListRawIterator::current','field')
assign('38eecf92','BaseListRawIterator::previous','field')
assign('0aa00c5c 4574f3bb','BaseListBasicIterator::new','basic','false')
assign('f77b7196 8b82260c','BaseListBasicIterator::new','basic','true')
assign('c002aa6d','BaseListBasicIterator::<core::default::Default>::default','basic')
assign('b1fd43e6','BaseListBasicIterator::<core::clone::Clone>::clone','basic')
assign('18bd65f0 feadf6a4','BaseListBasicIterator::from_mutable','basic','false')
assign('7070446a','BaseListBasicIterator::assign','basic')
assign('b1b3e8c9 79d858ea','BaseListBasicIterator::assign_mutable','basic','false')
assign('111190e9 59cb15a8','BaseListBasicIterator::initialize','basic','false')
assign('15803841 8f7b0bbb','BaseListBasicIterator::initialize','basic','true')
assign('6bba1261 f4a73b89','BaseListBasicIterator::init','basic','false')
assign('faf89012 bd4fe564','BaseListBasicIterator::init','basic','true')
assign('14ca9031','BaseListBasicIterator::more','basic')
assign('381e0a69','BaseListBasicIterator::iterator','basic')
assign('b5b41b0d','BaseListBasicIterator::change_iterator','basic')
assign('3bab747c','BaseListBasicIterator::postfix_increment','basic')
assign('f181ef95','BaseListBasicIterator::prefix_increment','basic')
assign('e6521969','BaseListBasicIterator::next','basic')
assign('eeed45d9 a729563d','BaseListBasicIterator::is_equal','basic')
assign('57bec130 c0455f4f','BaseListBasicIterator::<core::cmp::PartialEq<rustycad_tkernel::ncollection::base_list::basic_iterator::BaseListBasicIterator<N, O>>>::eq','basic')
assign('1c32fdc0 82570f0f','BaseListBasicIterator::<core::cmp::PartialEq<rustycad_tkernel::ncollection::base_list::basic_iterator::BaseListBasicIterator<N, O>>>::eq','basic',note='Rust != uses the standard PartialEq::ne default over eq; this project has no separately compiler-observed ne body. Eq body alone must not count as an operator!= body proof.')
assign('289f658f','BaseListBasicIterator::dereference','basic','both')
assign('5a33d8ca','BaseListBasicIterator::value','basic','both')
assign('aecda403','BaseListBasicIterator::arrow','basic','both')
assign('67b17825 1bff44bb','BaseListBasicIterator::change_value','basic','true')

def stripped_signature(value):
    if isinstance(value,list):return [stripped_signature(v) for v in value]
    if not isinstance(value,dict):return value
    return {k:stripped_signature(v) for k,v in value.items() if k not in ('id','resolved_item_path')}

def source_span(item):
    span=item['span']; begin,end=span['begin'],span['end']
    lines=(ROOT/span['filename']).read_text().splitlines(keepends=True)
    text=''.join(lines[begin[0]-1:end[0]])
    text=text[begin[1]-1:]
    end_excess=len(lines[end[0]-1])-end[1]+1
    if end_excess:text=text[:-end_excess]
    return {'raw_rustdoc_item_id':item['id'],'span':span,'declaration_source_span_sha256':hashlib.sha256(text.encode()).hexdigest()}

catalog={}
def register(candidate):
    key=candidate['declaration_sha256']
    if key in catalog:return key
    assert sha(ROOT/candidate['source_file'])==candidate['source_sha256'],candidate['path']
    entry=dict(candidate); entry['source_matches_audited_revision']=True
    if candidate['kind']=='function':
        signature=stripped_signature(candidate['signature'])
        matches=[i for i in raw['index'].values() if i['name']==candidate['path'].rsplit('::',1)[-1] and i.get('span',{}).get('filename')==candidate['source_file'] and 'function' in i['inner'] and stripped_signature(i['inner']['function'])==signature]
        entry['raw_body_source_matches']=[source_span(i) for i in matches]
        assert matches, candidate['path']
        entry['has_body']=candidate['signature']['has_body']
    catalog[key]=entry
    return key

def specialization(candidate):
    args=candidate.get('impl_context',{}).get('for',{}).get('resolved_path',{}).get('args') or {}
    return [a['const']['expr'] for a in args.get('angle_bracketed',{}).get('args',[]) if 'const' in a]

def native_identity(row):
    if row['kind'] in ('Field','CXXRecord','ClassTemplate','TypeAlias'):return row['qualified_name']
    suffix=re.search(r'\)\s*((?:const\s*)?(?:noexcept)?)$',row['signature']).group(1)
    return row['qualified_name']+'('+','.join(row.get('written_parameter_types',row.get('parameter_types',[])))+')'+(' '+suffix if suffix else '')

rows=[]
for native in cpp:
    row={'native':{k:v for k,v in native.items() if k!='_toolkits'}}
    claims=[c for c in ledger if native['id'] in c.get('cpp_ids',[])]
    row['current_claims']=[{k:c.get(k) for k in ('upstream_id','parity_status','resolution','cpp_status','rust_status','declared_rust_paths')} for c in claims]
    cfg=configs.get(native['id']);row['candidate_binding_keys']=[]
    if not cfg:
        name=native['qualified_name'];kind=native['kind']
        if 'operator new' in name or 'operator delete' in name:status='missing_object_allocation_surface'
        elif kind=='CXXDestructor':status='language_drop_glue_without_exact_body_proof'
        elif kind=='TypeAlias':status='missing_native_iterator_alias_contract'
        elif kind in ('TemplateTypeParm','NonTypeTemplateParm'):status='template_parameter_not_separate_api_candidate'
        else:raise AssertionError((native['id'],name,kind))
        row['status']=status;rows.append(row);continue
    kind={'field':'struct_field','nominal':'struct'}.get(cfg['group'],'function')
    candidates=[c for c in rust if c['path']==PREFIX+cfg['target'] and c['kind']==kind]
    selection=cfg['selector']
    if selection and selection!='both':candidates=[c for c in candidates if selection in specialization(c)]
    assert len(candidates)==(2 if selection=='both' else 1),(native['id'],cfg,len(candidates))
    row['candidate_binding_keys']=[register(c) for c in candidates]
    row['scope']='partial_domain';row['evidence_group']=cfg['group']
    row['const_specialization_rule']='C++ IsConstant == !Rust MUTABLE; concrete true/false selections are retained separately.' if cfg['group']=='basic' else None
    row['review_note']=cfg['note']
    row['status']='partial_body_binding' if kind=='function' else 'partial_nominal_or_field_binding'
    if selection=='both':row['status']='partial_conditional_body_binding_requires_impl_selector'
    if 'operator!=' in native['qualified_name']:row['status']='trait_default_operator_without_project_body_proof'
    if claims:
        row['claim_correction']='replace_typed_facade_with_base_surface_and_downgrade_to_partial' if kind=='function' else 'review_existing_claim'
    else:row['claim_correction']='add_partial_evidence_without_implemented_credit'
    if kind=='function' and native['api_visible'] and row['status']=='partial_body_binding':
        target=PREFIX+cfg['target']; identity=claims[0]['upstream_id'] if claims else native_identity(native)
        proposed={'upstream_id':identity,'toolkit':'TKernel','source':native['source'],'rust_item':target,'rust_items':[target],'rust_kind':'function','status':'partial','notes':'Exact BaseList declaration reconciliation; valid raw-node/borrow domain only, allocator/ABI/noexcept/configuration closure remains open. See porting/audits/base-list-api-reconciliation.json and its exact-ID matrix.'}
        cpp_status, cpp_matches=cpp_candidates(identity,'TKernel',by_name)
        rust_status, rust_matches=row_rust_candidates(proposed,rust_index)
        row['proposal_resolution']={'cpp_status':cpp_status,'cpp_ids':[c['id'] for c in cpp_matches],'rust_status':rust_status,'rust_declaration_keys':[c['declaration_sha256'] for c in rust_matches]}
        if cpp_status=='unique' and rust_status=='unique' and cpp_matches[0]['id']==native['id']:
            row['proposed_row']=proposed
        else:row['claim_correction']='requires_selector_support_before_ledger_change'
    rows.append(row)

out=ROOT/'porting/audits'
def jsonl(name, entries):
    path=out/name
    path.write_text(''.join(json.dumps(e,sort_keys=True,separators=(',',':'))+'\n' for e in entries))
    return {'path':str(path.relative_to(ROOT)),'sha256':sha(path),'rows':len(entries)}
artifacts={'matrix':jsonl('base-list-api-correction-matrix.jsonl',rows),'rust_body_catalog':jsonl('base-list-api-rust-bodies.jsonl',list(catalog.values()))}
summary={'schema':'rustycad.read-only-binding-reconciliation.v1','source_revision':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'native_revision':'3d097a0328e71b826377d4814ab05ec3c3d23871','scope':'Every captured declaration owned by NCollection_BaseList, including both Iterator classes, protected methods, fields, allocation macros, aliases, and template-owned non-candidates. No BaseSequence/BaseMap method conclusions are claimed.','rust_capture_revision':rust_doc['capture_workspace_revision'],'artifacts':artifacts,'counts':{'captured_native_records':len(rows),'api_visible_candidates':sum(r['native']['api_visible'] for r in rows),'non_candidate_records':sum(not r['native']['api_visible'] for r in rows),'existing_claimed_candidates':sum(bool(r['current_claims']) for r in rows),'unclaimed_api_candidates':sum(r['native']['api_visible'] and not r['current_claims'] for r in rows),'exact_rust_binding_records':len(catalog),'safe_partial_proposals':sum('proposed_row' in r for r in rows),'proposal_replacements':sum('proposed_row' in r and bool(r['current_claims']) for r in rows),'proposal_additions':sum('proposed_row' in r and not r['current_claims'] for r in rows),'status_counts':dict(collections.Counter(r['status'] for r in rows))},'input_sha256':{p:sha(MAIN/p) for p in ['porting/api-inventory/occt-declarations.jsonl.gz','porting/api-inventory/rust-api.json.gz','porting/api-inventory/api-crosswalk.json.gz','porting/parity.json','target/api-proof/rustdoc-map-engines/crates/rustycad_tkernel.json']},'native_header':{'path':cpp[0]['source'],'sha256':sha(MAIN.parent/'OCCT'/cpp[0]['source'])},'published_api_inventory_credit_added':0,'original_test_mapping_credit_added':0,'api_parity_complete':False}
(out/'base-list-api-reconciliation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['counts'],indent=2))
