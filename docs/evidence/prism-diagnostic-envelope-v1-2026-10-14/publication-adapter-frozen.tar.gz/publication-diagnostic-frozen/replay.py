import ast, hashlib, json, os, re, subprocess
from pathlib import Path
root = Path.cwd()
out = root / 'target/publication-diagnostic-frozen'
binary = root / 'target/debug/deps/rustycad_tkbo-3743221922cb8a91'
specs = [
 ('publication-diagnostic', 'sketch_region_prism::owned_request::publication_diagnostic_tests::replay_tests::full_publication_diagnostic_process_receipt', 'env', 'MARTENSITE_PUBLICATION_DIAGNOSTIC_RECEIPT'),
 ('typed-preparation', 'sketch_region_prism::owned_request::diagnostic_codec_tests::full_typed_refusal_process_receipt', 'env', 'MARTENSITE_TYPED_DIAGNOSTIC_RECEIPT'),
 ('publication-v1', 'sketch_region_prism::publication::replay_tests::publication_process_replay', 'hex', 'named-prism-publication-v1='),
 ('publication-v2', 'sketch_region_prism::publication::operation_v2_tests::v2_publication_process_replay', 'hex', 'named-prism-publication-v2='),
 ('semantic-map', 'sketch_region_prism::owned_request::names::body_map::tests::semantic_map_replay_probe', 'list', 'SEMANTIC_MAP_REPLAY='),
 ('owned-request', 'sketch_region_prism::owned_request::request_replay::operand_tests::owned_request_process_receipt', 'hex', 'owned-prism-request-v1:'),
]
expected = {
 'typed-preparation': 'a27a9465306496b6d8fa5c732e80bc39e7a2976aa6a074ae67612bddfad196a8',
 'publication-v1': 'accba93e30c455d9f888a96c5b70f684a1dbacbbf3afec9076de3544c7a13107',
 'publication-v2': 'e68be877959b90ae723b2386ae83db09e0a169149571433d5f3e01fe1be7d878',
 'semantic-map': 'ffbdcd9461a1acb2349d514610a6f24b6cdadd03b460bf9394a65240b88247ff',
}
manifest = {'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'commands': [], 'replays': {}}
for name, test, form, marker in specs:
    captures = []
    for repetition in range(2):
        destination = out / f'{name}-{repetition}.bin'
        env = dict(os.environ)
        if form == 'env':
            env[marker] = str(destination)
        command = [str(binary), '--exact', test, '--nocapture', '--test-threads=1']
        result = subprocess.run(command, env=env, capture_output=True, check=True)
        log = result.stdout + result.stderr
        (out / f'{name}-{repetition}.log').write_bytes(log)
        if form != 'env':
            pattern = re.escape(marker) + (r'([0-9a-f]+)' if form == 'hex' else r'(\[[^\n]*\])')
            payload = re.search(pattern, log.decode()).group(1)
            capture = bytes.fromhex(payload) if form == 'hex' else bytes(ast.literal_eval(payload))
            destination.write_bytes(capture)
        capture = destination.read_bytes()
        captures.append(capture)
        manifest['commands'].append({'argv': command, 'output_env': {marker: str(destination)} if form == 'env' else {}})
    assert captures[0] == captures[1], name
    digest = hashlib.sha256(captures[0]).hexdigest()
    if name in expected:
        assert digest == expected[name], (name, digest)
    manifest['replays'][name] = {'bytes': len(captures[0]), 'sha256': digest, 'two_processes_equal': True, 'historical_expected_sha256': expected.get(name)}
(out / 'replays.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['replays'], indent=2))
