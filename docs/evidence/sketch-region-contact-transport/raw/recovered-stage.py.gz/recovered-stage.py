from pathlib import Path
import sys, json, subprocess, hashlib, tarfile
root=Path.cwd(); sys.path.insert(0,str(root/'tools'))
from release_inventory import SystemCommands, release_inventory
from release_packages import package_test_support
from release_archives import stage_workspace
commands=SystemCommands(); crates=release_inventory(root,commands)
assert not commands.run(['git','status','--porcelain'],root).strip()
commands.run(['cargo','package','--workspace','--locked','--no-verify','--exclude-lockfile'],root)
package_test_support(root,commands)
stage=root/'target/contact-transport/extracted'; stage_workspace(root/'target/package',stage,crates,root/'Cargo.lock')
head=commands.run(['git','rev-parse','HEAD'],root).strip(); archives={}; vcs={}; source_members={}
for crate in crates:
    archive=root/'target/package'/crate.archive
    archives[crate.archive]=hashlib.sha256(archive.read_bytes()).hexdigest()
    with tarfile.open(archive) as stream:
        for member in stream.getmembers():
            if not member.isfile(): continue
            relative=Path(member.name).relative_to(Path(member.name).parts[0]); blob=stream.extractfile(member).read()
            if str(relative)=='.cargo_vcs_info.json': vcs[crate.name]=json.loads(blob)
            if relative.suffix!='.rs': continue
            source=root/crate.directory/relative
            assert source.read_bytes()==blob,source
            source_members[str(source.relative_to(root))]=hashlib.sha256(blob).hexdigest()
assert all(info['git']['sha1']==head and not info['git'].get('dirty',False) for info in vcs.values())
receipt={'head':head,'archives':archives,'vcs':vcs,'rust_members':source_members,'stage':str(stage)}
(root/'target/contact-transport/recovered-archive-source.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'head':head,'archives':len(archives),'matching_rust_members':len(source_members),'stage':str(stage)}))
