import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd(); base=root/'docs/evidence/prism-exact-tolerance-v2-2026-10-14';out=root/'docs/evidence/prism-exact-tolerance-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def hashes():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=hashes();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
verified=0
for name in ('final','reconciliation'):
 folder=base/name;manifest=json.loads((folder/'artifact-hashes.json').read_text())
 for p,h in manifest.items():assert sha((folder/p).read_bytes())==h,p
 verified+=len(manifest)
 assert gzip.decompress((folder/'source-before.json.gz').read_bytes())==gzip.decompress((folder/'source-after.json.gz').read_bytes())
for p,h in json.loads((base/'reconciliation/candidate-file-hashes.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
selectors=[('exact','sketch_region_prism::exact_tolerance::joined_replay_tests::exact_tolerance_bytes_replay_across_threads_and_operations','prism-exact-tolerance-v2:'),('frozen-v1','sketch_region_prism::frozen::replay_tests::frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1:'),('inspection-v1','sketch_region_prism::tolerance_inspection::replay_tests::tolerance_arithmetic_replays_across_repeated_operations_and_independent_workers','prism-tolerance-arithmetic-v1:')]
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
def decode(payload,prefix):
 lines=re.findall(re.escape(prefix)+r'([0-9a-f]+)',payload.decode());assert len(lines)==1
 return bytes.fromhex(lines[0])
for label,selector,prefix in selectors:
 expected=decode(gzip.decompress((base/'final'/f'{label}-process-1.log.gz').read_bytes()),prefix)
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',selector,'--','--exact','--nocapture']
  p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'integrated-{label}-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  assert decode(p.stdout,prefix)==expected
  (out/f'integrated-{label}-{i}.bin.gz').write_bytes(gzip.compress(expected,mtime=0))
 row={'kind':label,'bytes':len(expected),'sha256':sha(expected),'two_processes_equal_to_candidate':True};replays.append(row);print(json.dumps(row),flush=True)
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkmath','-p','rustycad-tkbrep','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=lambda payload:set(re.findall(r'^test (.+?) \.\.\. ok$',payload.decode(),re.M))
candidate=names(gzip.decompress((base/'final/tests.log.gz').read_bytes()));actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual,sorted(candidate-actual)
assert before==hashes()
receipt={'integration_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_artifacts_verified':verified,'both_candidate_bookends_identical':True,'source_unchanged_since_matrix':True,'candidate_file_hashes_verified':38,'replays':replays,'candidate_test_names':len(candidate),'integrated_test_names':len(actual),'missing_test_names':sorted(candidate-actual),'warning_denied_docs_exit':p.returncode,'tsan':'incomplete; instrumented control crashed before main, tolerance suite unbuilt/unexecuted'}
(out/'integrated-supplement.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('supplementary checks passed',flush=True)
