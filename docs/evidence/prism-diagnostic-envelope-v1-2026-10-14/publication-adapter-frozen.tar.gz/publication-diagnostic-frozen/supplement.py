import hashlib, json, os, subprocess
from pathlib import Path
root = Path.cwd()
out = root / 'target/publication-diagnostic-frozen'
env = dict(os.environ)
env['PATH'] = '/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:' + env['PATH']
env['CARGO_BUILD_JOBS'] = '2'
commands = [
 ('doctests', ['cargo','test','-p','rustycad-tkbo','--doc','--all-features']),
 ('clippy', ['cargo','clippy','-p','rustycad-tkbo','--all-targets','--all-features','--','-D','warnings']),
 ('fmt', ['cargo','fmt','--all','--','--check']),
 ('rendered-docs', ['cargo','doc','-p','rustycad-tkbo','--no-deps','--all-features']),
 ('replay', ['python3',str(out/'replay.py')]),
]
receipts = []
for name, command in commands:
    with (out/f'{name}.log').open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipts.append({'gate': name, 'argv': command, 'exit_code': result.returncode})
    (out/'supplement.json').write_text(json.dumps(receipts, indent=2)+'\n')
    print(json.dumps(receipts[-1]), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
files = subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
selected = [f for f in files if f and (f.endswith(('.rs','.toml','.lock')) or Path(f).name in ['rust-toolchain','rust-toolchain.toml'])]
after = {f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in selected}
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert after == json.loads((out/'source-before.json').read_text())
context = json.loads((out/'context.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip() == context['revision']
(out/'status-after.txt').write_bytes(subprocess.check_output(['git','status','--porcelain']))
print(json.dumps({'source_unchanged':True,'files':len(after)}),flush=True)
