import os,sys,subprocess,json,hashlib,platform,time
from pathlib import Path
root=Path.cwd();out=root/'target/gui-surface-outcomes/final';sys.path.insert(0,str(root/'tools'))
from vulkan_source_receipt import source_hashes
before=source_hashes();(out/'supplement-source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
view=out/'checker-input';view.mkdir(exist_ok=True)
for capture in [*out.glob('*-rapid-*'),out/'amd-acceptance',out/'lavapipe-acceptance']:
    if capture.is_dir(): (view/capture.name).symlink_to(capture.resolve(),target_is_directory=True)
args=['python3',str(root/'docs/evidence/gui-framebuffer-restart-2026-10-14/check_framebuffers.py'),str(view)]
with (out/'exact-framebuffers-corrected-input.log').open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
receipt={'checker_command':args,'checker_exit':r.returncode,'original_checker_failure':'glob matched sibling .log files before any pixel reads; preserved in exact-framebuffers.log','runs':[]}
env=os.environ.copy();layer=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr');env.update(VK_LAYER_PATH=str(layer/'share/vulkan/explicit_layer.d'),LD_LIBRARY_PATH=str(layer/'lib/x86_64-linux-gnu'))
if r.returncode==0:
    for driver,icd in [('amd','radeon_icd.json'),('lavapipe','lvp_icd.json')]:
        env.update(VK_DRIVER_FILES='/usr/share/vulkan/icd.d/'+icd,VK_ICD_FILENAMES='/usr/share/vulkan/icd.d/'+icd)
        for policy in ['legacy','checked']:
            name=driver+'-performance-'+policy
            args=['/usr/bin/time','-v','-o',str(out/(name+'.time')),str(root/'target/debug/examples/native_gui_performance'),'20','100',policy]
            record={'name':name,'command':args,'load_before':os.getloadavg(),'environment':{key:env.get(key) for key in ['DISPLAY','VK_LAYER_PATH','LD_LIBRARY_PATH','VK_DRIVER_FILES','VK_ICD_FILENAMES']}}
            print(json.dumps({'starting':name}),flush=True);start=time.monotonic()
            with (out/(name+'.log')).open('w') as log:
                try:record['exit']=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
                except subprocess.TimeoutExpired:record['timeout']=600
            record['elapsed_seconds']=time.monotonic()-start;record['load_after']=os.getloadavg();receipt['runs'].append(record);print(json.dumps(record),flush=True)
after=source_hashes();(out/'supplement-source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n');receipt['source_bookends_equal']=before==after
binary_before=json.loads((out/'native-binaries-before.json').read_text());receipt['native_binaries_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in binary_before.items())
(out/'supplement-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
