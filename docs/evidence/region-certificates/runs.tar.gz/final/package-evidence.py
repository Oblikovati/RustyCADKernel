from pathlib import Path
import subprocess,json,hashlib,re,shutil,tarfile
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-region-certificates')
final=Path('/tmp/martensite-region-certificates-final')
old=Path('/tmp/martensite-region-certificates-evidence')
out=repo/'docs/evidence/region-certificates'
commands=json.loads((final/'commands.json').read_text())
assert len(commands)==8 and all(row['exit_code']==0 and row['source_unchanged'] for row in commands)
before=json.loads((final/'source-before.json').read_text());after=json.loads((final/'source-after.json').read_text());assert before==after
for relative,digest in before.items(): assert hashlib.sha256((repo/relative).read_bytes()).hexdigest()==digest,relative
bookends=json.loads((final/'source-bookends.json').read_text());assert all(row['before']==before==row['after'] for row in bookends.values())
extraction=json.loads((final/'extraction-equality.json').read_text())
for row in extraction:
 relative=row['file']; extracted=final/'extracted/src'/relative.removeprefix('crates/tkmath/src/')
 assert extracted.read_bytes()==(repo/relative).read_bytes(),relative
 assert hashlib.sha256(extracted.read_bytes()).hexdigest()==row['sha256'],relative
corpus_hashes={}
for relative in ['tests/support/metric_residual_cases.rs','tests/fixtures/certified_bezier_pairs/native.tsv']:
    captured=final/'extracted'/relative
    assert captured.read_bytes()==(repo/'crates/tkmath'/relative).read_bytes(),relative
    corpus_hashes[relative]=hashlib.sha256(captured.read_bytes()).hexdigest()
(final/'extraction-corpus-equality.json').write_text(json.dumps(corpus_hashes,indent=2)+'\n')
first=(final/'process-first.json').read_bytes();assert first==(final/'process-second.json').read_bytes()
def count(label):
 text=(final/'logs'/f'{label}.log').read_text();assert not re.search(r'test result: FAILED',text)
 return sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',text)))
counts={label:count(label) for label in ['all-targets','doctests','extracted-tests']}
assert counts=={'all-targets':4162,'doctests':84,'extracted-tests':138},counts
out.mkdir(parents=True,exist_ok=True)
readme=(final/'README.draft.md').read_text().replace('FULL_COUNT','4,162').replace('DOC_COUNT','84').replace('EXTRACTED_COUNT','138').replace('all changed files are below','all changed Rust files are below')
(out/'README.md').write_text(readme)
archive_stage=Path('/tmp/martensite-region-certificates-archive');archive_stage.mkdir(exist_ok=True)
shutil.copy2(__file__,final/'package-evidence.py')
shutil.copytree(final,archive_stage/'final',ignore=shutil.ignore_patterns('target','README.draft.md'),dirs_exist_ok=True)
prior=archive_stage/'pre-correction';prior.mkdir(exist_ok=True)
for name in ['verify.py','commands.json','source-before.json','interrupted.json']:
 if (old/name).exists():shutil.copy2(old/name,prior/name)
shutil.copytree(old/'logs',prior/'logs',dirs_exist_ok=True)
attempts=archive_stage/'attempts';attempts.mkdir(exist_ok=True)
for path in Path('/tmp').glob('martensite-region-*.log'):shutil.copy2(path,attempts/path.name)
with tarfile.open(out/'runs.tar.gz','w:gz',compresslevel=9) as archive:
 for path in sorted(archive_stage.iterdir()):archive.add(path,arcname=path.name)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
base=subprocess.check_output(['git','rev-parse','b6e39c42a'],cwd=repo,text=True).strip()
rustc=subprocess.check_output(['/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc','-Vv'],text=True)
receipt={
 'operation':'martensite.source-bound-region-certificate','behavior_version':1,
 'source_revision':revision,'initial_source_revision':subprocess.check_output(['git','rev-parse','fbeffb302'],cwd=repo,text=True).strip(),'base_revision':base,
 'branch':'extension/martensite-region-certificates','decision':'docs/adr/0014-owned-analytic-sketch-regions.md',
 'platform':{'uname':subprocess.check_output(['uname','-a'],text=True).strip(),'rustc':rustc},
 'options':{'seed':[1,1],'extrusion':[0,0,2],'spatial_limit':1e-8,'parameter_limit':1e-8,'contact_world_limit':1e-8,'fresh_closure_certificate_limit':0.0,'root_options':{'version':1,'max_width':0.001,'max_degree':32,'max_bisections':4096},'fresh_point_domain':'exact singleton t=0, paired u=1 established separately','point_completed_bisections':0},
 'outcome':{'body':'incomplete','candidate_obligations_discharged_conditionally':['Construction','SharedIncidenceReuse','CandidateHistoryCoverage','SearchCompleteness'],'selected_winding':1,'complementary_winding':-1,'orientation':'Forward','boundary_reversed':False,'achieved_error':'unknown; only individual certified zero residuals recorded','publication':'not provided'},
 'oracles':['independent closed form x=12t(1-t)^2, y=12t^2(1-t), strictly increasing ratio y/x=t/(1-t)','positive rational denominator and identical ratio for weights [1,2,2,1]','exact source/copy coefficient identities and current zero closure point residuals','topology/history/multiplicity invariants','generated scaled/reversed/degenerate/mutation examples','unchanged native fixtures: historical replay only'],
 'tests':{'focused_region':40,**counts,'worker_count':8,'fresh_rebuilds_per_worker':4,'process_bytes_equal':True,'portable_receipt':json.loads(first),'extracted_source_files':len(extraction),'audited_functions':151,'region_module_files':20},
 'commands':commands,'source_bookends_all_equal':True,'source_hash_manifest':{'archive_path':'final/source-before.json','file_count':len(before),'sha256':hashlib.sha256((final/'source-before.json').read_bytes()).hexdigest()},
 'process_receipt_sha256':hashlib.sha256(first).hexdigest(),'retained_corpus_sha256':corpus_hashes,
 'preserved_failures':{'initial_context_expectation':{'passed':10,'failed':8},'review_first':{'passed':31,'failed':1},'review_isolated':{'passed':29,'failed':3},'old_frozen_pipeline':'interrupted during compilation before edits; diagnostic-only','other':'initial test-builder compile and large-error Clippy failures retained'},
 'exclusions':['No healthy region or solid publication','Full ordered body/self-intersection/tolerance validation incomplete','No area/volume acceptance or previous-release accepted-workload benchmark','No application acceptance','Ordinary-host ThreadSanitizer acceptance remains incomplete; no new sanitizer run in this slice','No OCCT execution or new native fixture capture','No host instrumentation masking, disabling or exclusion','No global mutable algorithm state or unsafe trait implementation added'],
 'retention':'runs.tar.gz contains final commands/logs/hash bookends, standalone extracted sources/lock/support/historical fixture, all initial attempt logs and interrupted old-run record; build artifacts excluded',
 'artifact_sha256':{name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['README.md','runs.tar.gz']},
}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256((out/name).read_bytes()).hexdigest()}  {name}\n' for name in ['README.md','receipt.json','runs.tar.gz']))
print(json.dumps({'revision':revision,'counts':counts,'archive_bytes':(out/'runs.tar.gz').stat().st_size,'source_files':len(before)}))
