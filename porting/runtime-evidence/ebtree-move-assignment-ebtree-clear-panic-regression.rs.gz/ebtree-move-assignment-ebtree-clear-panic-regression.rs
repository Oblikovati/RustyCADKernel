use rustycad_tkernel::ncollection::{BaseAllocator, BoundingVolume, EBTree, HashKey};
use std::{cell::Cell,rc::Rc};
#[derive(Clone,Default)] struct Object { value:i32, reject:Rc<Cell<bool>> }
impl PartialEq for Object {fn eq(&self,other:&Self)->bool {self.value==other.value}}
impl std::fmt::Debug for Object {fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result {self.value.fmt(f)}}
impl HashKey for Object {fn occt_hash(&self)->usize {self.value as usize}}
impl Drop for Object {fn drop(&mut self) {if self.reject.replace(false) {panic!("intentional first key destructor failure");}}}
#[derive(Clone,Default)] struct Bounds;
impl BoundingVolume for Bounds {
 fn add(&mut self,_:&Self) {}
 fn is_out(&self,_:&Self)->bool {false}
 fn square_extent(&self)->f64 {0.0}
}
fn main() {
 let allocator=BaseAllocator::incremental(1024);
 let rejected=Rc::new(Cell::new(false));
 let mut tree=EBTree::with_allocator(allocator.clone());
 for value in 1..=3 {tree.add(Object {value,reject:rejected.clone()},Bounds);}
 rejected.set(true);
 let failed=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||tree.clear())).is_err();
 let query=Object {value:1,reject:Rc::new(Cell::new(false))};
 println!("clear_map_panic failed={} tree_empty={} contains1={} live_nodes={}",failed,tree.is_empty(),tree.contains(&query),allocator.reset(true).is_err());
 let repaired=std::env::args().nth(1).unwrap()=="candidate";
 assert!(failed && tree.is_empty()==repaired && !tree.contains(&query));
 assert_eq!(allocator.reset(true).is_err(),!repaired);
 drop(tree);allocator.reset(true).unwrap();
}
