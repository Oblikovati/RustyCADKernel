# Remaining actual single-boundary owned-refusal families

Read-only inventory at source 9699a8adf. This is a future-work inventory, not
implemented coverage. The current bridge completes only ScopedPrismCause::Projection.

## Preparation

`owned_request/diagnostics.rs::OwnedPreparationCause` retains Admission, Native,
Census, Contact, PrismUnavailable, StageUnavailable, MissingLocalState, Callback.
The existing early diagnostic adapter supports direct operands but explicitly
refuses to declare complete projection of meaningful retained/nested owners.

- `sketch_region_certification/outcome.rs::CensusCause` includes Input, Policy,
  Capture, Incomplete, SourceCancelled and Cancelled. The latter two retain a
  completed BoundaryCensus, not just a work count. Partial evidence can contain
  geometry/context-bearing endpoint observations.
- `sketch_region_contact_transport/types.rs::ContactTransportStop` retains Policy
  or Cancelled plus the completed PairedContactTransaction. Preserve the native
  phase, offending field/value, and meaningful completed evidence.
- `region_certificate/types.rs::RegionPrismUnavailable` contains the full requested
  PrismRequest, RegionCertificateCause and missing-certificate rows. ClosurePoint
  and Capture causes require their exact typed payload; Mapped keeps exact Failure.
- `PreparationDiagnosticView::outer_entry_phase/outer_retained_stages` describe
  only outer owners. Neither is a complete census of nested diagnostic payload.

## Resolution

`owned_request/resolver/types.rs::ResolutionCause` has eight direct owned-value
families: Native, EndpointParameter, PlanVersion, PlanMismatch, NativeParameter,
Names, Missing, Count. Preserve both full plans, all scalar bits/expected bounds,
name operands and exact native provenance. Three families nest existing causes:
Binding, Prism, History.

`ScopedPrismCause::Resolution` already carries the actual prepared reference and
exact cause. `prepared.diagnostic_context()` provides its actual request and
optional plan; a detached context/cause pair is unnecessary. No generic child
class or internal resolver phase header is stored. An additive wrapper must label
any new classification policy and preserve the separate actual outer callback.

Reuse `frozen/owned_refusal/binding.rs` rather than duplicate it: its bounded
projector covers Region/Chart/Body/Cancelled/Classification. BodySelection,
BodyShape and unsupported candidate branches retain the original cause. Its
`PrismCause` projector preserves Mapped native phase, ValidationRejected and
InvalidRequest operands. MissingCopy/CyclicBodyContext are still shape-bearing.

`PrismHistoryCause` is distinct from the borrowed `PrismHistoryFailure` below.
It includes AtUse, Legacy, Lineage, LineageCancelled, Count, Missing, Changed,
ParentsMismatch, Bounds, ContextRead, Frozen, Native, Geometry and
UnsupportedDiagnostic. Recursion, exact parent arrays, bounded work and full use
ancestry must survive; an unsupported summary cannot become a complete projection.

## Publication

`diagnostic_envelope/publication` already consumes only the sealed actual
invocation packet. V2 retains complete child phase/class/cause beneath callback
failure; V1 missing child headers remain an explicit gap. Keep that distinction.

- Join: closure query/region, embedding originals and numerical proof failures,
  capture/link/binding and unknown entity correspondence remain bounded gaps.
- Validation: `frozen/ordered_validation/errors.rs` retains operation/options,
  checkpoint, class, ordered trace, full source bytes, and typed topology,
  orientation, conformance, SI, tolerance and callback causes. These are largely
  owned, but need complete typed operand serialization and identity qualification.
- Measures: `frozen/joined_measures/error.rs` retains affected authored uses,
  requested options, class, exact extrusion bits and arithmetic failures.
  `measurements/complete/operand_errors.rs::BoundPrismMeasureFailure::Side`
  contains source/output PartitionOccurrenceIdentity despite being owned. Bind
  these to actual semantic keys or explicit unbound context; retain the precise
  PolynomialSideError, requested/effective limits, work and achieved bounds.
- History: `frozen/complete_history/result.rs::PrismHistoryFailure` retains owned
  finding plus optional Join, borrowed PartitionReadFailure,
  ArrangementCompletion or CandidateCause local diagnostic. This is the main
  borrowed-lifetime blocker. `HistoricalLegacyCause` deliberately contains some
  outer variants/counts instead of full nested evidence; do not treat those as
  lossless codec input or silently drop the local original.

## Completed transport boundary in ADR0056

ProjectionRefusal is lifetime-free: its actual ResolvedPrismPublication owns full
request, dictionary and immutable accepted publication. The five typed failure
families (Callback, Names, Reservations, Body, Volume) now move unchanged.
Earlier successful pure projection temporaries were dropped by the producer.
Retained coverage is the accepted publication only, and never outer completion.
