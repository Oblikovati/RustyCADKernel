from pathlib import Path
import hashlib,json,subprocess,tarfile,re,os
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-cap-measures')
stage=Path('/tmp/martensite-prism-cap-final')
prior=Path('/tmp/martensite-cap-measures-evidence')
out=repo/'docs/evidence/prism-cap-measures';out.mkdir(parents=True,exist_ok=True)
source=(stage/'revision.txt').read_text().strip()
expected=json.loads((stage/'source-before.json').read_text())
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in expected.items())
commands=json.loads((stage/'commands.json').read_text())
assert len(commands)==10 and all(c['exit_code']==0 and c['source_unchanged'] for c in commands)
counts={p.stem:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',p.read_text()))) for p in (stage/'logs').glob('*.log')}
assert counts['all-targets']==4318 and counts['doctests']==88 and counts['extracted-tests']==216
assert (stage/'process-first.json').read_bytes()==(stage/'process-second.json').read_bytes()
ts=json.loads((stage/'tsan.json').read_text())
status='Ordinary-host ThreadSanitizer acceptance remains incomplete. The isolated\ninstrumented standalone build succeeded with nightly-2026-09-25 and build-std,\nbut the test process exited with SIGSEGV before any test began (Cargo exit 101).\nThe log establishes neither a passing test nor a race conclusion. Source hashes\nmatch before/after; exact compiler, command and environment changes are retained.'
readme=(stage/'README.draft.md').read_text()
for old,new in {'SOURCE_REVISION':source,'FULL_COUNT':'4,318','DOC_COUNT':'88','EXTRACTED_COUNT':'216','TSAN_STATUS':status,'and28':'and 28'}.items():readme=readme.replace(old,new)
(out/'README.md').write_text(readme)
env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
platform={'uname':subprocess.check_output(['uname','-a'],text=True).strip(),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'cargo':subprocess.check_output(['cargo','-V'],env=env,text=True).strip(),'jobs':2}
corpus=[]
for p in sorted((stage/'extracted/tests').rglob('*')):
 if p.is_file():corpus.append({'path':str(p.relative_to(stage)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':str((Path('crates/tkmath')/p.relative_to(stage/'extracted'))),'equal_source':p.read_bytes()==(repo/'crates/tkmath'/p.relative_to(stage/'extracted')).read_bytes()})
assert all(r['equal_source'] for r in corpus)
(stage/'corpus-equality.json').write_text(json.dumps(corpus,indent=2)+'\n')
receipt={'operation':'martensite.source-bound-prism-cap-measurements','behavior_version':1,'source_revision':source,'frozen_base':'a42ab0646','upstream_evidence_only_amendment':'42740916a; preserve corrected regularity candidate count 18 during integration','source_commits':subprocess.check_output(['git','log','--format=%H %s','a42ab0646..HEAD'],cwd=repo,text=True).splitlines(),'dependency_provenance':{'sqrt_original':'19d6c14fd','sqrt_initial_cherry_pick':'56313554b; dropped as equivalent during rebase onto integrated side main8980e4929','support_extraction_original':'14b0198db','chart_access_original':['6ab9bb8e6','756793d39'],'chart_access_rebased':['f57d069bb','5afe541f7']},'platform':platform,'policy':{'behavior_version':1,'max_degree':16,'max_curves':64,'default_absolute_error_limit':1e-12,'cap_units':'world coordinate squared','sweep_units':'world coordinate cubed','requested_effective':'unchanged; no clamp or widening','domain':'polynomial full native [0,1], explicit occurrence reversal; Some(weights) unsupported'},'oracle_kinds':['independent exact Green antiderivative I=12/5','Jacobian QQ augmented Gram determinant S=338','exact binary64 nearly-unit Gram determinant greater than one','independently pinned adjacent binary64 bits','source/history/ownership invariants','generated degenerates','unchanged owned Jacobian baseline'], 'checks':commands,'test_counts':counts,'source_bookends_equal':True,'portable_scalar_process_receipts_equal':True,'thread_stress':{'plane':'8 workers x 32 owned reports','composition':'8 workers x 4 independent rebuilds vs serial portable receipt'},'audit':{'files':20,'functions':145,'function_physical_lines':'4..20','file_lines':'<500'},'sanitizer':{'status':'incomplete-before-test-output','details':ts},'retained_extraction':{'source_file_count':len(json.loads((stage/'extraction-equality.json').read_text())),'corpus':corpus,'historical_native_fixture':'unchanged replay only; no OCCT execution or new capture'},'completion':{'conditional_cap_measures':'complete for admitted current binding','conditional_signed_sweep_measure':'complete for admitted current binding','side_area':'pending binding','total_area':'pending composition','valid_body':'incomplete','publication':'not provided'},'exclusions':['ordinary-host sanitizer acceptance incomplete','no operation achieved-error/body validity/tolerance or self-intersection discharge','no native OCCT oracle or new native fixtures','no faceted or sampled acceptance','no application acceptance','no previous-release accepted-workload benchmark','no immutable publication of legacy failure diagnostics','operation-local pointer identities are not stable document names','no concurrent writes to legacy shape aliases authorized'],'earlier_attempts':'retained diagnostic-only, not final frozen acceptance'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with tarfile.open(out/'runs.tar.gz','w:gz') as archive:
 for folder,prefix in [(stage,'final'),(prior,'initial')]:
  for path in sorted(folder.rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(folder)
   if any(part in {'target','tsan-target'} for part in relative.parts) or path.name=='README.draft.md':continue
   archive.add(path,arcname=str(Path(prefix)/relative),recursive=False)
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in ['README.md','receipt.json','runs.tar.gz']))
print(json.dumps({'source':source,'test_counts':counts,'archive_bytes':(out/'runs.tar.gz').stat().st_size,'extracted_sources':receipt['retained_extraction']['source_file_count']}))
