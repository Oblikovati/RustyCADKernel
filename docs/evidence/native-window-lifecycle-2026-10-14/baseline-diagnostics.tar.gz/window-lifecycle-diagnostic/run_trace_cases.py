from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();dest=root/'target/window-lifecycle-diagnostic';env=os.environ.copy();env.update(DISPLAY=':1',MARTENSITE_TRACE_WINDOW_CALLS='1',VK_LAYER_PATH='/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr/share/vulkan/explicit_layer.d',LD_LIBRARY_PATH='/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr/lib/x86_64-linux-gnu')
binary=root/'target/debug/examples/native_view_lifecycle_probe';runs=[]
for device,icd in [('amd','radeon'),('lavapipe','lvp')]:
    env.update(VK_DRIVER_FILES=f'/usr/share/vulkan/icd.d/{icd}_icd.json',VK_ICD_FILENAMES=f'/usr/share/vulkan/icd.d/{icd}_icd.json')
    for repeat in range(3):
        for mode in ['owned-retained','owned-rebind','wrapped-live','wrapped-dead-resize','wrapped-dead-redraw','owned-destroy-event']:
            name=f'trace2-{device}-{repeat}-{mode}';command=[str(binary),mode]
            with (dest/(name+'.log')).open('w') as output:
                result=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=20)
            content=(dest/(name+'.log')).read_text();bad='BadWindow' in content and 'X_GetWindowAttributes' in content
            expected=mode in ['owned-retained','owned-rebind','wrapped-live']
            assert (result.returncode==0) if expected else (result.returncode==1 and bad), (name,result.returncode)
            runs.append({'name':name,'command':command,'driver':device,'exit':result.returncode,'expected_success':expected,'bad_window_attributes':bad})
            print(name,result.returncode,flush=True)
            (dest/'trace2-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
(dest/'trace2-binary-sha256.txt').write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'\n')
