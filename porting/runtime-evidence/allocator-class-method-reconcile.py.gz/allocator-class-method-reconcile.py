import collections,gzip,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/rustycad-allocator-method-reconciliation')
rows=json.load(open('/tmp/allocator-family-inventory-rows.json'))
kinds={'CXXConstructor','CXXDestructor','CXXMethod','CXXConversion','Function','FunctionTemplate'}
callables=[row for row in rows if row['kind'] in kinds]
previous={r['id']:r for r in map(json.loads,(root/'porting/audits/allocator-callable-checklist.jsonl').read_text().splitlines())}
protected=json.loads((root/'porting/audits/allocator-protected-operations.json').read_text())
updates={r['id']:r for r in protected['newly_adapted_declarations']}
pending=json.loads(subprocess.check_output(['git','show','207450a3:porting/audits/inc-allocator-native-blocks.json'],cwd=root))
pending_methods={r['id']:r for r in pending['newly_adapted_declarations']}
family_counts=collections.Counter();results=[]
standard={'Allocate':'memory::allocate','AllocateOptimal':'memory::allocate_optimal','Free':'memory::free/free_and_null','Reallocate':'memory::reallocate','AllocateAligned':'memory::allocate_aligned','FreeAligned':'memory::free_aligned/free_aligned_and_null','Purge':'memory::purge','GetAllocatorType':'memory::get_allocator_type','StackTrace':'standard::stack_trace'}
opt={'Standard_MMgrOpt':'MMgrOpt::new','~Standard_MMgrOpt':'MMgrOpt::drop','Allocate':'MMgrOpt::allocate','Free':'MMgrOpt::free','Reallocate':'MMgrOpt::reallocate','SetCallBackFunction':'MMgrOpt::set_call_back_function','Purge':'MMgrOpt::purge','Initialize':'MMgrOpt::new (internal startup only)','FreePools':'MMgrOpt::free_pools','FreeMemory':'MMgrOpt::free_system_memory','AllocMemory':'MMgrOpt::allocate_system_memory'}
for row in sorted(callables,key=lambda r:(r['qualified_name'],r['signature'],r['kind'],r['id'])):
 q,sig=row['qualified_name'],row['signature'];family=q.split('::')[0];name=q.split('::')[-1]
 if family=='operator==':family=pathlib.Path(row['spelling_location']['file']).stem
 family_counts[family]+=1
 result={k:row[k] for k in ['id','qualified_name','signature','kind','usr','access','api_visible','macro_generated','spelling_location'] if k in row}
 result.update(family=family,status='needs_manual_classification',rust_binding='',evidence=[],automatic_api_credit=0)
 if row['id'] in previous:
  prior=previous[row['id']];result.update(status=prior['status'],rust_binding=prior['rust'],scope_or_gap=prior['scope_or_gap'],evidence=['porting/audits/allocator-callable-checklist.jsonl'])
  if row['id'] in updates:result.update(status='bounded_canonical_engine_adapter',rust_binding=updates[row['id']]['rust_binding'],scope_or_gap='Real engine operation; native raw domains and Rust synchronization limits remain explicit.',evidence=['porting/audits/allocator-protected-operations.json'])
  if row['id'] in pending_methods:result['pending_candidate']={'commit':'207450a3','rust_binding':pending_methods[row['id']]['rust_binding'],'receipt':'porting/audits/inc-allocator-native-blocks.json','status':'not_on_reconciled_main_c6b9259f'}
 elif family in ['NCollection_OccAllocator','NCollection_Allocator']:
  typ='OccAllocator' if family.endswith('OccAllocator') else 'StandardAllocator'
  methods={'allocate':'allocate_with_hint','deallocate':'deallocate_ptr','reallocate':'reallocate_ptr','max_size':'max_size','SetAllocator':'set_allocator','Allocator':'allocator','construct':'AllocatorTypes::construct_with','destroy':'AllocatorTypes::destroy','address':'AllocatorTypes::address' if '(const ' in sig else 'AllocatorTypes::address_mut','operator==':'PartialEq::eq','operator!=':'PartialEq::ne'}
  if name.startswith(family):
   binding='Default::default' if sig.startswith('void ()') else 'Clone::clone'
   if 'BaseAllocator' in sig:binding=('with_allocator_move_from' if '&&' in sig else 'with_allocator_ref') if typ=='OccAllocator' else 'from_optional_base'
   elif '&&' in sig:binding='move_from'
   elif 'type-parameter-1-0' in sig:binding='rebind'
  elif name=='operator=':binding='move_assign_returning' if '&&' in sig else 'assign_returning'
  else:binding=methods[name]
  result.update(status='bounded_previously_evidenced_adapter',rust_binding=typ+'::'+binding,evidence=['porting/audits/occ-allocator-method-contracts.json'],scope_or_gap='Raw allocation overflow/null and typed alignment are explicit Rust adaptations; generic C++ argument forwarding is represented by constructor policies, not automatic template body parity.')
 elif family=='Standard':
  if name.startswith('operator '):result.update(status='no_explicit_class_operator_adapter',rust_binding='Underlying allocation/free operations exist; Standard-specific operator surface is absent',scope_or_gap='Macro new/delete/new[]/delete[] and placement operators need explicit source-specific bindings; generic Rust allocation is not counted as coverage.')
  else:
   result.update(status='bounded_existing_service_adapter',rust_binding=standard[name],evidence=['crates/tkernel/tests/standard_services_api_behavior/memory.rs'],scope_or_gap='Pinned NATIVE memory-manager profile only; safe owners adapt void pointers and template pointer-slot overloads.')
   if name in ['Allocate','AllocateOptimal','Reallocate']:result.update(status='partial_vec_owned_storage',scope_or_gap='StandardMemory uses Vec: zero-size live owners alias dangling address1 and lack native malloc alignment; Reallocate resizes Vec rather than the shared raw heap engine.')
   if name in ['AllocateAligned','FreeAligned']:result.update(status='partial_vec_aligned_storage',scope_or_gap='AlignedMemory uses independent overallocated Vec plus an offset, not shared raw allocation ownership; zero-size alignment1 can expose a dangling address.')
   if name=='StackTrace':result['evidence']=['crates/tkernel/src/standard/stack_trace.rs'];result['scope_or_gap']='Outside allocation operation selection; current platform-specific adapter must retain separate stack-trace evidence.'
 elif family=='Standard_MMgrRoot':
  binding={'~Standard_MMgrRoot':'dynamic concrete Drop','Allocate':'MMgrRoot::allocate','Free':'MMgrRoot::free','Reallocate':'MMgrRoot::reallocate','Purge':'MMgrRoot::purge'}[name]
  result.update(status='bounded_trait_adapter',rust_binding=binding,evidence=['crates/tkernel/src/standard/mmgr_root.rs'],scope_or_gap='Safe StorageAddress and mutable manager borrows adapt native virtual raw pointers; this is not arbitrary C++ subclass or concurrent raw-pointer parity.')
 elif family=='Standard_MMgrOpt':
  result.update(status='bounded_existing_manager_adapter',rust_binding=opt[name],evidence=['porting/audits/standard-mmgr-opt-protected-hooks.json','porting/audits/standard-mmgr-opt-partial-free.json','porting/audits/standard-mmgr-opt-mapped-prefix-os.json'],scope_or_gap='Mapped/unmapped memory, callback and pointer validation domains remain limited to their existing receipts; no fresh runtime revalidation in this checklist.')
  if name=='Initialize':result.update(status='internal_startup_only',scope_or_gap='Constructor applies Initialize adjustments; there is no protected per-instance Initialize callable or proof of repeat invocation over existing manager state.')
 assert result['status']!='needs_manual_classification',result
 result['template_record_role']='enclosing_template_record' if row['kind']=='FunctionTemplate' else 'callable_declaration_record'
 results.append(result)
path=root/'porting/audits/allocator-class-method-reconciliation.jsonl'
path.write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in results))
raw=root/'porting/runtime-evidence/allocator-class-method-selected-declarations.json.gz'
raw.write_bytes(gzip.compress(json.dumps(rows,indent=2).encode(),mtime=0))
summary={'schema':'rustycad.class-method-reconciliation.v1','reconciled_main':'c6b9259f','scope':'Seven NCollection allocator classes plus Standard, Standard_MMgrRoot and Standard_MMgrOpt; all compiler-recorded explicit callable declarations including free equality templates and macro operators','selected_declarations':len(rows),'callable_records':len(callables),'enclosing_template_records':sum(r['kind']=='FunctionTemplate' for r in callables),'noncallable_records':len(rows)-len(callables),'by_family':dict(family_counts),'by_status':dict(collections.Counter(r['status'] for r in results)),'historical_rows_preserved':len(previous),'historical_rows_with_integrated_method_updates':len(updates),'pending_canonical_header_candidate':'207450a3 (three method rows kept separate from integrated status)','selected_inventory_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'source_inventory_sha256':hashlib.sha256((root/'porting/api-inventory/occt-declarations.jsonl.gz').read_bytes()).hexdigest(),'checklist_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'automatic_api_parity_credit':0,'limitations':['Completeness is relative to the pinned compiler declaration capture, not a proof of all platform/template instantiations.','FunctionTemplate records and their method/function/constructor body records are retained as separate compiler IDs; counts are declaration records, not independent semantic overload totals.','Structural fields, typedefs, enums, parameters and variables are preserved in the selected declaration artifact but are not mislabeled callable methods.','Existing bounded adapters do not claim full class parity; status and scope remain attached to each exact declaration.','Runtime evidence references are historical evidence except where a later implementation receipt explicitly revalidates them.'],'next_concrete_slice':'Standard ordinary/aligned byte owners over the existing common raw allocation engine, real reallocation and native zero-size allocation identity; owned.rs untouched'}
(root/'porting/audits/allocator-class-method-reconciliation.json').write_text(json.dumps(summary,indent=2)+'\n')
assert {r['id'] for r in results}=={r['id'] for r in callables}
assert set(previous)<={r['id'] for r in results}
print(json.dumps(summary,indent=2))
