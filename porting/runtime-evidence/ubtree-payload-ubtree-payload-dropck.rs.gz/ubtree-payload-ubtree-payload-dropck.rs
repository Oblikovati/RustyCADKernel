use rustycad_tkernel::ncollection::{BoundingNode, ObjBnd};
fn node_dropck() {
    let node;
    let value = String::from("borrowed");
    node = BoundingNode::new(&value, ());
    assert_eq!(node.object().as_str(), "borrowed");
}
fn pair_dropck() {
    let pair;
    let value = String::from("borrowed");
    pair = ObjBnd::new(&value, ());
    assert_eq!(pair.object.as_str(), "borrowed");
}
fn public_partial_move() {
    let pair = ObjBnd { object: String::from("object"), bounds: String::from("bounds") };
    let object: String = pair.object;
    assert_eq!(object, "object");
    assert_eq!(pair.bounds, "bounds");
}
fn main() {
    node_dropck();
    pair_dropck();
    public_partial_move();
}
