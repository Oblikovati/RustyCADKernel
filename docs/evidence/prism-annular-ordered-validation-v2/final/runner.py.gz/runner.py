import ast,gzip,hashlib,json,os,platform,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/prism-annular-ordered-validation-v2/final';out.mkdir(parents=True,exist_ok=True)
raw=root/'target/annular-ordered-final';raw.mkdir(exist_ok=True)
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
def digest(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0')
 return {p:digest((root/p).read_bytes()) for p in names if p}
def retain(name,payload):
 p=out/name;p.write_bytes(gzip.compress(payload,mtime=0));return {'path':name,'sha256':digest(p.read_bytes())}
def run(name,cmd):
 log=raw/(name+'.log');print('starting',name,flush=True)
 with log.open('wb') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 content=log.read_bytes();row={'name':name,'command':cmd,'exit':r.returncode,'log':retain(name+'.log.gz',content)}
 counts=re.findall(rb'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',content)
 if counts:row['tests']={k:sum(int(v[i]) for v in counts) for i,k in enumerate(['passed','failed','ignored'])}
 commands.append(row);print(json.dumps(row),flush=True)
 assert r.returncode==0,name
 return content
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();before=snapshot();commands=[];records=[]
try:
 args=['-p','rustycad-tkbo','--all-features','--locked']
 run('tests',['cargo','+1.99.0','test','--all-targets',*args,'--','--test-threads=2'])
 run('doctests',['cargo','+1.99.0','test','--doc',*args])
 run('clippy',['cargo','+1.99.0','clippy','--all-targets',*args,'--','-D','warnings'])
 run('fmt',['cargo','+1.99.0','fmt','--all','--','--check'])
 env['RUSTDOCFLAGS']='-D warnings';run('docs',['cargo','+1.99.0','doc','--no-deps',*args])
 exe=root/'target/debug/deps/rustycad_tkbo-3743221922cb8a91'
 probes=[('ordered','frozen::ordered_validation::replay_tests::ordered_validation_process_receipt','ordered-validation-v1:','hex'),('annular','frozen::annular_join::replay_tests::annular_frozen_join_owned_process_receipt','named-annular-frozen-domain-v2=','hex'),('publication','publication::replay_tests::publication_process_replay','named-prism-publication-v1=','hex'),('annular-ordered','frozen::ordered_validation::annular::replay_tests::ordered_annular_replay_probe','ANNULAR_ORDERED_REPLAY=','array')]
 for name,test,marker,kind in probes:
  payloads=[]
  for ordinal in (1,2):
   log=run(name+'-'+str(ordinal),[str(exe),'--exact','sketch_region_prism::'+test,'--nocapture','--test-threads=1'])
   assert b'1 passed;' in log
   value=log.decode().split(marker,1)[1].splitlines()[0];payload=bytes(ast.literal_eval(value)) if kind=='array' else bytes.fromhex(value)
   retain(name+'-'+str(ordinal)+'.bin.gz',payload);payloads.append(payload)
  assert payloads[0]==payloads[1],name
  baseline=root/'docs/evidence/prism-annular-ordered-validation-v2/baseline'/str(name+'.bin.gz')
  if baseline.exists():assert payloads[0]==gzip.decompress(baseline.read_bytes()),name
  records.append(dict(name=name,bytes=len(payload),sha256=digest(payload),processes=2,previous_baseline=baseline.exists()))
finally:
 after=snapshot();retain('source-bookends.json.gz',json.dumps(dict(before=before,after=after),sort_keys=True).encode())
 receipt=dict(source=revision,platform=platform.platform(),toolchain='1.99.0',commands=commands,source_unchanged=before==after,source_count=len(before),replays=records,limitations=['No publication, complete history or release acceptance','No ThreadSanitizer suite executed; retained host startup limitation remains incomplete'])
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');retain('runner.py.gz',Path(__file__).read_bytes())
assert before==after
print('all checks green',flush=True)
