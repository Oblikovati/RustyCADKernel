import hashlib,json,os,pathlib,platform,subprocess
root=pathlib.Path.cwd();out=root/'target/owned-refusal-tsan';tool=pathlib.Path('/home/vmiguel/.rustup/toolchains/nightly-2026-09-25-x86_64-unknown-linux-gnu/bin')
env=os.environ.copy();env['PATH']=str(tool)+':'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'host':platform.platform(),'toolchain':subprocess.check_output([str(tool/'rustc'),'-Vv'],text=True),'host_masking':False,'inherited_environment':{k:os.environ.get(k) for k in ['LD_PRELOAD','TSAN_OPTIONS','RUSTFLAGS']},'suite':{'built':False,'executed':False},'commands':[]}
def run(name,cmd,environment):
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(cmd,env=environment,stdout=stdout,stderr=stderr)
 record={'name':name,'command':cmd,'returncode':result.returncode};report['commands'].append(record)
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');return result.returncode
env['RUSTFLAGS']='-Zsanitizer=thread -Cforce-frame-pointers=yes'
cmd=[str(tool/'cargo'),'build','-Zbuild-std','--target','x86_64-unknown-linux-gnu','--manifest-path',str(out/'control/Cargo.toml'),'--target-dir',str(out/'build')]
report['rustflags']=env['RUSTFLAGS'];built=run('sanitized-build',cmd,env)
if built==0:
 binary=out/'build/x86_64-unknown-linux-gnu/debug/martensite-owned-refusal-tsan-control';report['sanitized_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
 status=run('sanitized-startup',[str(binary)],env);report['sanitized_main_marker']='owned-refusal-tsan-main-entered' in (out/'sanitized-startup.stdout').read_text()
 if status==0 and report['sanitized_main_marker']:
  cmd=[str(tool/'cargo'),'test','-Zbuild-std','--target','x86_64-unknown-linux-gnu','--target-dir',str(out/'suite-build'),'-p','rustycad-tkbo','--lib','owned_refusal','--','--test-threads=1']
  result=run('actual-suite',cmd,env);output=(out/'actual-suite.stdout').read_text()+(out/'actual-suite.stderr').read_text();report['suite']={'built':'Running unittests' in output,'executed':'running 26 tests' in output,'returncode':result}
unsanitized=out/'unsanitized-control';cmd=[str(tool/'rustc'),str(out/'control/src/main.rs'),'-o',str(unsanitized)]
if run('unsanitized-build',cmd,os.environ.copy())==0:
 report['unsanitized_sha256']=hashlib.sha256(unsanitized.read_bytes()).hexdigest();run('unsanitized-startup',[str(unsanitized)],os.environ.copy())
 report['unsanitized_main_marker']='owned-refusal-tsan-main-entered' in (out/'unsanitized-startup.stdout').read_text()
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
