from pathlib import Path
import os,subprocess
root=Path('/tmp/rustycad-ubtree-kill-methods');build=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full');libs=build/'lin64/gcc/libi';env=dict(os.environ,LD_LIBRARY_PATH=str(libs))
for stem in ['tkernel_ubtree_kill_contracts','tkernel_ubtree_payload_contracts','tkernel_ubtree_method_contracts']:
 subprocess.run(['g++','-std=c++17','-I'+str(build/'include/opencascade'),str(root/'tools/oracle'/f'{stem}.cxx'),'-L'+str(libs),'-lTKernel','-o','/tmp/'+stem],check=True)
 output=subprocess.check_output(['/tmp/'+stem],env=env)
 assert output==(root/'tools/oracle'/f'{stem}.expected').read_bytes()
 Path('/tmp/ubtree-kill-native-'+stem+'.log').write_bytes(output);print(stem,len(output.splitlines()),'matched',flush=True)
with open('/tmp/ubtree-kill-legacy.log','w') as output:
 result=subprocess.run([str(build/'lin64/gcc/bini/OpenCascadeGTest'),'--gtest_filter=NCollection_UBTreeTest.*:NCollection_EBTreeTest.*'],env=env,stdout=output,stderr=subprocess.STDOUT)
print('legacy',result.returncode,flush=True);assert result.returncode==0
