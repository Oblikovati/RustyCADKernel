fn main() { println!("TSAN_STARTUP_CONTROL_MAIN_REACHED"); }
