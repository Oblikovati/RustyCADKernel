import gzip, hashlib, json, os, re, subprocess
from pathlib import Path
p=Path('docs/evidence/prism-embedding-v1-2026-10-14')
expected=json.loads((p/'boxing-comparison.json').read_text())
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}
rows=[]
for label in ['first','second']:
 command=['cargo','+1.99.0','test','-p','rustycad-tkbo','--all-features','--lib','prism_embedding_process_receipt','--locked','--','--nocapture','--test-threads=1']
 result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (p/('integrated-replay-'+label+'.log.gz')).write_bytes(gzip.compress(result.stdout,mtime=0))
 assert result.returncode==0,result.stdout[-4000:]
 lines=result.stdout.decode().splitlines()
 values=[line[line.index('{"operation":"martensite.prism-embedding"'):] for line in lines if '{"operation":"martensite.prism-embedding"' in line]
 assert len(values)==1,values
 payload=values[0].encode()
 actual=hashlib.sha256(payload).hexdigest()
 assert actual==expected['sha256'],(actual,expected)
 rows.append({'command':command,'exit_code':0,'bytes':len(payload),'sha256':actual,'matches_candidate':True})
rootlog=gzip.decompress((p/'integrated-tests.log.gz').read_bytes()).decode()
candidatelog=gzip.decompress((p/'tests.log.gz').read_bytes()).decode()
pattern=r'^test (\S+) \.\.\. ok$'
rootnames=set(re.findall(pattern,rootlog,re.M)); candidatenames=set(re.findall(pattern,candidatelog,re.M))
assert rootnames and candidatenames
assert not candidatenames-rootnames, sorted(candidatenames-rootnames)
(p/'integrated-replay.json').write_text(json.dumps({'processes':rows,'additional_integrated_tests':sorted(rootnames-candidatenames)},indent=2)+'\n')
print('Both replays match candidate; additional integrated tests:',len(rootnames-candidatenames),flush=True)
