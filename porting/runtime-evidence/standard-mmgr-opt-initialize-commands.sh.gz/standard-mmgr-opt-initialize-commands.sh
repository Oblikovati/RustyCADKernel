#!/bin/bash
cd /tmp/rustycad-mmgropt-initialize || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-target
cargo test -p rustycad-tkernel --lib standard::mmgr_opt > /tmp/mmgropt-initialize-unit.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-unit.exit
cargo test -p rustycad-tkernel --test mmgr_opt_initialize --test standard_memory_storage --test standard_services_api_behavior --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_cell_filter --test ncollection_ordered_map --test ncollection_ordered_data_map > /tmp/mmgropt-initialize-rust.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-rust.exit
cargo test -p rustycad-tkernel --doc > /tmp/mmgropt-initialize-doc.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-doc.exit
cargo clippy -p rustycad-tkernel --all-targets -- -D warnings > /tmp/mmgropt-initialize-clippy.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-clippy.exit
cargo fmt --all -- --check > /tmp/mmgropt-initialize-fmt.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-fmt.exit

#!/bin/bash
cd /tmp/rustycad-mmgropt-initialize || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-miri MIRIFLAGS=-Zmiri-strict-provenance
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib standard::mmgr_opt > /tmp/mmgropt-initialize-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test mmgr_opt_initialize --test standard_memory_storage > /tmp/mmgropt-initialize-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_services_api_behavior memory -- --skip memory::allocate_optimal_returns_null_instead_of_raising > /tmp/mmgropt-initialize-services-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-services-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test standard_services_api_behavior mmgr::initialize_corrects_page_count_and_rounds_cell_size > /tmp/mmgropt-initialize-legacy-miri.log 2>&1
printf '%s\n' "$?" > /tmp/mmgropt-initialize-legacy-miri.exit

#!/bin/bash
cd /tmp/rustycad-mmgropt-initialize || exit 2
c++ -std=c++17 tools/oracle/tkernel_mmgr_opt_initialize.cxx -I/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/include/opencascade -L/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -Wl,-rpath,/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/libi -lTKernel -o /tmp/mmgropt-initialize-native
/tmp/mmgropt-initialize-native
/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full/lin64/gcc/bini/OpenCascadeGTest --gtest_filter='NCollection_BaseAllocatorTest.*:NCollection_OccAllocatorTest.*:NCollection_CellFilterTest.*:NCollection_OrderedMapTest.*:NCollection_OrderedDataMapTest.*'
