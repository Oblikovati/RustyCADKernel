//! Diagnostic only: isolates Vulkan lifetime from Martensite toolkit handle transport.
use martensite_vulkan::{PrimitiveDraw, RenderBackend, RenderFrame, RenderVertex, VulkanOptions, VulkanRenderer, identity_clip};
use std::sync::{Arc, Barrier};
fn triangle_frame() -> RenderFrame {
    let vertices = [[-0.5, -0.5, 0.0], [0.5, -0.5, 0.0], [0.0, 0.5, 0.0]]
        .map(|point| RenderVertex::new(point, [1.0, 0.0, 0.0, 1.0])).to_vec();
    let draw = PrimitiveDraw::new(vertices, vec![0, 1, 2], identity_clip()).unwrap();
    RenderFrame::new(32, 32, [0.0, 0.0, 0.0, 1.0], vec![draw]).unwrap()
}
fn lifecycle_worker(index: usize, barrier: Arc<Barrier>) {
    barrier.wait();
    for round in 0..8 {
        let mut renderer = VulkanRenderer::new(VulkanOptions { validation: true, device_index: Some(0) }).unwrap();
        for _ in 0..1 + (index + round) % 6 {
            let capture = renderer.render(&triangle_frame()).unwrap();
            assert_eq!(capture.rgba.len(), 32 * 32 * 4);
        }
        assert!(renderer.validation_errors().is_empty());
    }
}
fn main() {
    let barrier = Arc::new(Barrier::new(13));
    let workers: Vec<_> = (0..13).map(|index| {
        let barrier = barrier.clone();
        std::thread::spawn(move || lifecycle_worker(index, barrier))
    }).collect();
    for worker in workers { worker.join().unwrap(); }
    println!("{{\"workers\":13,\"cycles_per_worker\":8,\"validation\":true,\"status\":\"passed\"}}");
}
