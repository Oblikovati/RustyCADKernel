#!/bin/bash
cd /tmp/rustycad-allocator-protected-operations || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-target
cargo test -p rustycad-tkernel --lib --test allocator_protected_operations --test acc_allocator_aligned_reservation --test acc_allocator_alignment_safety --test acc_allocator_owned_release --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers --test ncollection_ordered_map --test ncollection_ordered_data_map --test ordered_canonical_storage --test ordered_node_contracts > /tmp/allocator-protected-rust.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-rust.exit
cargo test -p rustycad-tkernel --doc > /tmp/allocator-protected-doc.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-doc.exit
cargo clippy -p rustycad-tkernel --all-targets -- -D warnings > /tmp/allocator-protected-clippy.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-clippy.exit
cargo fmt --all -- --check > /tmp/allocator-protected-fmt.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-fmt.exit

#!/bin/bash
cd /tmp/rustycad-allocator-protected-operations || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-miri MIRIFLAGS=-Zmiri-strict-provenance
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test allocator_protected_operations --test acc_allocator_aligned_reservation --test acc_allocator_alignment_safety --test acc_allocator_owned_release --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers --test ncollection_ordered_map --test ncollection_ordered_data_map --test ordered_canonical_storage --test ordered_node_contracts > /tmp/allocator-protected-miri.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::allocator > /tmp/allocator-protected-allocator-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-allocator-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::ordered_table::canonical_contracts > /tmp/allocator-protected-ordered-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-ordered-unit-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::cell_filter > /tmp/allocator-protected-cell-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/allocator-protected-cell-unit-miri.exit
