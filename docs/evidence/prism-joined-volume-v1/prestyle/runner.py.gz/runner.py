import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd(); out=root/'docs/evidence/prism-joined-volume-v1/prestyle';out.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def files():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=files(); revision=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'}; commands=[];replays=[]
for i in (1,2):
 command=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked','joined_volume::','--','--nocapture','--test-threads=1'];p=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'focused-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
 matches=re.findall(r'joined-volume-v1=([0-9a-f]+)',p.stdout.decode());assert len(matches)==1;actual=bytes.fromhex(matches[0]); replays.append(actual);(out/f'replay-{i}.bin.gz').write_bytes(gzip.compress(actual,mtime=0));commands.append({'command':command,'exit_code':p.returncode,'tests':12})
assert replays[0]==replays[1];assert before==files(); (out/'source-bookends.json.gz').write_bytes(gzip.compress(json.dumps({'before':before,'after':files()},sort_keys=True).encode(),mtime=0))
for label,path in [('expanded','/tmp/martensite-volume-expanded.log'),('clippy','/tmp/martensite-volume-clippy.log')]: (out/f'preceding-{label}.log.gz').write_bytes(gzip.compress(pathlib.Path(path).read_bytes(),mtime=0))
receipt={'revision':revision,'commands':commands,'source_unchanged':True,'full_replay':{'bytes':len(replays[0]),'sha256':sha(replays[0])},'scope':'pin before mechanical helper extraction;12focused tests, no full suite/publication/sanitizer claim'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print(json.dumps(receipt),flush=True)
