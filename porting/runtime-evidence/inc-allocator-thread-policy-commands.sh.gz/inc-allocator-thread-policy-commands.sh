#!/bin/bash
cd /tmp/rustycad-inc-allocator-thread-policy || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-target
cargo test -p rustycad-tkernel --lib --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers > /tmp/inc-thread-rust.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-rust.exit
cargo test -p rustycad-tkernel --doc > /tmp/inc-thread-doc.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-doc.exit
cargo clippy -p rustycad-tkernel --all-targets -- -D warnings > /tmp/inc-thread-clippy.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-clippy.exit
cargo fmt --all -- --check > /tmp/inc-thread-fmt.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-fmt.exit

#!/bin/bash
cd /tmp/rustycad-inc-allocator-thread-policy || exit 2
export PATH=/home/vmiguel/.cargo/bin:$PATH CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/tmp/rustycad-sequence-tail-miri MIRIFLAGS=-Zmiri-strict-provenance
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --test inc_allocator_thread_policy --test ncollection_base_allocator --test ncollection_occ_allocator --test ncollection_allocators_api_behavior --test ncollection_allocator_views_behavior --test allocator_supplemental --test typed_allocator_provenance_contracts --test occ_allocator_method_contracts --test ncollection_cell_filter --test cell_filter_method_contracts --test cell_filter_supplemental --test cell_filter_fallible --test cell_filter_cell_methods --test cell_filter_protected_helpers > /tmp/inc-thread-miri.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-miri.exit
cargo +nightly-2026-09-25 miri test -p rustycad-tkernel --lib ncollection::cell_filter > /tmp/inc-thread-unit-miri.log 2>&1
printf '%s\n' "$?" > /tmp/inc-thread-unit-miri.exit
