import gzip,hashlib,json,runpy,subprocess,sys
from pathlib import Path
root=Path.cwd();out=root/'docs/evidence/annular-prism-construction-integration-2026-10-14';candidate=root/'docs/evidence/annular-prism-construction-v1-2026-10-14'
report=json.loads((out/'integrated-main.json').read_text());assert report['checks_passed']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def source():return {n:digest(root/n) for n in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],text=True).split('\0') if n}
before=source();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
seal=json.loads((candidate/'artifact-seal.json').read_text())
for name,value in seal.items():assert digest(candidate/name)==value,name
baseline=json.loads((candidate/'baseline.json').read_text());expected={r['filter']:r['payloads'] for r in baseline['commands']}
for phase in ['root-first','root-second']:
 sys.argv=['/tmp/martensite-annular-integration-replay.py',phase];runpy.run_path(sys.argv[0],run_name='__main__')
 actual=json.loads((out/(phase+'.json')).read_text());assert {r['filter']:r['payloads'] for r in actual['commands']}==expected
assert source()==before
import re
names=lambda p:set(re.findall(r'^test (.+?) \.\.\. ok$',gzip.decompress(p.read_bytes()).decode(),re.M))
prior=names(candidate/'full-tests.log.gz');actual=names(out/'integrated-tests.log.gz')|names(out/'integrated-doctests.log.gz');assert prior<=actual
(out/'supplement.json').write_text(json.dumps({'source_revision':report['integration_revision'],'source_unchanged':True,'candidate_artifacts_verified':len(seal),'all_candidate_test_names_retained':True,'additional_all_target_test_names':sorted(actual-prior),'independent_replay_processes':14,'baseline_payloads':expected,'scope':'Construction/raw chart extraction only; full annular validity and release incomplete'},indent=2)+'\n')
for script in ['/tmp/martensite-annular-main-supplement.py','/tmp/martensite-annular-integration-replay.py']:(out/(Path(script).name+'.gz')).write_bytes(gzip.compress(Path(script).read_bytes(),mtime=0))
print('Annular main supplement passed',flush=True)
