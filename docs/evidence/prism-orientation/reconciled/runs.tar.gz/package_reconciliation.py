import hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-orientation')
run=Path('/tmp/martensite-prism-orientation-reconciled')
report=json.loads((run/'receipt.json').read_text())
assert report['source_unchanged'] and all(r['exit_code']==0 for r in report['commands'])
def rows(path,marker):
    return [s for s in path.read_text().splitlines() if s.startswith(marker)]
orientation=rows(run/'focused.log','{"operation":"martensite.prism-orientation"')
original=Path('/tmp/martensite-prism-orientation-checks/frozen/orientation-portable.json').read_text().strip()
assert orientation==[original],orientation
embedding=rows(run/'embedding-baseline.log','{"operation":')
old_embedding=rows(Path('/tmp/martensite-prism-orientation-checks/frozen/embedding-baseline.log'),'{"operation":')
assert len(embedding)==1 and embedding==old_embedding
report['replay_comparison']={'orientation_identical_to_original':True,'embedding_identical_to_original':True,'orientation_receipts':1,'embedding_receipts':1,'separate_process_replays':2,'independent_workers':8,'worker_repetitions':4}
report['focused_tests']=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(run/'focused.log').read_text())))
names=subprocess.check_output(['git','diff','--name-only','e6955e6db','HEAD','--','crates','docs/adr'],cwd=root).decode().splitlines()
report['candidate_files']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}
report['original_sanitizer_status']='incomplete; executable SIGSEGV before test output; not rerun for reconciliation'
for n in names:
    dest=run/'candidate-source'/n; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(root/n,dest)
shutil.copy2('/tmp/martensite-prism-orientation-checks/reconcile.py',run/'reconcile.py')
shutil.copy2('/tmp/martensite-prism-orientation-checks/run_matrix.py',run/'run_matrix.py')
shutil.copy2('/tmp/martensite-prism-orientation-checks/package_reconciliation.py',run/'package_reconciliation.py')
(run/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
files=sorted(p for p in run.rglob('*') if p.is_file())
(run/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(run))+'\n' for p in files))
out=root/'docs/evidence/prism-orientation/reconciled'; out.mkdir(exist_ok=False)
shutil.copy2(run/'receipt.json',out/'receipt.json')
with tarfile.open(out/'runs.tar.gz','w:gz') as t:
    for p in sorted(run.rglob('*')):
        if p.is_file(): t.add(p,arcname=str(p.relative_to(run)),recursive=False)
print(json.dumps({'revision':report['revision'],'focused':report['focused_tests'],'sources':report['source_files'],'candidate_files':len(names),'archive_files':len(files)+1}))
