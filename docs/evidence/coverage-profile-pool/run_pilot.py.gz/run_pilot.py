"""Actual nextest isolation and binary metadata; only raw-profile policy changes."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

ROOT: Path = Path(__file__).resolve().parent
WORKSPACE: Path = ROOT.parents[1]
LLVM: Path = Path("/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin")
POLICIES: dict[str, str] = {"pid": "pilot-%p-%32m.profraw", "pool1": "pilot-%1m.profraw", "pool4": "pilot-%4m.profraw"}
SELECTION: set[tuple[str, str]] = {tuple(x) for x in json.loads((ROOT / "selected-tests.json").read_text())}


def run_nextest(folder: Path, pattern: str, concurrency: int, repetition: int) -> None:
    environment: dict[str, str] = os.environ.copy()
    environment.update(PATH="/home/vmiguel/.cargo/bin:" + environment["PATH"], LLVM_PROFILE_FILE=str(folder / pattern))
    command: list[str] = ["cargo", "nextest", "run", "--cargo-metadata", str(ROOT / "full-workspace-features.json"), "--binaries-metadata", str(ROOT / "binaries.json"), "--profile", "ci", "--test-threads", str(concurrency), "-E", (ROOT / "filter.txt").read_text().strip()]
    result: subprocess.CompletedProcess[str] = subprocess.run(command, cwd=WORKSPACE, env=environment, capture_output=True, text=True, timeout=20)
    (folder / f"nextest-{repetition}.log").write_text(result.stdout + result.stderr)
    selected: set[tuple[str, str]] = set(re.findall(r"PASS \[[^]]+\] \([^)]*\) (\S+) (\S+)", result.stdout + result.stderr))
    assert result.returncode == 0 and selected == SELECTION
    assert "LLVM Profile" not in result.stderr


def export_profiles(folder: Path, binaries: list[str]) -> None:
    arguments: list[str] = [str(p) for p in sorted(folder.glob("*.profraw"))]
    commands: dict[str, list[str]] = {"merge": ["llvm-profdata", "merge", "-sparse", *arguments, "-o", str(folder / "merged.profdata")], "counters": ["llvm-profdata", "show", "--all-functions", "--counts", str(folder / "merged.profdata")]}
    objects: list[str] = [part for binary in binaries for part in ["--object", binary]]
    for kind in ["json", "lcov"]:
        commands[kind] = ["llvm-cov", "export", *objects, "-instr-profile=" + str(folder / "merged.profdata"), "-format=" + ("text" if kind == "json" else kind)]
    for label, argv in commands.items():
        result: subprocess.CompletedProcess[bytes] = subprocess.run([str(LLVM / argv[0]), *argv[1:]], capture_output=True, timeout=20)
        (folder / f"{label}.stdout").write_bytes(result.stdout)
        (folder / f"{label}.stderr").write_bytes(result.stderr)
        assert result.returncode == 0 and not result.stderr


def categorize_files(folder: Path) -> dict[str, int]:
    profiles: list[Path] = list(folder.glob("*.profraw"))
    return {"raw_files": len(profiles), "raw_logical": sum(p.stat().st_size for p in profiles), "raw_allocated": sum(p.stat().st_blocks * 512 for p in profiles)}


def run_pilot() -> None:
    suites: dict[str, dict[str, object]] = json.loads((ROOT / "list.json").read_text())["rust-suites"]
    binaries: list[str] = [str(s["binary-path"]) for s in suites.values()]
    measurements: dict[str, dict[str, int]] = {}
    for concurrency in [1, 8]:
        for policy, pattern in POLICIES.items():
            folder: Path = ROOT / f"{policy}-c{concurrency}"
            folder.mkdir()
            for repetition in range(4):
                run_nextest(folder, pattern, concurrency, repetition)
            export_profiles(folder, binaries)
            measurements[folder.name] = categorize_files(folder)
            print(folder.name, measurements[folder.name], flush=True)
    (ROOT / "measurements.json").write_text(json.dumps(measurements, indent=2) + "\n")


if __name__ == "__main__":
    run_pilot()
