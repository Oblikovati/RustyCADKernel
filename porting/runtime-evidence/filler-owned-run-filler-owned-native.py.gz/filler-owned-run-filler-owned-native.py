from pathlib import Path
import subprocess
root=Path('/tmp/rustycad-ubtree-filler-owned-policy')
build=Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-modeling-full')
exe='/tmp/tkernel_ubtree_filler_owned_policy_contracts'
command=['g++','-std=c++17','-I'+str(build/'include/opencascade'),str(root/'tools/oracle/tkernel_ubtree_filler_owned_policy_contracts.cxx'),'-L'+str(build/'lin64/gcc/libi'),'-Wl,-rpath,'+str(build/'lin64/gcc/libi'),'-lTKernel','-o',exe]
subprocess.run(command,check=True)
rows=[]
for mode in ['', 'Oe','Be','Od','Bd','Ou','Bu']:
 result=subprocess.run([exe,*([mode] if mode else [])],capture_output=True,text=True)
 assert result.returncode==(86 if mode.endswith(('d','u')) else 0)
 rows.append(f'case {mode or "traits"} exit {result.returncode}\n'+result.stdout)
text=''.join(rows)
print(text,end='')
assert (root/'tools/oracle/tkernel_ubtree_filler_owned_policy_contracts.expected').read_text()==text
