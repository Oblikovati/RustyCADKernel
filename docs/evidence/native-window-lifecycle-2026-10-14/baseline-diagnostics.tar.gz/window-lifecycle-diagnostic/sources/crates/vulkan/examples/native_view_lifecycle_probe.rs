//! Temporary public-view lifetime diagnostic; no error handlers or production fallback.
#![allow(unsafe_code)]
#[path = "support/native_window.rs"]
mod native_window;
use martensite_vulkan::{Graphic3dRenderDriver, Graphic3dRenderView, VulkanOptions};
use rustycad_tkernel::standard::Handle;
use rustycad_tkservice::{aspect::AspectWindow, xw::XwWindow};
use rustycad_tkv3d::v3d::V3dViewer;
fn main() {
    let mode = std::env::args().nth(1).expect("expected lifecycle mode");
    let driver = Graphic3dRenderDriver::new(VulkanOptions { validation: true, ..Default::default() }).unwrap();
    let native = native_window::NativeWindow::new(64, 64);
    let display = native.window.window_base().fields().display.clone();
    let viewer = V3dViewer::new(&driver.cast()).unwrap();
    let view = viewer.create_view().unwrap();
    view.set_immediate_update(false);
    let window = if mode.starts_with("wrapped") {
        Handle::new(XwWindow::wrap(&display, native.window.native_handle(), 0).unwrap())
    } else {
        native.window.clone()
    };
    let original_id = window.native_handle();
    view.set_window(&window.cast(), 0).unwrap();
    let render = view.get().unwrap().view().cast::<Graphic3dRenderView>();
    render.try_redraw().unwrap();
    assert_eq!(render.capture().unwrap().width, 64);
    drop(window);
    let retained_native = (mode == "wrapped-live").then_some(native);
    eprintln!("{{\"probe\":\"view-lifecycle\",\"mode\":{mode:?},\"original_window\":{original_id},\"stage\":\"caller-owner-released\"}}");
    match mode.as_str() {
        "owned-rebind" => rebind_view(view.get().unwrap()),
        "owned-display-reset" => display.init(0).unwrap(),
        "owned-destroy-event" => destroy_native_window(&view.get().unwrap().window().cast::<XwWindow>()),
        "owned-retained" | "wrapped-live" | "wrapped-dead-resize" | "wrapped-dead-redraw" => {},
        _ => panic!("unexpected lifecycle mode={mode:?}"),
    }
    if mode != "wrapped-dead-redraw" { view.must_be_resized(); }
    render.try_redraw().unwrap();
    assert_eq!(render.capture().unwrap().width, 64);
    view.remove();
    assert!(render.capture().is_err());
    assert!(driver.validation_errors().is_empty());
    drop(retained_native);
    eprintln!("{{\"probe\":\"view-lifecycle\",\"mode\":{mode:?},\"stage\":\"completed\"}}");
}
fn rebind_view(view: &dyn rustycad_tkv3d::v3d::V3dViewSource) {
    let replacement = native_window::NativeWindow::new(64, 64);
    view.set_window(&replacement.window.cast(), 0).unwrap();
}

fn destroy_native_window(window: &XwWindow) {
    let api = x11_dl::xlib::Xlib::open().unwrap();
    let connection = window.window_base().fields().display.clone();
    let display = connection.get_display_aspect() as *mut x11_dl::xlib::Display;
    let mut event: x11_dl::xlib::XEvent = unsafe { std::mem::zeroed() };
    unsafe {
        (api.XDestroyWindow)(display, window.native_handle());
        (api.XSync)(display, 0);
        assert_ne!((api.XCheckTypedWindowEvent)(display, window.native_handle(), x11_dl::xlib::DestroyNotify, &mut event), 0);
    }
    let bytes = unsafe { std::mem::transmute::<x11_dl::xlib::XEvent, [u8; rustycad_tkservice::xw::XwXEvent::SIZE]>(event) };
    let mut message = rustycad_tkservice::xw::XwXEvent::from_bytes(&bytes);
    let mut listener = rustycad_tkv3d::ais::AisViewController::new().unwrap();
    let handled = window.process_message(&mut listener, &mut message).unwrap();
    eprintln!("{{\"probe\":\"view-lifecycle\",\"stage\":\"destroy-event-delivered\",\"handled\":{handled},\"native_handle_after_event\":{}}}", window.native_handle());
}
