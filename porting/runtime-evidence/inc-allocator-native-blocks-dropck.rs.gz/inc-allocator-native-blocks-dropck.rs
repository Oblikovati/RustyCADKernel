use rustycad_tkernel::ncollection::{AllocatedBox, BaseAllocator};

fn escape_borrowed_payload() -> AllocatedBox<&'static u64> {
    let borrowed = 41;
    BaseAllocator::incremental(2048).allocate_value(&borrowed)
}
