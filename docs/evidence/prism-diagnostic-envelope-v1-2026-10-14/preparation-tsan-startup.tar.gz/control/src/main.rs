fn main() {
    println!("diagnostic-envelope-tsan-main-entered");
    let snapshot = std::sync::Arc::new(vec![1_u64, 2, 3]);
    let reader = snapshot.clone();
    let sum = std::thread::spawn(move || reader.iter().sum::<u64>());
    assert_eq!(sum.join().unwrap(), 6);
    assert_eq!(snapshot.as_slice(), &[1, 2, 3]);
}
