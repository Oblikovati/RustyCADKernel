from pathlib import Path
import re,json
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-cap-measures')
paths=list((repo/'crates/tkbo/src/sketch_region_prism/region_certificate/measurements').rglob('*.rs'))+list((repo/'crates/tkmath/src/predicates/roots/metric_bounds/polynomial_integrals/plane').rglob('*.rs'))
paths += [repo/'crates/tkmath/src/predicates/roots/metric_bounds/polynomial_integrals/plane.rs',repo/'crates/tkmath/src/predicates/roots/metric_bounds/affine_support.rs']
rows=[]
for path in paths:
    lines=path.read_text().splitlines();assert len(lines)<500,(path,len(lines))
    start=None;depth=0;begun=False
    for index,line in enumerate(lines,1):
        if start is None:
            match=re.search(r'\bfn\s+(\w+)',line)
            if match:start=index;name=match[1]
        if start is None:continue
        clean=re.sub(r'"(?:\\.|[^"\\])*"','""',line.split('//')[0]);begun|='{' in clean
        depth+=clean.count('{')-clean.count('}')
        if begun and depth==0:
            length=index-start+1;assert 4<=length<=20,(path,name,length)
            rows.append({'path':str(path.relative_to(repo)),'function':name,'line':start,'length':length})
            start=None;begun=False
print(json.dumps({'file_count':len(paths),'function_count':len(rows),'functions':rows},indent=2))
