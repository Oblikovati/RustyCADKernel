"""Retain integrated kernel checks and immutable input bookends."""
import gzip
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / sys.argv[1]
CANDIDATE = sys.argv[2]
BASE = sys.argv[3]
PACKAGES = sys.argv[4:]
OUT.mkdir(parents=True, exist_ok=True)
RAW = ROOT / "target" / ("integrated-" + OUT.name)
RAW.mkdir(parents=True, exist_ok=False)
ENV = {**os.environ, "PATH": "/home/vmiguel/.cargo/bin:" + os.environ["PATH"],
       "CARGO_BUILD_JOBS": "2", "CARGO_TARGET_DIR": str(ROOT / "target/two-loop-integrated-cold"), "PYTHONDONTWRITEBYTECODE": "1"}


def git_bytes(*arguments: str) -> bytes:
    return subprocess.check_output(["git", *arguments], cwd=ROOT)


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def input_snapshot() -> dict[str, str]:
    tracked = git_bytes("ls-files", "-z", "crates", "Cargo.toml", "Cargo.lock",
                        "rust-toolchain.toml", ".cargo").decode().split("\0")
    return {name: digest((ROOT / name).read_bytes()) for name in tracked if name}


def compare_candidate_files(
    base: str, candidate: str, snapshot: dict[str, str]
) -> tuple[dict[str, str], dict[str, bool]]:
    checks = {}
    changes = {}
    origins = (candidate, "e347e8b13")
    ancestor = git_bytes("merge-base", origins[1], candidate).decode().strip()
    names = git_bytes("diff", "--name-only", ancestor, candidate, "--", "crates").decode().splitlines()
    for name in names:
        changes[name] = "candidate"
        expected = [git_bytes("show", origin + ":" + name) for origin in origins
                    if subprocess.run(["git", "cat-file", "-e", origin + ":" + name],
                                      stderr=subprocess.DEVNULL).returncode == 0]
        checks[name] = snapshot.get(name) in [digest(payload) for payload in expected]
    assert all(checks.values()), [name for name, passed in checks.items() if not passed]
    return changes, checks


def write_compressed(name: str, payload: bytes) -> dict[str, str]:
    destination = OUT / name
    destination.write_bytes(gzip.compress(payload, mtime=0))
    return {"path": name, "sha256": digest(destination.read_bytes())}


def run(label: str, command: list[str]) -> dict[str, object]:
    print("starting " + label, flush=True)
    path = RAW / (label + ".log")
    with path.open("w") as stream:
        result = subprocess.run(command, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    payload = path.read_bytes()
    record = {"label": label, "command": command, "exit_code": result.returncode,
              "log": write_compressed("integrated-" + label + ".log.gz", payload)}
    counts = re.findall(r"test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;",
                        payload.decode(errors="replace"))
    if counts:
        record["tests"] = {key: sum(int(row[i]) for row in counts)
                           for i, key in enumerate(("passed", "failed", "ignored"))}
    print(json.dumps(record), flush=True)
    return record


revision = git_bytes("rev-parse", "HEAD").decode().strip()
before = input_snapshot()
candidate_changes, candidate_checks = compare_candidate_files(BASE, CANDIDATE, before)
package_args = [part for package in PACKAGES for part in ("-p", package)]
commands = []
for label, args in (("tests", ["test", "--all-targets"]),
                    ("doctests", ["test", "--doc"]),
                    ("clippy", ["clippy", "--all-targets"])):
    command = ["cargo", "+1.99.0", *args, *package_args, "--all-features", "--locked"]
    if label == "clippy":
        command.extend(["--", "-D", "warnings"])
    commands.append(run(label, command))
commands.append(run("fmt", ["cargo", "+1.99.0", "fmt", "--all", "--", "--check"]))
ENV["RUSTDOCFLAGS"] = "-D warnings"
commands.append(run("docs", ["cargo", "+1.99.0", "doc", *package_args, "--no-deps", "--all-features", "--locked"]))
after = input_snapshot()
bookends = write_compressed("integrated-source-bookends.json.gz",
                            json.dumps({"before": before, "after": after}, sort_keys=True).encode())
receipt = {"integration_revision": revision, "candidate_revision": CANDIDATE,
           "candidate_base": BASE, "platform": platform.platform(), "commands": commands,
           "source_inputs_unchanged": before == after, "source_bookends": bookends,
           "candidate_crate_files_match": candidate_checks,
           "candidate_crate_file_status": candidate_changes,
           "environment": {"CARGO_BUILD_JOBS": "2", "toolchain": "1.99.0"},
           "limitations": ["TSan acceptance remains incomplete; no sanitizer bypass was used.",
                           "No application, release-package, platform-wide or performance acceptance.",
                           "No full API/test parity or complete region/body validity claim."]}
receipt["checks_passed"] = (all(row["exit_code"] == 0 for row in commands)
                             and before == after and all(candidate_checks.values()))
(OUT / "integrated-main.json").write_text(json.dumps(receipt, indent=2) + "\n")
write_compressed("integrated-runner.py.gz", Path(__file__).read_bytes())
print(json.dumps({"checks_passed": receipt["checks_passed"], "revision": revision}), flush=True)
sys.exit(0 if receipt["checks_passed"] else 1)
