//! Temporary public-window lifecycle diagnostic; no error handler or replacement baseline.
use rustycad_tkernel::standard::Handle;
use rustycad_tkservice::{aspect::{AspectDisplayConnection, AspectWindow}, xw::XwWindow};
fn main() {
    let mode = std::env::args().nth(1).expect("expected owned, wrapped-live or wrapped-dead");
    let display = Handle::new(AspectDisplayConnection::new().unwrap());
    let owner = Handle::new(XwWindow::create(&display, "Martensite lifetime diagnostic", 100, 100, 64, 64).unwrap());
    owner.map();
    assert_eq!(owner.size(), (64, 64));
    let observed = match mode.as_str() {
        "owned" => owner.clone(),
        "wrapped-live" | "wrapped-dead" => Handle::new(XwWindow::wrap(&display, owner.native_handle(), 0).unwrap()),
        _ => panic!("mode={mode:?}; expected owned, wrapped-live or wrapped-dead"),
    };
    eprintln!("{{\"probe\":\"window-lifecycle\",\"mode\":{mode:?},\"window\":{},\"stage\":\"before-owner-release\"}}", observed.native_handle());
    let retained_owner = (mode == "wrapped-live").then(|| owner.clone());
    drop(owner);
    eprintln!("{{\"probe\":\"window-lifecycle\",\"mode\":{mode:?},\"window\":{},\"stage\":\"after-owner-release-before-size\"}}", observed.native_handle());
    assert_eq!(observed.size(), (64, 64));
    eprintln!("{{\"probe\":\"window-lifecycle\",\"mode\":{mode:?},\"stage\":\"size-returned\"}}");
    drop(observed);
    drop(retained_owner);
}
