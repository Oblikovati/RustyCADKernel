import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path.cwd(); base=root/'docs/evidence/prism-complete-history-v1-2026-10-14'; out=root/'docs/evidence/prism-complete-history-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=snapshot();assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
for name in ['final-source-bookends.json.gz']:
 d=json.loads(gzip.decompress((base/name).read_bytes()));assert d['before']==d['after']
pinned=json.loads(gzip.decompress((base/'final-test-extraction-source.json.gz').read_bytes()))
for path,digest in pinned.items():
 assert sha(subprocess.check_output(['git','show','4d02ab813:'+path]))==digest,path
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M))
candidate=set().union(*(names(gzip.decompress((base/n).read_bytes())) for n in ['final-tests.log.gz','final-test-extraction-history.log.gz','final-test-extraction-lineage.log.gz']))
actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual
expected=json.loads((base/'pre-style-replay.json').read_text());env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2'};replays=[]
for kind,needle,marker in [('history','complete_prism_history_replay_across_processes_and_threads','complete-prism-history-v1'),('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads','prism-copy-lineage-v1'),('frozen','frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations','frozen-prism-v1')]:
 fixture=gzip.decompress((base/f'pre-style-{kind}-replay.bin.gz').read_bytes());assert sha(fixture)==expected[kind]['sha256']
 for i in (1,2):
  cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked',needle,'--','--nocapture','--test-threads=1'];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{kind}-process-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
  found=re.findall(marker+r':([0-9a-f]+)',p.stdout.decode());assert len(found)==1;blob=bytes.fromhex(found[0]);assert blob==fixture
  (out/f'{kind}-process-{i}.bin.gz').write_bytes(gzip.compress(blob,mtime=0));replays.append({'kind':kind,'process':i,'bytes':len(blob),'sha256':sha(blob)})
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0;assert before==snapshot()
r={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_test_names_retained':len(candidate),'missing_tests':sorted(candidate-actual),'source_unchanged':True,'candidate_artifact_hashes':{str(p.relative_to(base)):sha(p.read_bytes()) for p in sorted(base.rglob('*')) if p.is_file()},'replays':replays,'docs_exit':p.returncode,'limits':['Private complete-history inspection; no public operation or release acceptance.','ThreadSanitizer remains incomplete.']}
(out/'integrated-supplement.json').write_text(json.dumps(r,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('history supplement passed',flush=True)
