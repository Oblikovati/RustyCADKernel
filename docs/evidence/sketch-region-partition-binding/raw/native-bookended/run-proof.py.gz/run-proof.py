import hashlib,json,pathlib,subprocess,gzip,os
root=pathlib.Path.cwd();sdk=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/occt-all-full');out=root/'target/partition-binding/native-bookended'; compiler=pathlib.Path('/usr/bin/x86_64-linux-gnu-g++-13');exe=out/'partition-copy-binding-directed'
sources=[root/'tools/oracle/martensite_partition_copy_binding.cxx',root/'tools/oracle/martensite_partition_fixture.hxx']
sources.extend([root/'tools/oracle/martensite_partition_binding.cxx',root/'tools/oracle/martensite_partition_observation.cxx']); paths=set(sources+[compiler]);paths.update(p for p in sdk.rglob('*') if p.is_file())
for p in sdk.joinpath('include/opencascade').glob('*'):
 if not p.is_file():continue
 for line in p.read_text(errors='ignore').splitlines():
  if line.startswith('#include "'):
   q=pathlib.Path(line.split('"')[1])
   if q.is_absolute() and q.is_file():paths.add(q)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,include_exe=False):
 inputs=paths|({exe} if include_exe else set()); hashes={str(p):digest(p) for p in sorted(inputs)}
 with gzip.GzipFile(filename=str(out/name),mode='wb',mtime=0) as stream:stream.write(json.dumps(hashes,sort_keys=True).encode())
 return hashes
prior=json.loads((root/'target/partition-binding/native-shared-placement/directed-receipt.json').read_text()); paths.update(pathlib.Path(p) for p in prior['loaded_libraries']); paths.add(pathlib.Path(subprocess.check_output([str(compiler),'-print-prog-name=cc1plus'],text=True).strip())); before=save('directed-before-build.json.gz');command=[str(compiler),'-std=c++17','-I',str(sdk/'include/opencascade'),str(sources[0]),'-L',str(sdk/'lin64/gcc/libi'),'-Wl,-rpath,'+str(sdk/'lin64/gcc/libi'),'-lTKBO','-lTKTopAlgo','-lTKBRep','-lTKG3d','-lTKMath','-lTKernel','-o',str(exe)]
with (out/'directed-build.log').open('wb') as log:built=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
assert built.returncode==0
runs=[]
for ordinal in (1,2):
 book=save(f'directed-before-{ordinal}.json.gz',True)
 with (out/f'directed-run-{ordinal}.txt').open('wb') as raw,(out/f'directed-loader-{ordinal}.log').open('wb') as err:
  run=subprocess.run(['bash','-c','ulimit -c 0; exec "$1"','native-proof',str(exe)],stdout=raw,stderr=err,env={**os.environ,'LD_DEBUG':'libs'})
 after=save(f'directed-after-{ordinal}.json.gz',True);assert book==after;assert run.returncode==0
 runs.append({'exit':run.returncode,'raw_sha256':digest(out/f'directed-run-{ordinal}.txt')})
assert runs[0]['raw_sha256']==runs[1]['raw_sha256'];assert before==save('directed-after-source.json.gz')
loaded=set()
for line in (out/'directed-loader-1.log').read_text().splitlines():
 if 'calling init: ' in line:
  p=pathlib.Path(line.split('calling init: ',1)[1].strip())
  if p.is_file():loaded.add(p)
receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_dirty':subprocess.check_output(['git','status','--short'],text=True).splitlines(),'sdk_source_head':subprocess.check_output(['git','-C','/home/vmiguel/git/oblikovati-workspace/OCCT','rev-parse','HEAD'],text=True).strip(),'compiler_version':subprocess.check_output([str(compiler),'--version'],text=True),'command':command,'build_exit':built.returncode,'executable_sha256':digest(exe),'runs':runs,'inputs':len(before),'loaded_libraries':{str(p):digest(p) for p in sorted(loaded)}}
(out/'directed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

for name,fixture in [('martensite_partition_binding','partition-binding-native.txt'),('martensite_partition_observation','partition-observation-native.txt')]:
 legacy=out/name;args=list(command);args[args.index(str(sources[0]))]=str(root/('tools/oracle/'+name+'.cxx'));args[-1]=str(legacy)
 with (out/(name+'-build.log')).open('wb') as log:completed=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 assert completed.returncode==0;paths.add(legacy)
 executions=[]
 for ordinal in (1,2):
  before_legacy=save(f'{name}-before-{ordinal}.json.gz',True)
  raw=out/f'{name}-{ordinal}.txt'
  with raw.open('wb') as stdout,(out/f'{name}-{ordinal}-loader.log').open('wb') as stderr:
   result=subprocess.run(['bash','-c','ulimit -c 0; exec "$1"','native-proof',str(legacy)],stdout=stdout,stderr=stderr,env={**os.environ,'LD_DEBUG':'libs'})
  assert result.returncode==0;assert before_legacy==save(f'{name}-after-{ordinal}.json.gz',True)
  assert raw.read_bytes()==(root/'crates/tkbo/tests/fixtures'/fixture).read_bytes()
  executions.append({'exit':result.returncode,'raw_sha256':digest(raw)})
 receipt[name]={'command':args,'build_exit':completed.returncode,'executable_sha256':digest(legacy),'runs':executions}
(out/'all-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
