import os,subprocess,json
from pathlib import Path
folder=Path('target/unlit-side-color')
env=os.environ.copy();env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
for key in ['VK_ICD_FILENAMES','MARTENSITE_VULKAN_DEVICE','MESA_VK_DEVICE_SELECT']:env.pop(key,None)
env['VK_LAYER_PATH']='/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr/share/vulkan/explicit_layer.d'
env['LD_LIBRARY_PATH']='/home/vmiguel/git/oblikovati-workspace/RustyCADKernel/target/vulkan-validation/extracted/usr/lib/x86_64-linux-gnu'
rows=[]
for profile,icd in [('host','radeon'),('lavapipe','lvp')]:
 env['VK_DRIVER_FILES']='/usr/share/vulkan/icd.d/'+icd+'_icd.json'
 for repeat in [1,2]:
  name=f'pinned-gpu-{profile}-repeat{repeat}'
  command=['cargo','test','-p','martensite-vulkan','--test','toolkit','unlit_face_color_gpu','--locked','--','--test-threads=1','--nocapture']
  with (folder/(name+'.log')).open('w') as log:result=subprocess.run(command,env=env,stdout=log,stderr=log)
  rows.append({'case':name,'exit':result.returncode,'command':command,'icd':env['VK_DRIVER_FILES']})
  if result.returncode:break
 if rows[-1]['exit']:break
 command=['cargo','test','-p','martensite-vulkan','--all-targets','--locked','--','--test-threads=1']
 name=f'pinned-full-{profile}'
 with (folder/(name+'.log')).open('w') as log:result=subprocess.run(command,env=env,stdout=log,stderr=log)
 rows.append({'case':name,'exit':result.returncode,'command':command,'icd':env['VK_DRIVER_FILES']})
 if result.returncode:break
(folder/'gpu-pinned-verdicts.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
raise SystemExit(any(row['exit'] for row in rows))
