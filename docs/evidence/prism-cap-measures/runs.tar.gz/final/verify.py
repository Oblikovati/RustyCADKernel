from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,re
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-cap-measures')
stage=Path('/tmp/martensite-prism-cap-final')
extracted=stage/'extracted'
(extracted/'src').mkdir(parents=True,exist_ok=True)
shutil.copytree(repo/'crates/tkmath/src/predicates',extracted/'src/predicates',dirs_exist_ok=True)
shutil.copy2(repo/'crates/tkmath/src/predicates.rs',extracted/'src/predicates.rs')
for relative in ['tests/support/metric_residual_cases.rs','tests/fixtures/certified_bezier_pairs/native.tsv']:
    target=extracted/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'crates/tkmath'/relative,target)
(extracted/'Cargo.toml').write_text('[package]\nname="martensite-prism-cap-extracted"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\nnum-bigint={version="=0.4.6",default-features=false}\n')
(extracted/'src/lib.rs').write_text('pub mod predicates;\n')
extraction=[]
for path in sorted((extracted/'src').rglob('*')):
    if not path.is_file() or path.name=='lib.rs':continue
    original=repo/'crates/tkmath/src'/path.relative_to(extracted/'src')
    assert path.read_bytes()==original.read_bytes()
    extraction.append({'source':str(original.relative_to(repo)),'extracted':str(path.relative_to(extracted)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(stage/'extraction-equality.json').write_text(json.dumps(extraction,indent=2)+'\n')
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
paths=[p for p in tracked if p.startswith(('crates/tkbo/','crates/tkmath/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/adr/0027-source-bound-prism-cap-measurements.md']]
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
initial=hashes();(stage/'source-before.json').write_text(json.dumps(initial,indent=2)+'\n')
(stage/'revision.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
commands=[
 ('plane-focused',['cargo','test','-p','rustycad-tkmath','--lib','plane_tests','--locked']),
 ('composition-focused',['cargo','test','-p','rustycad-tkbo','--lib','measurements','--locked']),
 ('all-targets',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked']),
 ('doctests',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--doc','--all-features','--locked']),
 ('clippy',['cargo','clippy','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked','--','-D','warnings']),
 ('fmt',['cargo','fmt','-p','rustycad-tkbo','-p','rustycad-tkmath','--check']),
 ('extracted-lock',['cargo','generate-lockfile','--manifest-path',str(extracted/'Cargo.toml'),'--offline']),
 ('extracted-tests',['cargo','test','--manifest-path',str(extracted/'Cargo.toml'),'--offline','--locked','--lib']),
]
for label in ['first','second']:
    commands.append(('process-'+label,['cargo','test','-p','rustycad-tkbo','--lib','portable_prism_measure_process_receipt','--locked','--','--nocapture','--test-threads=1']))
results=[];bookends={}
for label,command in commands:
    before=hashes();started=time.time()
    with (stage/'logs'/f'{label}.log').open('w') as output:
        code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
    after=hashes();entry={'label':label,'command':command,'cwd':str(repo),'exit_code':code,'elapsed_seconds':time.time()-started,'source_unchanged':initial==before==after}
    results.append(entry);bookends[label]={'before':before,'after':after}
    (stage/'commands.json').write_text(json.dumps(results,indent=2)+'\n');(stage/'source-bookends.json').write_text(json.dumps(bookends,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
    assert code==0 and entry['source_unchanged'],entry
(stage/'source-after.json').write_text(json.dumps(hashes(),indent=2)+'\n')
for label in ['first','second']:
    lines=(stage/'logs'/f'process-{label}.log').read_text().splitlines()
    receipts=[line[line.index('{"operation"'):] for line in lines if '{"operation":"martensite.prism-measure-subset"' in line]
    assert len(receipts)==1,(label,receipts)
    (stage/f'process-{label}.json').write_text(receipts[0]+'\n')
assert (stage/'process-first.json').read_bytes()==(stage/'process-second.json').read_bytes()
print('process receipts byte-equal',flush=True)
