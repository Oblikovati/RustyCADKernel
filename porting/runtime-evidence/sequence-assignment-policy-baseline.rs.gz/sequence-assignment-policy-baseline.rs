use rustycad_tkernel::ncollection::{BaseAllocator,Sequence};
fn main() {
 let left=BaseAllocator::incremental(1024);
 let right=BaseAllocator::incremental(1024);
 let mut receiver=Sequence::with_allocator(left.clone());
 receiver.append(9);
 let mut source=Sequence::with_allocator(right.clone());
 source.append(1);
 Clone::clone_from(&mut receiver,&source);
 println!("receiver_allocator_retained={}",receiver.allocator()==&left);
}
