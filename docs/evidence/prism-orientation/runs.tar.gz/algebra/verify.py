"""Independent exact ADR0034 algebra; consumes no Martensite geometry evaluator."""
import hashlib
import itertools
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def cross(first, second):
    return tuple(
        first[(i + 1) % 3] * second[(i + 2) % 3]
        - first[(i + 2) % 3] * second[(i + 1) % 3]
        for i in range(3)
    )


def dot(first, second):
    products = tuple(a * b for a, b in zip(first, second))
    assert len(products) == 3
    return sum(products)


def term(coefficient, axes, count):
    exponents = [0] * count
    for axis in axes:
        exponents[axis] += 1
    return {"coefficient": {"num": str(coefficient), "den": "1"},
            "exponents": exponents}


def expected_function(variables, terms, denominator_axes=()):
    terms.sort(key=lambda item: item["exponents"], reverse=True)
    return {"domain": "QQ", "variables": variables,
            "numerator": {"terms": terms},
            "denominator": {"terms": [term(1, denominator_axes, len(variables))]}}


def tool_output(name):
    result = json.loads((ROOT / name).read_text())
    assert result.get("isError") is False
    return result["structuredContent"]["output"]


def verify_inward_coefficients():
    result = tool_output("orientation_dot_result.json")
    assert result["variables"] == ["u0", "u1", "u2", "v0", "v1", "v2", "a", "b"]
    expected = []
    for axis in range(3):
        j, k = (axis + 1) % 3, (axis + 2) % 3
        terms = [term(sign, [left, right + 3, t, t], 8)
                 for left, right, sign in [(j, k, -1), (k, j, 1)]
                 for t in [6, 7]]
        expected.append(expected_function(result["variables"], terms))
    assert result["entries"] == [expected]
    return "all three coefficients of arbitrary E equal -(a^2+b^2)*(U cross V)"


def verify_side_parameter_normal():
    result = tool_output("orientation_side_result.json")
    assert result["variables"] == ["tx", "ty", "tz", "ex", "ey", "ez", "h"]
    expected = []
    for axis in range(3):
        j, k = (axis + 1) % 3, (axis + 2) % 3
        terms = [term(-1, [j, k + 3], 7), term(1, [k, j + 3], 7)]
        expected.append([expected_function(result["variables"], terms, [6])])
    assert result["entries"] == expected
    return "T cross (-E/h) equals -(T cross E)/h; outward sign uses h>0"


def winding_sign_table():
    rows = []
    for facing, traversal, native in itertools.product([-1, 1], repeat=3):
        selected = facing * traversal * native
        recovered = facing * traversal * selected
        assert recovered == native
        rows.append(dict(f=facing, r=traversal, q=native, w=selected))
    return rows


def rectangle_trim_table():
    edges = {"First": ((1, 0), (0, -1)), "Last": ((1, 0), (0, 1)),
             "Start": ((0, -1), (1, 0)), "End": ((0, -1), (-1, 0))}
    expected = {"First": -1, "Last": 1, "Start": 1, "End": -1}
    rows = []
    for role, (tangent, inward) in edges.items():
        determinant = tangent[0] * inward[1] - tangent[1] * inward[0]
        assert determinant == expected[role]
        for facing in [-1, 1]:
            cumulative = facing * determinant
            assert cumulative * determinant == facing
            rows.append(dict(role=role, tangent=tangent, inward=inward,
                             facing=facing, cumulative=cumulative))
    return rows


def cap_boundary_table():
    rows = []
    for native, facing in itertools.product([-1, 1], repeat=2):
        cumulative = facing * native
        assert cumulative * native == facing
        rows.append(dict(q=native, face=facing, edge=cumulative))
    return rows


def check_world_basis(first, second, extrusion, jacobian):
    checks = 0
    for a, b in itertools.product([-1, 0, 1], repeat=2):
        if a == b == 0:
            continue
        tangent = tuple(a * u + b * v for u, v in zip(first, second))
        left = tuple(-b * u + a * v for u, v in zip(first, second))
        observed = dot(cross(tangent, extrusion), left)
        assert observed == -jacobian * (a * a + b * b)
        for native, face in itertools.product([-1, 1], repeat=2):
            stored_normal_inward_dot = -face * native * observed
            expected_outward = face == -native * (1 if jacobian > 0 else -1)
            assert (stored_normal_inward_dot < 0) == expected_outward
            checks += 1
    return checks


def world_sign_cases():
    vectors = list(itertools.product([-1, 0, 1], repeat=3))
    cases = dict(bases=0, singular=0, side_sign_checks=0, cap_sign_checks=0)
    for first, second, extrusion in itertools.product(vectors, repeat=3):
        jacobian = dot(cross(first, second), extrusion)
        if jacobian == 0:
            cases["singular"] += 1
            continue
        cases["bases"] += 1
        cases["side_sign_checks"] += check_world_basis(first, second, extrusion, jacobian)
        for face in [-1, 1]:
            sign = 1 if jacobian > 0 else -1
            assert (face * jacobian < 0) == (face == -sign)
            assert (face * -jacobian < 0) == (face == sign)
            cases["cap_sign_checks"] += 2
    return cases


def combined_incidence_signs():
    rows = []
    for native, determinant in itertools.product([-1, 1], repeat=2):
        first, last, side = -determinant, determinant, -native * determinant
        cap_edges = [first * native, last * native]
        side_rims = [-side, side]
        assert all(a == -b for a, b in zip(cap_edges, side_rims))
        rows.append(dict(q=native, j=determinant, first=first, last=last,
                         side=side, cap_edges=cap_edges, side_rims=side_rims))
    return rows


def main():
    receipt = {"behavior": "ADR0034 algebra only; no geometry acceptance",
               "python": platform.python_version(), "platform": platform.platform(),
               "inward_identity": verify_inward_coefficients(),
               "stored_side_normal": verify_side_parameter_normal(),
               "winding": winding_sign_table(), "cap_trims": cap_boundary_table(),
               "side_trims": rectangle_trim_table(), "world_cases": world_sign_cases(),
               "incidence_signs": combined_incidence_signs(),
               "limitations": ["Jordan orientation and regularity are prerequisites",
                               "positive h and nonzero J required for sign conclusions",
                               "finite cases supplement universal coefficient identity"]}
    receipt["inputs"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(ROOT.glob("orientation_*.json"))}
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
