use rustycad_tkernel::ncollection::{BaseAllocator, Sequence};
fn main() {
    let mut destination = Sequence::with_allocator(BaseAllocator::incremental(1024));
    let mut source = Sequence::with_allocator(BaseAllocator::incremental(1024));
    destination.append(7); source.append(1);
    let rejected = destination.insert_sequence_after(usize::MAX, &mut source).is_err();
    println!("{{\"rejected\":{rejected},\"destination\":{:?},\"source_length\":{}}}",
        destination.iter().copied().collect::<Vec<_>>(), source.len());
}
