import subprocess,os,json,time,hashlib
from pathlib import Path
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-region-certificates')
stage=Path('/tmp/martensite-region-certificates-evidence')
env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
paths=[p for p in tracked if p.startswith(('crates/tkbo/','crates/tkmath/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/adr/0014-owned-analytic-sketch-regions.md']]
def hashes():
    return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
initial=hashes();(stage/'source-before.json').write_text(json.dumps(initial,indent=2)+'\n')
commands=[
 ('all-targets',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked']),
 ('doctests',['cargo','test','-p','rustycad-tkbo','-p','rustycad-tkmath','--doc','--all-features','--locked']),
 ('clippy',['cargo','clippy','-p','rustycad-tkbo','-p','rustycad-tkmath','--all-targets','--all-features','--locked','--','-D','warnings']),
 ('fmt',['cargo','fmt','-p','rustycad-tkbo','-p','rustycad-tkmath','--check']),
 ('extracted-lock',['cargo','generate-lockfile','--manifest-path',str(stage/'extracted/Cargo.toml'),'--offline']),
 ('extracted-tests',['cargo','test','--manifest-path',str(stage/'extracted/Cargo.toml'),'--offline','--locked','--lib']),
]
for label in ['first','second']:
    commands.append(('process-'+label,['cargo','test','-p','rustycad-tkbo','--lib','portable_region_certificate_process_receipt','--locked','--','--nocapture','--test-threads=1']))
results=[];bookends={}
for label,command in commands:
    before=hashes();started=time.time()
    with (stage/'logs'/f'{label}.log').open('w') as output:
        code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
    after=hashes();entry={'label':label,'command':command,'cwd':str(repo),'exit_code':code,'elapsed_seconds':time.time()-started,'source_unchanged':initial==before==after}
    results.append(entry);bookends[label]={'before':before,'after':after}
    (stage/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
    (stage/'source-bookends.json').write_text(json.dumps(bookends,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
(stage/'source-after.json').write_text(json.dumps(hashes(),indent=2)+'\n')
for label in ['first','second']:
    lines=(stage/'logs'/f'process-{label}.log').read_text().splitlines()
    receipts=[line[line.index('{"operation"'):] for line in lines if '{"operation":"martensite.region-certificate"' in line]
    assert len(receipts)==1,(label,receipts)
    (stage/f'process-{label}.json').write_text(receipts[0]+'\n')
assert (stage/'process-first.json').read_bytes()==(stage/'process-second.json').read_bytes()
print('process receipts byte-equal',flush=True)
assert all(row['exit_code']==0 and row['source_unchanged'] for row in results),results
