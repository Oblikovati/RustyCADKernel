import ast,gzip,hashlib,importlib.util,json,os,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd(); base=root/'docs/evidence/prism-semantic-names-v1'; out=root/'docs/evidence/prism-semantic-names-integration-2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():return {p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0') if p}
before=snapshot(); assert before==json.loads(gzip.decompress((out/'integrated-source-bookends.json.gz').read_bytes()))['after']
r=json.loads((base/'receipt.json').read_text()); assert sha((base/'checks.tar.gz').read_bytes())==r['artifact']['sha256']
with tarfile.open(base/'checks.tar.gz') as archive:
 payloads={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
assert json.loads(payloads['source-before.json'])==json.loads(payloads['source-after.json'])
spec=importlib.util.spec_from_file_location('semantic_expected',base/'generate_expected.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
expected=module.generate_fixture(); fixture=root/'crates/tkbo/src/sketch_region_prism/owned_request/names/fixtures/names-v1.bin';assert expected==fixture.read_bytes(); assert sha(expected)==r['process_replay']['sha256']
env={**os.environ,'PATH':'/home/vmiguel/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','PYTHONDONTWRITEBYTECODE':'1'}
for i in (1,2):
 cmd=['cargo','+1.99.0','test','-p','rustycad-tkbo','--lib','--all-features','--locked','sketch_region_prism::owned_request::names::tests::semantic_replay_probe','--','--exact','--nocapture']
 p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); (out/f'semantic-process-{i}.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
 matches=re.findall(r'SEMANTIC_REPLAY=(\[[^\n]+\])',p.stdout.decode());assert len(matches)==1
 actual=bytes(ast.literal_eval(matches[0]));assert actual==expected
 (out/f'semantic-process-{i}.bin.gz').write_bytes(gzip.compress(actual,mtime=0))
p=subprocess.run(['cargo','+1.99.0','doc','-p','rustycad-tkbo','--all-features','--no-deps','--locked'],env={**env,'RUSTDOCFLAGS':'-D warnings'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'integrated-docs.log.gz').write_bytes(gzip.compress(p.stdout,mtime=0));assert p.returncode==0
names=lambda b:set(re.findall(r'^test (.+?) \.\.\. ok$',b.decode(),re.M))
candidate=names(payloads['frozen-0.log'])|names(payloads['frozen-1.log']);actual=names(gzip.decompress((out/'integrated-tests.log.gz').read_bytes()));assert candidate<=actual
assert before==snapshot()
receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'candidate_archive_verified':r['artifact'],'archive_payload_hashes':{p:sha(b) for p,b in payloads.items()},'candidate_bookends_equal':True,'source_unchanged_since_matrix':True,'candidate_test_names':len(candidate),'missing_names':sorted(candidate-actual),'replay':{'bytes':len(expected),'sha256':sha(expected),'two_processes_match_literal_fixture':True},'docs_exit':p.returncode,'limitations':['Private name reservations only; actual correspondence adapter remains open.','No TSan, public operation, application or release acceptance.']}
(out/'integrated-supplement.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'integrated-supplement-runner.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print('semantic supplement passed',flush=True)
