from pathlib import Path
import subprocess,os,hashlib,json,time
repo=Path('/home/vmiguel/git/oblikovati-workspace/Martensite-prism-complete-measures');stage=Path('/tmp/martensite-complete-measures-evidence')
paths=json.loads(Path('/tmp/martensite-complete-measures-before-boxing/source-before.json').read_text())
def hashes():return {path:hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in paths}
before=hashes();env=dict(os.environ);env['PATH']='/home/vmiguel/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
command=['cargo','test','-p','rustycad-tkbo','--lib','complete_prism_measure_process_receipt','--locked','--','--nocapture','--test-threads=1']
with (stage/'after-boxing-process.log').open('w') as out:code=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
assert code==0
lines=(stage/'after-boxing-process.log').read_text().splitlines();receipt=next(line[line.index('{"operation"'):] for line in lines if '{"operation":"martensite.prism-complete-measures"' in line)+'\n'
(stage/'after-boxing-process.json').write_text(receipt);after=hashes();equal=receipt.encode()==(stage/'before-boxing-process.json').read_bytes()
record={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'command':command,'exit_code':code,'source_unchanged':before==after,'before_after_boxing_bytes_equal':equal,'before':before,'after':after};(stage/'boxing-comparison.json').write_text(json.dumps(record,indent=2)+'\n');assert before==after and equal;print('before/after boxing process receipt bytes equal',flush=True)
