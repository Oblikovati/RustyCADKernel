import os,sys,json,gzip,hashlib,subprocess,time,re
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path.cwd()/'tools'))
from verify_vulkan import run
from vulkan_profiles import probe_profile,confirm_device
from vulkan_performance import performance_rows,summarize_samples,regression_failures
from vulkan_source_receipt import source_hashes

def state():
 rows=subprocess.check_output(['ps','-eo','pid,comm,args'],text=True).splitlines()
 return {'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadavg':Path('/proc/loadavg').read_text().strip(),'compiler_processes':[line for line in rows if len(line.split())>1 and line.split()[1] in ['cargo','rustc','rustdoc','c++','cc1plus','glslangValidator']]}
folder=Path('/tmp/martensite-integrated-gpu-71131d660');start=json.loads((folder/'start.json').read_text());env=os.environ.copy();env['DISPLAY']=':1';assert source_hashes()==start['source_sha256'];assert run(['git','rev-parse','HEAD'],env)==start['start_head'];baseline=json.loads(Path('porting/runtime-evidence/vulkan-clipping-baseline-2026-10-10.json').read_text());text=Path('crates/vulkan/tests/support/text_culling_scene.rs').read_text();culling=set(re.findall(r'"([^"]+)"',re.search(r'pub const CULLING_MODES:.*?=\s*\[(.*?)\];',text,re.S).group(1)))
programs={'renderer_performance':None,'shadow_text_performance':{'shadow-text-1024-glyphs',*[f'named-light-{kind}' for kind in range(4)]},'text_culling_performance':culling,'view_cube_performance':{'view-cube-default','view-cube-lit'}};binary_hashes={name:hashlib.sha256((Path('target/release/examples')/name).read_bytes()).hexdigest() for name in programs};receipt={**start,'binary_sha256':binary_hashes,'start':state(),'profiles':[],'baseline_accepted':False,'baseline_path':'porting/runtime-evidence/vulkan-clipping-baseline-2026-10-10.json','ratios':{'median':1.25,'p95':1.5},'timing_scope':'Optimized completed-frame redraw/readback;63workloads/profile,20warmup100samples;validationdisabled'}
for name in ['lavapipe','host']:
 p=probe_profile(name,env,list(Path('/usr/share/vulkan/icd.d').glob('*.json')),run,Path('/usr/share/vulkan/icd.d/radeon_icd.json'));entry={'name':name,'device':asdict(p.device),'probe':p.probe,'programs':[]};receipt['profiles'].append(entry)
 for program,expected in programs.items():
  before=state();cmd=[str(Path('target/release/examples')/program)];cmd+=['100','20'] if program=='renderer_performance' else [];output=run(cmd,p.environment);after=state();confirm_device(output,p.device);(folder/f'performance-{name}-{program}.log.gz').write_bytes(gzip.compress((output+'\n').encode(),mtime=0))
  if expected is None:rows=performance_rows(output)
  else:
   rows=[json.loads(line.split('=',1)[1]) for line in output.splitlines() if line.startswith('MARTENSITE_PERFORMANCE=')];assert len(rows)==len(expected) and {row['workload'] for row in rows}==expected
   for row in rows:row.update(summarize_samples(row['samples_ms']),samples=len(row['samples_ms']))
  assert all(row['warmup']==20 and row['validation'] is False and row['samples']==100 for row in rows)
  entry['programs'].append({'program':program,'command':cmd,'exit_code':0,'start':before,'end':after,'workloads':rows});print(name,program,'passed',len(rows),'workloads',flush=True)
  if expected is None:
   previous=next(v for v in baseline['profiles'] if v['profile']==name);old_names={r['workload'] for r in previous['performance']};current={'device':asdict(p.device),'driver_info':p.probe,'performance':[r for r in rows if r['workload'] in old_names]};entry['accepted_baseline_workloads']=sorted(old_names);entry['historical_without_accepted_baseline']=sorted(r['workload'] for r in rows if r['workload'] not in old_names);entry['baseline_failures']=regression_failures(current,previous,1.25,1.5);print(name,'accepted10baseline gates',entry['baseline_failures'],flush=True)
 assert sum(len(r['workloads']) for r in entry['programs'])==63
 (folder/'performance.json.gz').write_bytes(gzip.compress((json.dumps(receipt,indent=2)+'\n').encode(),mtime=0))
assert start['source_sha256']==source_hashes();assert run(['git','rev-parse','HEAD'],env)==start['start_head'];assert all(hashlib.sha256((Path('target/release/examples')/name).read_bytes()).hexdigest()==sha for name,sha in binary_hashes.items());receipt.update(end=state(),exit_code=0,final_hashes_verified=True);(folder/'performance.json.gz').write_bytes(gzip.compress((json.dumps(receipt,indent=2)+'\n').encode(),mtime=0));print('final source/binary/HEAD hashes unchanged',flush=True)
