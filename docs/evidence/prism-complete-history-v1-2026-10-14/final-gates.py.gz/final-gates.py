import pathlib,json,hashlib,subprocess,os,time,platform,re,gzip
root=pathlib.Path.cwd();out=pathlib.Path('/tmp/martensite-prism-complete-history');evidence=root/'docs/evidence/prism-complete-history-v1-2026-10-14';env=os.environ.copy();env['PATH']='/home/vmiguel/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2'
files=subprocess.check_output(['git','ls-files','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml']).decode().splitlines()
def snapshot(): return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=snapshot();receipt={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','+1.99.0','-Vv'],env=env).decode(),'jobs':2,'source_files':len(files),'commands':[],'replays':{}}
base=['cargo','+1.99.0'];package=['-p','rustycad-tkbo'];locked=['--all-features','--locked'];commands=[('tests',base+['test']+package+['--all-targets']+locked+['--','--test-threads=1']),('docs',base+['test']+package+['--doc']+locked),('clippy',base+['clippy']+package+['--all-targets']+locked+['--','-D','warnings']),('fmt',base+['fmt','--all','--','--check'])]
for process in [1,2]:
 for label,needle in [('history','complete_prism_history_replay_across_processes_and_threads'),('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads'),('frozen','frozen_prism_owned_bytes_replay_across_threads_and_repeated_operations')]:
  commands.append((f'{label}-process-{process}',base+['test']+package+['--lib',needle]+locked+['--','--nocapture','--test-threads=1']))
for label,cmd in commands:
 start=time.monotonic();path=out/f'final-{label}.log'
 with path.open('wb') as log:code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 entry={'label':label,'command':cmd,'exit_code':code,'seconds':time.monotonic()-start,'source_unchanged':before==snapshot()};receipt['commands'].append(entry);(out/'final-progress.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(entry),flush=True)
 (evidence/f'final-{label}.log.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
 if code or before!=snapshot():raise SystemExit(1)
 if '-process-' in label:
  kind=label.split('-process-')[0];marker={'history':'complete-prism-history-v1','lineage':'prism-copy-lineage-v1','frozen':'frozen-prism-v1'}[kind];matches=re.findall(marker+r':([0-9a-f]+)',path.read_text());assert len(matches)==1
  blob=bytes.fromhex(matches[0]);assert blob==gzip.decompress((evidence/f'pre-style-{kind}-replay.bin.gz').read_bytes()),label
  receipt['replays'][label]={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'exact_bytes_equal_to_pre_style':True}
after=snapshot();assert before==after
(evidence/'final-source-bookends.json.gz').write_bytes(gzip.compress((json.dumps({'before':before,'after':after},indent=2)+'\n').encode(),mtime=0));(evidence/'final-gates.json').write_text(json.dumps(receipt,indent=2)+'\n');print('all gates passed',flush=True)
