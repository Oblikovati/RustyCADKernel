from pathlib import Path
import json, os, subprocess
root = Path.cwd()
runs = []
base = json.loads((root / "target/native-lifecycle-integrated-4757e8b35/runs.json").read_text())[0]["environment"]
for driver, icd in [("amd", "radeon"), ("lavapipe", "lvp")]:
    overrides = {**base, "CARGO_BUILD_JOBS": "2"}
    overrides["VK_DRIVER_FILES"] = overrides["VK_ICD_FILENAMES"] = f"/usr/share/vulkan/icd.d/{icd}_icd.json"
    env = {**os.environ, **overrides}
    command = ["/home/vmiguel/.cargo/bin/cargo", "+1.99.0", "test", "-p", "martensite-vulkan", "--all-targets", "--all-features", "--locked", "--no-fail-fast", "--", "--test-threads=1"]
    log_path = root / f"target/native-lifecycle-integrated-vulkan-{driver}.log"
    with log_path.open("w") as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    runs.append({"driver": driver, "command": command, "environment": overrides, "exit_code": result.returncode, "log": str(log_path.relative_to(root))})
    (root / "target/native-lifecycle-integrated-vulkan-runs.json").write_text(json.dumps(runs, indent=2) + "\n")
    print(json.dumps(runs[-1]), flush=True)
raise SystemExit(any(run["exit_code"] for run in runs))
