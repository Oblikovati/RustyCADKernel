import os,subprocess,sys
from pathlib import Path
root='/tmp/rustycad-ubtree-move-assignment';miri='miri' in sys.argv
suffix='miri' if miri else 'target'
env=dict(os.environ,PATH='/home/vmiguel/.cargo/bin:'+os.environ['PATH'],CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/tmp/rustycad-sparse-base-'+suffix)
if miri:env['MIRIFLAGS']='-Zmiri-strict-provenance'
suites=Path('/tmp/ubtree-move-assignment-suites.txt').read_text().splitlines();args=[arg for suite in suites for arg in ['--test',suite]]
commands=[('miri',['cargo','+nightly-2026-09-25','miri','test','-p','rustycad-tkernel',*args])] if miri else [('normal',['cargo','test','-p','rustycad-tkernel',*args]),('docs',['cargo','test','-p','rustycad-tkernel','--doc']),('clippy',['cargo','clippy','-p','rustycad-tkernel',*args,'--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check'])]
for name,command in commands:
 with open('/tmp/ubtree-move-assignment-'+name+'.log','w') as output:result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 if result.returncode:break
