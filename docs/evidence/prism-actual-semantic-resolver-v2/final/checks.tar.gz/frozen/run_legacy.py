import pathlib,re,subprocess,hashlib,json
root=pathlib.Path('target/semantic-resolver-final')
binary=json.loads((root/'replays.json').read_text())['executable']
cases=[('history','complete_prism_history_replay_across_processes_and_threads','complete-prism-history-v1:',421702,'b5e276d00b09bf4a5590c57692f14a55913b5aa9f3ff0772d9c43384086e0686'),('lineage','prism_copy_lineage_owned_bytes_replay_across_processes_and_threads','prism-copy-lineage-v1:',167821,'491a1a0a7d1a68505a31dcbc3ea52737d19542d44b3a9e5fb93a072614e397ec'),('publication','publication_process_replay','named-prism-publication-v1=',2202990,'accba93e30c455d9f888a96c5b70f684a1dbacbbf3afec9076de3544c7a13107'),('symbolic-map','semantic_map_replay_probe','SEMANTIC_MAP_REPLAY=',10571,'ffbdcd9461a1acb2349d514610a6f24b6cdadd03b460bf9394a65240b88247ff')]
results=[]
for name,test,marker,size,digest in cases:
 log=root/(name+'-legacy.log');cmd=[binary,test,'--nocapture']
 with log.open('wb') as stream: result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0
 text=log.read_text();tail=text.split(marker,1)[1].splitlines()[0]
 payload=bytes(json.loads(tail)) if name=='symbolic-map' else bytes.fromhex(tail)
 actual=hashlib.sha256(payload).hexdigest();assert len(payload)==size and actual==digest
 results.append({'name':name,'command':cmd,'status':result.returncode,'bytes':len(payload),'sha256':actual})
 print(name,len(payload),'unchanged',flush=True)
(root/'legacy-replays.json').write_text(json.dumps(results,indent=2))
